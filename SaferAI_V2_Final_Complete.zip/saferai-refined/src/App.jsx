import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import HomePage from './components/HomePage';
import MechanismPage from './components/MechanismPage';
import ConceptReviewPage from './components/ConceptReviewPage';
import ProductReviewPage from './components/ProductReviewPage';
import GuidanceBot from './components/GuidanceBot';

const Navigation = () => {
  const location = useLocation();
  
  const navStyle = {
    backgroundColor: '#232f3e',
    padding: '0',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    position: 'sticky',
    top: 0,
    zIndex: 1000
  };

  const containerStyle = {
    maxWidth: '1200px',
    margin: '0 auto',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 20px'
  };

  const logoStyle = {
    color: '#ffffff',
    fontSize: '24px',
    fontWeight: 'bold',
    textDecoration: 'none',
    padding: '15px 0'
  };

  const navLinksStyle = {
    display: 'flex',
    listStyle: 'none',
    margin: 0,
    padding: 0,
    gap: '0'
  };

  const linkStyle = {
    color: '#ffffff',
    textDecoration: 'none',
    padding: '20px 24px',
    fontSize: '14px',
    fontWeight: '500',
    borderBottom: '3px solid transparent',
    transition: 'all 0.2s ease',
    display: 'block'
  };

  const activeLinkStyle = {
    ...linkStyle,
    borderBottomColor: '#ff9900',
    backgroundColor: 'rgba(255, 255, 255, 0.1)'
  };

  const isActive = (path) => location.pathname === path;

  return (
    <nav style={navStyle}>
      <div style={containerStyle}>
        <Link to="/" style={logoStyle}>
          SaferAI Portal
        </Link>
        <ul style={navLinksStyle}>
          <li>
            <Link 
              to="/" 
              style={isActive('/') ? activeLinkStyle : linkStyle}
            >
              Home
            </Link>
          </li>
          <li>
            <Link 
              to="/mechanism" 
              style={isActive('/mechanism') ? activeLinkStyle : linkStyle}
            >
              Mechanism
            </Link>
          </li>
          <li>
            <Link 
              to="/concept-review" 
              style={isActive('/concept-review') ? activeLinkStyle : linkStyle}
            >
              Concept Review
            </Link>
          </li>
          <li>
            <Link 
              to="/product-review" 
              style={isActive('/product-review') ? activeLinkStyle : linkStyle}
            >
              Product Review
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

const App = () => {
  return (
    <Router>
      <div style={{ minHeight: '100vh', backgroundColor: '#f5f7fa', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif' }}>
        <Navigation />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/mechanism" element={<MechanismPage />} />
          <Route path="/concept-review" element={<ConceptReviewPage />} />
          <Route path="/product-review" element={<ProductReviewPage />} />
        </Routes>
        <GuidanceBot />
      </div>
    </Router>
  );
};

export default App;
