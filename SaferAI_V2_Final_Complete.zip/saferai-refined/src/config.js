// SaferAI Portal Configuration

export const API_CONFIG = {
  // Production API Gateway endpoint
  BASE_URL: 'https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1',
  
  // Endpoints
  ENDPOINTS: {
    PRODUCT_REVIEW: '/product-review',
    CONCEPT_REVIEW: '/concept-review',
    PROMPT_ANALYSIS: '/prompt-analysis'
  },
  
  // Timeout settings (in milliseconds)
  TIMEOUT: 30000,
  
  // Retry settings
  MAX_RETRIES: 3,
  RETRY_DELAY: 1000
};

// Helper function to get full endpoint URL
export const getEndpointUrl = (endpoint) => {
  return `${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS[endpoint]}`;
};

// Helper function for API calls with error handling
export const callAPI = async (endpoint, options = {}) => {
  const url = typeof endpoint === 'string' && endpoint.startsWith('http') 
    ? endpoint 
    : getEndpointUrl(endpoint);
  
  const defaultOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    ...options
  };

  try {
    const response = await fetch(url, defaultOptions);
    
    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API call error:', error);
    throw error;
  }
};

export default API_CONFIG;
