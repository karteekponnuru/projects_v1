# SaferAI Portal - Enhanced Version Deployment Guide

## Overview

This is the **enhanced version** of the SaferAI Portal with the following new features:

### ✨ New Features

1. **GuidanceBot Component** 
   - Floating chat assistant available on all pages
   - Contextual help for platform compatibility, scoring, and security topics
   - Quick questions for common scenarios
   - Always accessible via chat bubble in bottom-right corner

2. **Enhanced HomePage**
   - Background story from PRFAQ document
   - Expandable section explaining why SaferAI exists
   - Better visual design with gradients and improved layout
   - Clear value propositions for both review types

3. **Updated Concept Review**
   - Exact questions from your provided document
   - 8 risk vectors with precise scoring (0-40 points)
   - Clear risk thresholds: Low (0-16), Medium (17-28), High (29-40)
   - Better UX with hover states and visual feedback

4. **Enhanced Product Review**
   - **ASR ID field (mandatory)** - Required for all product deployments
   - **PDF upload capability** - Attach documentation
   - **Prompt security analysis** - AI-powered analysis via AWS Bedrock API
   - **Concept comparison** - Optional field to link to concept review
   - 8 product-specific questions matching your document
   - Combined risk assessment (product + prompt)

5. **API Integration**
   - Production API Gateway URL configured: `https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1`
   - Centralized config file for easy endpoint management
   - Graceful fallback if API is unavailable

## Project Structure

```
saferai-enhanced-portal/
├── src/
│   ├── components/
│   │   ├── HomePage.jsx              (Enhanced with PRFAQ background)
│   │   ├── MechanismPage.jsx         (Platform compatibility matrix)
│   │   ├── ConceptReviewPage.jsx     (Updated with exact questions)
│   │   ├── ProductReviewPage.jsx     (Enhanced with ASR ID, PDF, prompt analysis)
│   │   └── GuidanceBot.jsx           (NEW - Floating help assistant)
│   ├── lib/
│   │   ├── scoringEngine.js          (40-point scoring system)
│   │   └── pdfGenerator.js           (PDF report generation)
│   ├── config.js                     (NEW - API configuration)
│   ├── App.jsx                       (Updated to include GuidanceBot)
│   └── main.jsx
├── package.json
├── vite.config.js
├── index.html
└── DEPLOYMENT_GUIDE.md               (This file)
```

## Deployment Steps

### Option 1: Local Development

1. **Install Dependencies**
   ```bash
   cd saferai-enhanced-portal
   npm install
   ```

2. **Run Development Server**
   ```bash
   npm run dev
   ```

3. **Access the Portal**
   - Open browser to `http://localhost:5173`
   - Test all features including GuidanceBot

### Option 2: Production Build

1. **Build for Production**
   ```bash
   cd saferai-enhanced-portal
   npm install
   npm run build
   ```

2. **Deploy to S3 + CloudFront**
   ```bash
   # Upload dist folder to S3 bucket
   aws s3 sync dist/ s3://your-saferai-bucket/ --delete
   
   # Invalidate CloudFront cache
   aws cloudfront create-invalidation --distribution-id YOUR_DIST_ID --paths "/*"
   ```

3. **Verify Deployment**
   - Access your CloudFront URL
   - Test all pages and GuidanceBot functionality
   - Verify API integration with prompt analysis

## Configuration

### API Endpoint Configuration

The API endpoint is configured in `src/config.js`:

```javascript
export const API_CONFIG = {
  BASE_URL: 'https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1',
  ENDPOINTS: {
    PRODUCT_REVIEW: '/product-review',
    CONCEPT_REVIEW: '/concept-review',
    PROMPT_ANALYSIS: '/prompt-analysis'
  }
};
```

To change the API endpoint:
1. Edit `src/config.js`
2. Update the `BASE_URL` value
3. Rebuild the application

### Environment Variables (Optional)

For different environments, you can use Vite environment variables:

```bash
# .env.production
VITE_API_BASE_URL=https://your-api-gateway-url.com/prod-v1
```

Then update `config.js` to use:
```javascript
BASE_URL: import.meta.env.VITE_API_BASE_URL || 'https://default-url.com/prod-v1'
```

## Key Features Explained

### 1. GuidanceBot

The GuidanceBot provides contextual help throughout the portal:

- **Platform Compatibility**: Explains which platforms work with which data types
- **Scoring System**: Details on how the 40-point system works
- **Risk Levels**: What each risk level means and what actions to take
- **PII Handling**: Best practices for handling sensitive data
- **Prompt Security**: Guidance on secure prompt design

**Usage**: Click the chat bubble (💬) in the bottom-right corner on any page.

### 2. Concept Review Questions

The 8 risk vectors assessed in Concept Review:

1. **Data Sensitivity** (0-5 points) - What data will be processed
2. **Access Permissions** (0-5 points) - What access level needed
3. **Output Safety** (0-5 points) - What actions will be performed
4. **Prompt Security** (0-5 points) - Who can interact with the agent
5. **External Integrations** (0-5 points) - What external systems connected
6. **Business Impact** (0-5 points) - Impact if agent fails
7. **Compliance & Review** (0, 2, 3, or 5 points) - Review status
8. **Monitoring** (0, 2, 3, or 5 points) - Logging and monitoring plan

**Total Score**: 0-40 points
- 🟢 **Low Risk (0-16)**: Safe to proceed
- 🟡 **Medium Risk (17-28)**: File TT for visibility
- 🔴 **High Risk (29-40)**: Raise SIM before build

### 3. Product Review Questions

The 8 risk vectors assessed in Product Review:

1. **Data Handling** (0-5 points) - Actual data accessed/stored
2. **Access Level** (0-5 points) - Deployed access level
3. **Output Behavior** (0-5 points) - Actions generated
4. **Input Handling** (0-5 points) - Who can provide input
5. **Integrations** (0-5 points) - Systems connected
6. **Logging & Auditability** (0, 2, 3, or 5 points) - Audit capabilities
7. **Failure Handling** (0, 2, 3, 4, or 5 points) - Error handling
8. **Compliance & Review** (0, 1, 3, or 5 points) - Security review status

**Total Score**: 0-40 points
- 🟢 **Low Risk (0-16)**: Safe to deploy
- 🟡 **Medium Risk (17-28)**: File TT before launch
- 🔴 **High Risk (29-40)**: Raise SIM; block deployment

### 4. Prompt Security Analysis

When you submit a prompt for analysis, the system checks 8 security aspects:

1. **Role Clarity** (0-5 points) - Clear role definition
2. **Secret Exposure** (0-5 points) - No embedded secrets
3. **Injection Resistance** (0-5 points) - Can't override instructions
4. **Input Sanitization** (0-5 points) - Validates user input
5. **Prompt Transparency** (0-5 points) - Can't extract hidden instructions
6. **Data/Instruction Separation** (0-5 points) - Clear separation
7. **Safe Fallback** (0-5 points) - Handles uncertainty securely
8. **Output Validation** (0-5 points) - Reviews outputs before action

**Prompt Risk Score**: 0-40 points
- 🟢 **Low Risk (0-10)**: Safe to deploy
- 🟡 **Medium Risk (11-25)**: TT for prompt improvement
- 🔴 **High Risk (26-40)**: Raise SIM before deployment

## Testing Checklist

Before deploying to production, test the following:

- [ ] HomePage loads with background story section
- [ ] GuidanceBot appears on all pages
- [ ] GuidanceBot responds to questions correctly
- [ ] MechanismPage shows platform compatibility matrix
- [ ] Concept Review form validates all required fields
- [ ] Concept Review calculates scores correctly
- [ ] Concept Review shows appropriate risk levels
- [ ] Product Review requires ASR ID (mandatory field)
- [ ] Product Review accepts PDF uploads
- [ ] Product Review prompt analysis calls API
- [ ] Product Review shows combined risk assessment
- [ ] All navigation links work correctly
- [ ] Responsive design works on mobile devices
- [ ] Print functionality works for reports

## Troubleshooting

### GuidanceBot Not Appearing
- Check that `GuidanceBot` is imported in `App.jsx`
- Verify the component is rendered after `<Routes>`
- Check browser console for errors

### API Calls Failing
- Verify API Gateway URL in `src/config.js`
- Check CORS configuration on API Gateway
- Test API endpoint directly with curl/Postman
- Check browser network tab for error details

### Scoring Not Working
- Verify `scoringEngine.js` is imported correctly
- Check that all question options have `score` property
- Ensure form data is being updated correctly

### PDF Upload Not Working
- Check file input `accept` attribute is set to `.pdf`
- Verify file size limits (if any)
- Check browser console for errors

## Support

For issues or questions:
- Check the GuidanceBot for common questions
- Review the PRFAQ document for methodology details
- Contact CTOSS SWAT team for security guidance

## Version History

### Version 2.0 (Enhanced)
- Added GuidanceBot component
- Enhanced HomePage with PRFAQ background
- Updated questions to match provided document
- Added ASR ID mandatory field
- Added PDF upload capability
- Integrated prompt security analysis API
- Added concept comparison feature
- Improved UX with better visual feedback

### Version 1.0 (Original)
- Basic concept and product review functionality
- Platform compatibility matrix
- Simple scoring system
- PDF generation

---

**Deployment Date**: October 2025
**Maintained By**: CTOSS SWAT Team
**API Version**: prod-v1
