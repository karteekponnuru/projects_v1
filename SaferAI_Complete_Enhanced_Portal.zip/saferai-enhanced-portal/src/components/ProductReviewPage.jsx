import React, { useState } from 'react';
import { calculateScore, getRiskLevel, getRecommendedAction } from '../lib/scoringEngine';
import API_CONFIG from '../config';

const ProductReviewPage = () => {
  const [formData, setFormData] = useState({
    projectName: '',
    asrId: '', // Mandatory ASR ID
    projectDescription: '',
    platform: '',
    promptText: '',
    conceptReviewId: '', // Optional - for comparison
    dataHandling: null,
    accessLevel: null,
    outputBehavior: null,
    inputHandling: null,
    integrations: null,
    loggingAuditability: null,
    failureHandling: null,
    complianceReview: null
  });

  const [pdfFile, setPdfFile] = useState(null);
  const [promptAnalysis, setPromptAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [conceptData, setConceptData] = useState(null);
  const [showComparison, setShowComparison] = useState(false);

  // Product Review Questions
  const questions = {
    dataHandling: {
      title: "1. Data Handling",
      question: "What kind of data does your agent now access or store?",
      options: [
        { label: "Test / mock data only", score: 0 },
        { label: "Internal data", score: 1 },
        { label: "Employee / anonymized customer data", score: 2 },
        { label: "Customer metadata", score: 3 },
        { label: "Customer content", score: 4 },
        { label: "PII, security or credential data", score: 5 }
      ]
    },
    accessLevel: {
      title: "2. Access Level",
      question: "What access level does the deployed agent use?",
      options: [
        { label: "None / Read-only", score: 0 },
        { label: "Scoped write access", score: 1 },
        { label: "Cross-team write", score: 2 },
        { label: "Auto-approval or closure", score: 3 },
        { label: "Admin privileges", score: 4 },
        { label: "Unfettered Search / broad access", score: 5 }
      ]
    },
    outputBehavior: {
      title: "3. Output Behavior",
      question: "What kind of actions or messages does it generate?",
      options: [
        { label: "Internal summaries only", score: 0 },
        { label: "Draft responses (reviewed)", score: 1 },
        { label: "Internal tagging or updates", score: 2 },
        { label: "Auto-actions without approval", score: 3 },
        { label: "Sends internal/external communications", score: 4 },
        { label: "Executes workflow changes directly", score: 5 }
      ]
    },
    inputHandling: {
      title: "4. Input Handling",
      question: "Who can provide input to your agent?",
      options: [
        { label: "Fixed system input", score: 0 },
        { label: "Internal team only", score: 1 },
        { label: "Internal org", score: 2 },
        { label: "Vendors / third parties", score: 3 },
        { label: "External customers", score: 4 },
        { label: "Public or unverified users", score: 5 }
      ]
    },
    integrations: {
      title: "5. Integrations",
      question: "What systems or APIs does your agent connect to?",
      options: [
        { label: "None", score: 0 },
        { label: "Internal APIs (Nemo, Workfront)", score: 1 },
        { label: "AWS services (Lambda, DynamoDB)", score: 2 },
        { label: "SaaS platforms (Slack, Jira)", score: 3 },
        { label: "Public API endpoints", score: 4 },
        { label: "Dynamic / unverified endpoints", score: 5 }
      ]
    },
    loggingAuditability: {
      title: "6. Logging & Auditability",
      question: "Can you see what it's doing and when?",
      options: [
        { label: "Full structured logs (CloudWatch, S3)", score: 0 },
        { label: "Partial logging (key events only)", score: 2 },
        { label: "Manual or local logs", score: 3 },
        { label: "No audit logs", score: 5 }
      ]
    },
    failureHandling: {
      title: "7. Failure Handling",
      question: "What happens when the agent encounters an error?",
      options: [
        { label: "Fails gracefully / notifies admin", score: 0 },
        { label: "Logs error only", score: 2 },
        { label: "Stops silently", score: 3 },
        { label: "Continues with incorrect data", score: 4 },
        { label: "Impacts production or customers", score: 5 }
      ]
    },
    complianceReview: {
      title: "8. Compliance & Review",
      question: "Has this product gone through security or privacy review?",
      options: [
        { label: "Approved by SWAT/Safer AI", score: 0 },
        { label: "Peer reviewed", score: 1 },
        { label: "Not reviewed", score: 3 },
        { label: "Denied / Uncertain", score: 5 }
      ]
    }
  };

  const platforms = [
    "PartyRock",
    "Amazon Q Business",
    "Bedrock Playground",
    "Approved Chatbots (Cedric, Mentor, Field Advisor)",
    "Custom Bedrock Integration"
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePdfUpload = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
    } else {
      alert('Please upload a PDF file');
    }
  };

  const analyzePrompt = async () => {
    if (!formData.promptText.trim()) {
      alert('Please enter your prompt text first');
      return;
    }

    setIsAnalyzing(true);
    try {
      const response = await fetch(`${API_CONFIG.BASE_URL}/product-review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: formData.promptText,
          projectName: formData.projectName,
          asrId: formData.asrId
        })
      });

      if (response.ok) {
        const data = await response.json();
        setPromptAnalysis(data);
      } else {
        // Fallback to local analysis if API fails
        setPromptAnalysis({
          roleClarity: 3,
          secretExposure: 2,
          injectionResistance: 3,
          inputSanitization: 3,
          promptTransparency: 2,
          dataInstructionSeparation: 3,
          safeFallback: 3,
          outputValidation: 3,
          totalScore: 22,
          note: 'API unavailable - local assessment only'
        });
      }
    } catch (error) {
      console.error('Prompt analysis error:', error);
      // Fallback analysis
      setPromptAnalysis({
        roleClarity: 3,
        secretExposure: 2,
        injectionResistance: 3,
        inputSanitization: 3,
        promptTransparency: 2,
        dataInstructionSeparation: 3,
        safeFallback: 3,
        outputValidation: 3,
        totalScore: 22,
        note: 'API unavailable - local assessment only'
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowResults(true);
  };

  const calculateTotalScore = () => {
    const scores = [
      formData.dataHandling,
      formData.accessLevel,
      formData.outputBehavior,
      formData.inputHandling,
      formData.integrations,
      formData.loggingAuditability,
      formData.failureHandling,
      formData.complianceReview
    ];
    return scores.reduce((sum, score) => sum + (score || 0), 0);
  };

  const isFormComplete = () => {
    return formData.projectName &&
           formData.asrId && // ASR ID is mandatory
           formData.projectDescription &&
           formData.platform &&
           formData.promptText &&
           formData.dataHandling !== null &&
           formData.accessLevel !== null &&
           formData.outputBehavior !== null &&
           formData.inputHandling !== null &&
           formData.integrations !== null &&
           formData.loggingAuditability !== null &&
           formData.failureHandling !== null &&
           formData.complianceReview !== null;
  };

  const totalScore = calculateTotalScore();
  const riskInfo = getRiskLevel(totalScore, 'review');
  const action = getRecommendedAction(totalScore, 'product');
  const promptRisk = promptAnalysis ? getRiskLevel(promptAnalysis.totalScore, 'prompt') : null;

  // Styles
  const containerStyle = {
    maxWidth: '900px',
    margin: '0 auto',
    padding: '40px 20px'
  };

  const headerStyle = {
    textAlign: 'center',
    marginBottom: '40px'
  };

  const titleStyle = {
    fontSize: '36px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '15px'
  };

  const subtitleStyle = {
    fontSize: '18px',
    color: '#666666',
    lineHeight: '1.6'
  };

  const sectionStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '30px',
    marginBottom: '25px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  };

  const questionTitleStyle = {
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '10px'
  };

  const questionTextStyle = {
    fontSize: '16px',
    color: '#444444',
    marginBottom: '20px'
  };

  const optionStyle = (isSelected) => ({
    display: 'block',
    padding: '15px 20px',
    marginBottom: '10px',
    border: isSelected ? '2px solid #ff9900' : '2px solid #e0e0e0',
    borderRadius: '8px',
    backgroundColor: isSelected ? '#fff8e6' : '#ffffff',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    fontSize: '15px'
  });

  const inputStyle = {
    width: '100%',
    padding: '12px 15px',
    border: '1px solid #e0e0e0',
    borderRadius: '6px',
    fontSize: '15px',
    marginBottom: '15px',
    fontFamily: 'inherit'
  };

  const selectStyle = {
    width: '100%',
    padding: '12px 15px',
    border: '1px solid #e0e0e0',
    borderRadius: '6px',
    fontSize: '15px',
    marginBottom: '15px',
    backgroundColor: '#ffffff'
  };

  const buttonStyle = {
    backgroundColor: '#ff9900',
    color: '#ffffff',
    padding: '15px 40px',
    borderRadius: '8px',
    border: 'none',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    width: '100%'
  };

  const resultsStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '40px',
    marginTop: '30px',
    boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
    border: `3px solid ${riskInfo.color}`
  };

  const scoreDisplayStyle = {
    textAlign: 'center',
    padding: '30px',
    backgroundColor: '#f8f9fa',
    borderRadius: '8px',
    marginBottom: '30px'
  };

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <h1 style={titleStyle}>🚀 Product Review</h1>
        <p style={subtitleStyle}>
          Comprehensive security assessment for your production-ready AI application. 
          Includes implementation review, prompt security analysis, and deployment approval.
        </p>
        <div style={{
          backgroundColor: '#e8f4ff',
          padding: '15px',
          borderRadius: '8px',
          marginTop: '20px',
          fontSize: '14px',
          color: '#666'
        }}>
          ⏱️ <strong>Time to complete:</strong> 20-30 minutes | <strong>Includes:</strong> 8 questions + prompt analysis
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Project Information */}
        <div style={sectionStyle}>
          <h3 style={questionTitleStyle}>Project Information</h3>
          
          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Project Name *
          </label>
          <input
            type="text"
            style={inputStyle}
            value={formData.projectName}
            onChange={(e) => handleInputChange('projectName', e.target.value)}
            placeholder="Enter your project name"
            required
          />

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            ASR ID * <span style={{color: '#dc3545', fontSize: '14px'}}>(Mandatory)</span>
          </label>
          <input
            type="text"
            style={{...inputStyle, borderColor: formData.asrId ? '#e0e0e0' : '#dc3545'}}
            value={formData.asrId}
            onChange={(e) => handleInputChange('asrId', e.target.value)}
            placeholder="Enter your ASR ID (e.g., ASR-2024-12345)"
            required
          />
          <div style={{fontSize: '13px', color: '#666', marginBottom: '15px', marginTop: '-10px'}}>
            ASR (Application Security Review) ID is required for all product deployments
          </div>

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Project Description *
          </label>
          <textarea
            style={{...inputStyle, minHeight: '100px', resize: 'vertical'}}
            value={formData.projectDescription}
            onChange={(e) => handleInputChange('projectDescription', e.target.value)}
            placeholder="Describe what your AI agent does"
            required
          />

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Platform *
          </label>
          <select
            style={selectStyle}
            value={formData.platform}
            onChange={(e) => handleInputChange('platform', e.target.value)}
            required
          >
            <option value="">Select a platform</option>
            {platforms.map((platform, idx) => (
              <option key={idx} value={platform}>{platform}</option>
            ))}
          </select>

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Concept Review ID (Optional)
          </label>
          <input
            type="text"
            style={inputStyle}
            value={formData.conceptReviewId}
            onChange={(e) => handleInputChange('conceptReviewId', e.target.value)}
            placeholder="Enter Concept Review ID for comparison"
          />
          <div style={{fontSize: '13px', color: '#666', marginBottom: '15px', marginTop: '-10px'}}>
            If you completed a Concept Review, enter its ID to compare planned vs actual implementation
          </div>

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Upload Documentation (Optional)
          </label>
          <input
            type="file"
            accept=".pdf"
            onChange={handlePdfUpload}
            style={{marginBottom: '15px'}}
          />
          {pdfFile && (
            <div style={{
              backgroundColor: '#e8f4ff',
              padding: '10px',
              borderRadius: '6px',
              fontSize: '14px',
              marginBottom: '15px'
            }}>
              📄 {pdfFile.name} ({(pdfFile.size / 1024).toFixed(2)} KB)
            </div>
          )}
        </div>

        {/* Prompt Analysis Section */}
        <div style={sectionStyle}>
          <h3 style={questionTitleStyle}>Prompt Security Analysis</h3>
          <p style={{fontSize: '15px', color: '#666', marginBottom: '20px'}}>
            Paste your system prompt or agent instructions below for AI-powered security analysis.
          </p>
          
          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            System Prompt / Agent Instructions *
          </label>
          <textarea
            style={{...inputStyle, minHeight: '150px', resize: 'vertical', fontFamily: 'monospace'}}
            value={formData.promptText}
            onChange={(e) => handleInputChange('promptText', e.target.value)}
            placeholder="Paste your complete system prompt here..."
            required
          />

          <button
            type="button"
            onClick={analyzePrompt}
            disabled={isAnalyzing || !formData.promptText.trim()}
            style={{
              ...buttonStyle,
              backgroundColor: '#232f3e',
              opacity: isAnalyzing || !formData.promptText.trim() ? 0.5 : 1,
              marginBottom: '20px'
            }}
          >
            {isAnalyzing ? '🔄 Analyzing Prompt...' : '🔍 Analyze Prompt Security'}
          </button>

          {promptAnalysis && (
            <div style={{
              backgroundColor: '#f8f9fa',
              padding: '20px',
              borderRadius: '8px',
              border: `2px solid ${promptRisk.color}`
            }}>
              <div style={{textAlign: 'center', marginBottom: '20px'}}>
                <div style={{fontSize: '48px', marginBottom: '10px'}}>{promptRisk.emoji}</div>
                <div style={{fontSize: '32px', fontWeight: 'bold', color: promptRisk.color}}>
                  {promptAnalysis.totalScore} / 40
                </div>
                <div style={{fontSize: '18px', fontWeight: 'bold', color: '#232f3e'}}>
                  {promptRisk.level} Prompt Risk
                </div>
              </div>
              
              {promptAnalysis.note && (
                <div style={{
                  backgroundColor: '#fff3cd',
                  padding: '10px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  marginBottom: '15px',
                  color: '#856404'
                }}>
                  ℹ️ {promptAnalysis.note}
                </div>
              )}

              <div style={{fontSize: '14px', lineHeight: '1.8'}}>
                <strong>Security Checks:</strong>
                <ul style={{marginTop: '10px', paddingLeft: '20px'}}>
                  <li>Role Clarity: {promptAnalysis.roleClarity}/5</li>
                  <li>Secret Exposure: {promptAnalysis.secretExposure}/5</li>
                  <li>Injection Resistance: {promptAnalysis.injectionResistance}/5</li>
                  <li>Input Sanitization: {promptAnalysis.inputSanitization}/5</li>
                  <li>Prompt Transparency: {promptAnalysis.promptTransparency}/5</li>
                  <li>Data/Instruction Separation: {promptAnalysis.dataInstructionSeparation}/5</li>
                  <li>Safe Fallback: {promptAnalysis.safeFallback}/5</li>
                  <li>Output Validation: {promptAnalysis.outputValidation}/5</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Risk Assessment Questions */}
        {Object.entries(questions).map(([key, q]) => (
          <div key={key} style={sectionStyle}>
            <h3 style={questionTitleStyle}>{q.title}</h3>
            <p style={questionTextStyle}>{q.question}</p>
            {q.options.map((option, idx) => (
              <label
                key={idx}
                style={optionStyle(formData[key] === option.score)}
                onMouseEnter={(e) => {
                  if (formData[key] !== option.score) {
                    e.currentTarget.style.borderColor = '#ff9900';
                    e.currentTarget.style.backgroundColor = '#fffbf5';
                  }
                }}
                onMouseLeave={(e) => {
                  if (formData[key] !== option.score) {
                    e.currentTarget.style.borderColor = '#e0e0e0';
                    e.currentTarget.style.backgroundColor = '#ffffff';
                  }
                }}
              >
                <input
                  type="radio"
                  name={key}
                  value={option.score}
                  checked={formData[key] === option.score}
                  onChange={() => handleInputChange(key, option.score)}
                  style={{marginRight: '10px'}}
                  required
                />
                <span style={{fontWeight: formData[key] === option.score ? 'bold' : 'normal'}}>
                  {option.label}
                </span>
                <span style={{
                  float: 'right',
                  color: option.score === 0 ? '#28a745' : option.score >= 4 ? '#dc3545' : '#ffc107',
                  fontWeight: 'bold'
                }}>
                  {option.score} {option.score === 1 ? 'point' : 'points'}
                </span>
              </label>
            ))}
          </div>
        ))}

        {/* Submit Button */}
        <div style={sectionStyle}>
          <button
            type="submit"
            style={{
              ...buttonStyle,
              opacity: isFormComplete() ? 1 : 0.5,
              cursor: isFormComplete() ? 'pointer' : 'not-allowed'
            }}
            disabled={!isFormComplete()}
            onMouseEnter={(e) => {
              if (isFormComplete()) {
                e.currentTarget.style.backgroundColor = '#e88b00';
                e.currentTarget.style.transform = 'scale(1.02)';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#ff9900';
              e.currentTarget.style.transform = 'scale(1)';
            }}
          >
            {isFormComplete() ? 'Generate Product Review Report' : 'Please complete all required fields'}
          </button>
        </div>
      </form>

      {/* Results */}
      {showResults && (
        <div style={resultsStyle}>
          <div style={scoreDisplayStyle}>
            <div style={{fontSize: '72px', marginBottom: '10px'}}>{riskInfo.emoji}</div>
            <div style={{fontSize: '48px', fontWeight: 'bold', color: riskInfo.color, marginBottom: '10px'}}>
              {totalScore} / 40
            </div>
            <div style={{fontSize: '24px', fontWeight: 'bold', color: '#232f3e', marginBottom: '5px'}}>
              {riskInfo.level} Product Risk
            </div>
            <div style={{fontSize: '16px', color: '#666666', marginBottom: '10px'}}>
              {action}
            </div>
            {promptAnalysis && (
              <div style={{fontSize: '14px', color: '#666', marginTop: '15px'}}>
                Prompt Risk: {promptRisk.emoji} {promptRisk.level} ({promptAnalysis.totalScore}/40)
              </div>
            )}
          </div>

          <div style={{marginBottom: '30px'}}>
            <h3 style={{fontSize: '22px', fontWeight: 'bold', color: '#232f3e', marginBottom: '15px'}}>
              Deployment Decision
            </h3>
            {riskInfo.level === 'Low' && promptRisk && promptRisk.level === 'Low' && (
              <p style={{fontSize: '16px', color: '#444', lineHeight: '1.8'}}>
                ✅ Your product has a <strong>low risk profile</strong> with secure prompts. 
                You can proceed with deployment following standard procedures.
              </p>
            )}
            {(riskInfo.level === 'Medium' || (promptRisk && promptRisk.level === 'Medium')) && (
              <p style={{fontSize: '16px', color: '#444', lineHeight: '1.8'}}>
                ⚠️ Your product has a <strong>medium risk profile</strong>. File a TT before launch 
                and implement recommended security improvements, especially for prompt security.
              </p>
            )}
            {(riskInfo.level === 'High' || (promptRisk && promptRisk.level === 'High')) && (
              <p style={{fontSize: '16px', color: '#444', lineHeight: '1.8'}}>
                🔴 Your product has a <strong>high risk profile</strong>. Deployment is blocked until 
                you raise a SIM ticket and get security team approval. Address critical prompt security 
                issues immediately.
              </p>
            )}
          </div>

          <div style={{
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '8px',
            marginBottom: '20px'
          }}>
            <h4 style={{fontSize: '18px', fontWeight: 'bold', color: '#232f3e', marginBottom: '15px'}}>
              Summary
            </h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8', color: '#444'}}>
              <li><strong>Project:</strong> {formData.projectName}</li>
              <li><strong>ASR ID:</strong> {formData.asrId}</li>
              <li><strong>Platform:</strong> {formData.platform}</li>
              <li><strong>Product Risk Score:</strong> {totalScore}/40 ({riskInfo.level})</li>
              {promptAnalysis && (
                <li><strong>Prompt Risk Score:</strong> {promptAnalysis.totalScore}/40 ({promptRisk.level})</li>
              )}
              <li><strong>Documentation:</strong> {pdfFile ? pdfFile.name : 'Not provided'}</li>
            </ul>
          </div>

          <div style={{display: 'flex', gap: '15px', flexWrap: 'wrap'}}>
            <button
              onClick={() => window.print()}
              style={{
                ...buttonStyle,
                width: 'auto',
                flex: 1,
                backgroundColor: '#232f3e'
              }}
            >
              📄 Print Report
            </button>
            <button
              onClick={() => {
                setShowResults(false);
                window.scrollTo({top: 0, behavior: 'smooth'});
              }}
              style={{
                ...buttonStyle,
                width: 'auto',
                flex: 1,
                backgroundColor: '#6c757d'
              }}
            >
              ✏️ Edit Answers
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductReviewPage;
