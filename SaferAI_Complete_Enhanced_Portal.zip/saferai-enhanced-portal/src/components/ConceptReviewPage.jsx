import React, { useState } from 'react';
import { calculateScore, getRiskLevel, getRecommendedAction } from '../lib/scoringEngine';

const ConceptReviewPage = () => {
  const [formData, setFormData] = useState({
    projectName: '',
    projectDescription: '',
    platform: '',
    dataSensitivity: null,
    accessPermissions: null,
    outputSafety: null,
    promptSecurity: null,
    externalIntegrations: null,
    businessImpact: null,
    complianceReview: null,
    monitoring: null
  });

  const [showResults, setShowResults] = useState(false);

  // Questions based on the provided document
  const questions = {
    dataSensitivity: {
      title: "1. Data Sensitivity",
      question: "What kind of data will your agent use or process?",
      options: [
        { label: "Test / Public data only", score: 0 },
        { label: "Internal non-sensitive data", score: 1 },
        { label: "Employee or operational data", score: 2 },
        { label: "Customer metadata (IDs, summaries)", score: 3 },
        { label: "Customer content (emails, chats, attachments)", score: 4 },
        { label: "Security-sensitive / PII / credentials", score: 5 }
      ]
    },
    accessPermissions: {
      title: "2. Access Permissions",
      question: "What kind of access will the agent need?",
      options: [
        { label: "None (sandboxed)", score: 0 },
        { label: "Read-only scoped API", score: 1 },
        { label: "Scoped write access (tag, assign)", score: 2 },
        { label: "Cross-team or multi-tenant access", score: 3 },
        { label: "Workflow approval or auto-closure", score: 4 },
        { label: "Admin / Unfettered Search (UFS)", score: 5 }
      ]
    },
    outputSafety: {
      title: "3. Output Safety",
      question: "What actions or outputs will your agent perform?",
      options: [
        { label: "Suggestions or insights only", score: 0 },
        { label: "Drafts for human review", score: 1 },
        { label: "Internal updates (tags, notes)", score: 2 },
        { label: "Auto-closes or updates workflows", score: 3 },
        { label: "Sends internal/external messages", score: 4 },
        { label: "Executes changes autonomously", score: 5 }
      ]
    },
    promptSecurity: {
      title: "4. Prompt Security",
      question: "Who can interact with or modify your agent's instructions?",
      options: [
        { label: "Fixed system prompt only", score: 0 },
        { label: "Internal staff (limited prompts)", score: 1 },
        { label: "Internal users (free text allowed)", score: 2 },
        { label: "Anyone in org (wide access)", score: 3 },
        { label: "Accepts files / URLs", score: 4 },
        { label: "External / public users", score: 5 }
      ]
    },
    externalIntegrations: {
      title: "5. External Integrations",
      question: "Will your agent connect to any external systems or APIs?",
      options: [
        { label: "None", score: 0 },
        { label: "Internal tools (Nemo, Workfront)", score: 1 },
        { label: "Internal AWS APIs (Lambda, S3)", score: 2 },
        { label: "Third-party SaaS (Slack, Jira)", score: 3 },
        { label: "Public APIs / Internet calls", score: 4 },
        { label: "Unverified / dynamic endpoints", score: 5 }
      ]
    },
    businessImpact: {
      title: "6. Business Impact",
      question: "What happens if the agent fails or misbehaves?",
      options: [
        { label: "None (test only)", score: 0 },
        { label: "Internal efficiency impact", score: 1 },
        { label: "Team-level disruption", score: 2 },
        { label: "Cross-org disruption", score: 3 },
        { label: "Customer-facing impact", score: 4 },
        { label: "Compliance / financial impact", score: 5 }
      ]
    },
    complianceReview: {
      title: "7. Compliance & Review",
      question: "Has this idea been reviewed or approved?",
      options: [
        { label: "Already reviewed and approved", score: 0 },
        { label: "Reviewed by peer / pending SWAT", score: 2 },
        { label: "Not yet reviewed", score: 3 },
        { label: "Rejected or unsure", score: 5 }
      ]
    },
    monitoring: {
      title: "8. Monitoring",
      question: "Will your agent have logging or monitoring?",
      options: [
        { label: "Full logging and dashboards", score: 0 },
        { label: "Partial logs (success/failure)", score: 2 },
        { label: "Manual tracking only", score: 3 },
        { label: "No monitoring planned", score: 5 }
      ]
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowResults(true);
  };

  const calculateTotalScore = () => {
    const scores = [
      formData.dataSensitivity,
      formData.accessPermissions,
      formData.outputSafety,
      formData.promptSecurity,
      formData.externalIntegrations,
      formData.businessImpact,
      formData.complianceReview,
      formData.monitoring
    ];
    return scores.reduce((sum, score) => sum + (score || 0), 0);
  };

  const totalScore = calculateTotalScore();
  const riskInfo = getRiskLevel(totalScore, 'review');
  const action = getRecommendedAction(totalScore, 'concept');

  const isFormComplete = () => {
    return formData.projectName &&
           formData.projectDescription &&
           formData.platform &&
           formData.dataSensitivity !== null &&
           formData.accessPermissions !== null &&
           formData.outputSafety !== null &&
           formData.promptSecurity !== null &&
           formData.externalIntegrations !== null &&
           formData.businessImpact !== null &&
           formData.complianceReview !== null &&
           formData.monitoring !== null;
  };

  // Styles
  const containerStyle = {
    maxWidth: '900px',
    margin: '0 auto',
    padding: '40px 20px'
  };

  const headerStyle = {
    textAlign: 'center',
    marginBottom: '40px'
  };

  const titleStyle = {
    fontSize: '36px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '15px'
  };

  const subtitleStyle = {
    fontSize: '18px',
    color: '#666666',
    lineHeight: '1.6'
  };

  const sectionStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '30px',
    marginBottom: '25px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  };

  const questionTitleStyle = {
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '10px'
  };

  const questionTextStyle = {
    fontSize: '16px',
    color: '#444444',
    marginBottom: '20px'
  };

  const optionStyle = (isSelected) => ({
    display: 'block',
    padding: '15px 20px',
    marginBottom: '10px',
    border: isSelected ? '2px solid #ff9900' : '2px solid #e0e0e0',
    borderRadius: '8px',
    backgroundColor: isSelected ? '#fff8e6' : '#ffffff',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    fontSize: '15px'
  });

  const inputStyle = {
    width: '100%',
    padding: '12px 15px',
    border: '1px solid #e0e0e0',
    borderRadius: '6px',
    fontSize: '15px',
    marginBottom: '15px',
    fontFamily: 'inherit'
  };

  const selectStyle = {
    width: '100%',
    padding: '12px 15px',
    border: '1px solid #e0e0e0',
    borderRadius: '6px',
    fontSize: '15px',
    marginBottom: '15px',
    backgroundColor: '#ffffff'
  };

  const buttonStyle = {
    backgroundColor: '#ff9900',
    color: '#ffffff',
    padding: '15px 40px',
    borderRadius: '8px',
    border: 'none',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    width: '100%'
  };

  const resultsStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '40px',
    marginTop: '30px',
    boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
    border: `3px solid ${riskInfo.color}`
  };

  const scoreDisplayStyle = {
    textAlign: 'center',
    padding: '30px',
    backgroundColor: '#f8f9fa',
    borderRadius: '8px',
    marginBottom: '30px'
  };

  const platforms = [
    "PartyRock",
    "Amazon Q Business",
    "Bedrock Playground",
    "Approved Chatbots (Cedric, Mentor, Field Advisor)",
    "Custom Bedrock Integration"
  ];

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <h1 style={titleStyle}>🎯 Concept Review</h1>
        <p style={subtitleStyle}>
          Evaluate your AI project concept before you build. Answer 8 questions across key risk vectors 
          to determine if your idea is feasible and get platform selection guidance.
        </p>
        <div style={{
          backgroundColor: '#e8f4ff',
          padding: '15px',
          borderRadius: '8px',
          marginTop: '20px',
          fontSize: '14px',
          color: '#666'
        }}>
          ⏱️ <strong>Time to complete:</strong> 10-15 minutes | <strong>Total possible score:</strong> 0-40 points
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Project Information */}
        <div style={sectionStyle}>
          <h3 style={questionTitleStyle}>Project Information</h3>
          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Project Name *
          </label>
          <input
            type="text"
            style={inputStyle}
            value={formData.projectName}
            onChange={(e) => handleInputChange('projectName', e.target.value)}
            placeholder="Enter your project name"
            required
          />

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Project Description *
          </label>
          <textarea
            style={{...inputStyle, minHeight: '100px', resize: 'vertical'}}
            value={formData.projectDescription}
            onChange={(e) => handleInputChange('projectDescription', e.target.value)}
            placeholder="Describe what your AI agent will do"
            required
          />

          <label style={{display: 'block', marginBottom: '10px', color: '#444', fontWeight: '500'}}>
            Intended Platform *
          </label>
          <select
            style={selectStyle}
            value={formData.platform}
            onChange={(e) => handleInputChange('platform', e.target.value)}
            required
          >
            <option value="">Select a platform</option>
            {platforms.map((platform, idx) => (
              <option key={idx} value={platform}>{platform}</option>
            ))}
          </select>
        </div>

        {/* Risk Assessment Questions */}
        {Object.entries(questions).map(([key, q]) => (
          <div key={key} style={sectionStyle}>
            <h3 style={questionTitleStyle}>{q.title}</h3>
            <p style={questionTextStyle}>{q.question}</p>
            {q.options.map((option, idx) => (
              <label
                key={idx}
                style={optionStyle(formData[key] === option.score)}
                onMouseEnter={(e) => {
                  if (formData[key] !== option.score) {
                    e.currentTarget.style.borderColor = '#ff9900';
                    e.currentTarget.style.backgroundColor = '#fffbf5';
                  }
                }}
                onMouseLeave={(e) => {
                  if (formData[key] !== option.score) {
                    e.currentTarget.style.borderColor = '#e0e0e0';
                    e.currentTarget.style.backgroundColor = '#ffffff';
                  }
                }}
              >
                <input
                  type="radio"
                  name={key}
                  value={option.score}
                  checked={formData[key] === option.score}
                  onChange={() => handleInputChange(key, option.score)}
                  style={{marginRight: '10px'}}
                  required
                />
                <span style={{fontWeight: formData[key] === option.score ? 'bold' : 'normal'}}>
                  {option.label}
                </span>
                <span style={{
                  float: 'right',
                  color: option.score === 0 ? '#28a745' : option.score >= 4 ? '#dc3545' : '#ffc107',
                  fontWeight: 'bold'
                }}>
                  {option.score} {option.score === 1 ? 'point' : 'points'}
                </span>
              </label>
            ))}
          </div>
        ))}

        {/* Submit Button */}
        <div style={sectionStyle}>
          <button
            type="submit"
            style={{
              ...buttonStyle,
              opacity: isFormComplete() ? 1 : 0.5,
              cursor: isFormComplete() ? 'pointer' : 'not-allowed'
            }}
            disabled={!isFormComplete()}
            onMouseEnter={(e) => {
              if (isFormComplete()) {
                e.currentTarget.style.backgroundColor = '#e88b00';
                e.currentTarget.style.transform = 'scale(1.02)';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#ff9900';
              e.currentTarget.style.transform = 'scale(1)';
            }}
          >
            {isFormComplete() ? 'Calculate Risk Score' : 'Please complete all questions'}
          </button>
        </div>
      </form>

      {/* Results */}
      {showResults && (
        <div style={resultsStyle}>
          <div style={scoreDisplayStyle}>
            <div style={{fontSize: '72px', marginBottom: '10px'}}>{riskInfo.emoji}</div>
            <div style={{fontSize: '48px', fontWeight: 'bold', color: riskInfo.color, marginBottom: '10px'}}>
              {totalScore} / 40
            </div>
            <div style={{fontSize: '24px', fontWeight: 'bold', color: '#232f3e', marginBottom: '5px'}}>
              {riskInfo.level} Risk
            </div>
            <div style={{fontSize: '16px', color: '#666666'}}>
              {action}
            </div>
          </div>

          <div style={{marginBottom: '30px'}}>
            <h3 style={{fontSize: '22px', fontWeight: 'bold', color: '#232f3e', marginBottom: '15px'}}>
              What This Means
            </h3>
            {riskInfo.level === 'Low' && (
              <p style={{fontSize: '16px', color: '#444', lineHeight: '1.8'}}>
                ✅ Your concept has a <strong>low risk profile</strong>. You can proceed with development 
                using standard security practices. Make sure to complete a Product Review after building.
              </p>
            )}
            {riskInfo.level === 'Medium' && (
              <p style={{fontSize: '16px', color: '#444', lineHeight: '1.8'}}>
                ⚠️ Your concept has a <strong>medium risk profile</strong>. File a TT (Trouble Ticket) for 
                visibility with the SWAT team before proceeding. They can provide guidance on additional 
                security controls you should implement.
              </p>
            )}
            {riskInfo.level === 'High' && (
              <p style={{fontSize: '16px', color: '#444', lineHeight: '1.8'}}>
                🔴 Your concept has a <strong>high risk profile</strong>. You must raise a SIM (Security 
                Incident Management) ticket and get approval from the security team before building. 
                Consider redesigning your approach to reduce risk, such as using a different platform, 
                reducing data sensitivity, or adding human-in-the-loop controls.
              </p>
            )}
          </div>

          <div style={{
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '8px',
            marginBottom: '20px'
          }}>
            <h4 style={{fontSize: '18px', fontWeight: 'bold', color: '#232f3e', marginBottom: '15px'}}>
              Next Steps
            </h4>
            <ol style={{paddingLeft: '20px', lineHeight: '1.8', color: '#444'}}>
              {riskInfo.level === 'High' && (
                <>
                  <li>Raise a SIM ticket immediately</li>
                  <li>Contact CTOSS SWAT team for consultation</li>
                  <li>Consider alternative approaches to reduce risk</li>
                  <li>Do not proceed with development until approved</li>
                </>
              )}
              {riskInfo.level === 'Medium' && (
                <>
                  <li>File a TT for SWAT team visibility</li>
                  <li>Review the Platform-Data Compatibility Matrix</li>
                  <li>Implement recommended security controls</li>
                  <li>Proceed with development</li>
                  <li>Complete Product Review after building</li>
                </>
              )}
              {riskInfo.level === 'Low' && (
                <>
                  <li>Review the Platform-Data Compatibility Matrix to confirm your platform choice</li>
                  <li>Proceed with development following security best practices</li>
                  <li>Implement logging and monitoring from the start</li>
                  <li>Complete Product Review after building</li>
                </>
              )}
            </ol>
          </div>

          <div style={{display: 'flex', gap: '15px', flexWrap: 'wrap'}}>
            <button
              onClick={() => window.print()}
              style={{
                ...buttonStyle,
                width: 'auto',
                flex: 1,
                backgroundColor: '#232f3e'
              }}
            >
              📄 Print Results
            </button>
            <button
              onClick={() => {
                setShowResults(false);
                window.scrollTo({top: 0, behavior: 'smooth'});
              }}
              style={{
                ...buttonStyle,
                width: 'auto',
                flex: 1,
                backgroundColor: '#6c757d'
              }}
            >
              ✏️ Edit Answers
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConceptReviewPage;
