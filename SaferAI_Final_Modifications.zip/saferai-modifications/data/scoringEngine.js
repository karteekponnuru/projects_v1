// SaferAI Scoring Engine - Simple 40-Point System
export const SaferAIScoringEngine = {
  
  // Risk vectors with detailed information
  RISK_VECTORS: {
    'data-sensitivity': {
      name: 'Data Sensitivity',
      description: 'Classification and handling of data types',
      maxScore: 5,
      questions: [
        'What type of data will your application primarily handle?',
        'Does your application process personally identifiable information (PII)?',
        'What data masking or anonymization strategy will you implement?',
        'What is your data retention and deletion policy?',
        'Will your application transfer data across geographic regions?'
      ]
    },
    'access-permissions': {
      name: 'Access Permissions',
      description: 'Authentication, authorization, and access controls',
      maxScore: 5,
      questions: [
        'What level of system access does your application require?',
        'How will users authenticate to your application?',
        'What authorization controls will you implement?',
        'How will you manage and review user access permissions?',
        'Do you require privileged access management (PAM) capabilities?'
      ]
    },
    'output-safety': {
      name: 'Output Safety',
      description: 'Content filtering and output validation',
      maxScore: 5,
      questions: [
        'What output filtering mechanisms will you implement?',
        'How will you prevent generation of harmful or inappropriate content?',
        'What content validation processes will you use?',
        'What logging strategy will you implement for outputs?',
        'How will you provide user guidance and warnings?'
      ]
    },
    'prompt-security': {
      name: 'Prompt Security',
      description: 'Input validation and prompt injection protection',
      maxScore: 5,
      questions: [
        'What is your approach to prompt design and engineering?',
        'What input validation strategy will you implement?',
        'How will you protect against prompt injection attacks?',
        'How will you handle dynamic content in prompts?',
        'What prompt testing and validation strategy will you use?'
      ]
    },
    'external-integrations': {
      name: 'External Integrations',
      description: 'Third-party services and API security',
      maxScore: 5,
      questions: [
        'Will your application integrate with third-party APIs or services?',
        'What data sharing arrangements do you have with external services?',
        'How will you assess and validate vendor security?',
        'What API security controls will you implement?',
        'How will you monitor external integrations?'
      ]
    },
    'business-impact': {
      name: 'Business Impact',
      description: 'Scope, criticality, and operational considerations',
      maxScore: 5,
      questions: [
        'What is the scope of users who will be impacted by your application?',
        'What is the business criticality of your application?',
        'What fallback plan do you have if your application fails?',
        'What is the scope of your initial deployment?',
        'What rollback plan do you have in case of issues?'
      ]
    },
    'compliance': {
      name: 'Compliance',
      description: 'Regulatory requirements and governance',
      maxScore: 5,
      questions: [
        'What regulatory requirements apply to your application?',
        'How will you ensure compliance with privacy laws?',
        'What industry standards or frameworks will you follow?',
        'What audit and compliance reporting requirements do you have?',
        'How will you implement data governance controls?'
      ]
    },
    'monitoring': {
      name: 'Monitoring',
      description: 'Logging, alerting, and incident response',
      maxScore: 5,
      questions: [
        'What logging strategy will you implement?',
        'What alerting and notification systems will you use?',
        'What is your incident response plan?',
        'How will you monitor application performance?',
        'What security monitoring capabilities will you implement?'
      ]
    }
  },

  // Platform compatibility matrix
  PLATFORM_DATA_MATRIX: {
    'partyrock': {
      'public': { 
        status: 'approved', 
        note: 'Perfect for public-facing AI applications and demos',
        details: 'PartyRock is designed for public data and can safely handle marketing materials, public documentation, and general knowledge bases.',
        examples: ['Customer FAQ chatbots', 'Product information assistants', 'Public knowledge bases'],
        requirements: ['Standard PartyRock terms of service', 'Public data only'],
        timeline: 'Immediate deployment'
      },
      'internal': { 
        status: 'review', 
        note: 'Requires review for internal data handling',
        details: 'Internal data on PartyRock requires additional security considerations and approval.',
        examples: ['Employee directory lookups', 'Internal FAQ systems'],
        requirements: ['Security review', 'Data classification approval', 'Access controls'],
        timeline: '1-2 weeks for review'
      },
      'confidential': { 
        status: 'restricted', 
        note: 'Not recommended for confidential data',
        details: 'PartyRock is not designed for confidential data handling and lacks necessary security controls.',
        examples: ['Not applicable'],
        requirements: ['Alternative platform recommended'],
        timeline: 'Not applicable'
      },
      'highly-confidential': { 
        status: 'blocked', 
        note: 'Strictly prohibited for highly confidential data',
        details: 'Highly confidential data cannot be processed on PartyRock under any circumstances.',
        examples: ['Not applicable'],
        requirements: ['Use approved enterprise platforms'],
        timeline: 'Not applicable'
      },
      'restricted': { 
        status: 'blocked', 
        note: 'Strictly prohibited for restricted data',
        details: 'Restricted data requires specialized security controls not available on PartyRock.',
        examples: ['Not applicable'],
        requirements: ['Use specialized secure platforms'],
        timeline: 'Not applicable'
      }
    },
    'amazon-q-business': {
      'public': { 
        status: 'approved', 
        note: 'Excellent for public knowledge bases and customer support',
        details: 'Amazon Q Business provides robust RAG capabilities for public data with built-in security controls.',
        examples: ['Customer support chatbots', 'Product documentation search', 'Public knowledge retrieval'],
        requirements: ['Standard Q Business configuration', 'Public data sources only'],
        timeline: 'Immediate deployment'
      },
      'internal': { 
        status: 'approved', 
        note: 'Built-in security controls for internal data',
        details: 'Amazon Q Business is designed for internal enterprise data with comprehensive access controls.',
        examples: ['Internal documentation search', 'Employee knowledge base', 'Process automation'],
        requirements: ['IAM configuration', 'Data source permissions', 'User access controls'],
        timeline: '1-3 days for setup'
      },
      'confidential': { 
        status: 'approved', 
        note: 'Enterprise-grade security for confidential data',
        details: 'Q Business provides enterprise security features suitable for confidential data handling.',
        examples: ['Customer data analysis', 'Business intelligence queries', 'Confidential document search'],
        requirements: ['Enhanced security configuration', 'Encryption at rest and in transit', 'Audit logging'],
        timeline: '1 week for security setup'
      },
      'highly-confidential': { 
        status: 'review', 
        note: 'Requires comprehensive security review',
        details: 'Highly confidential data requires additional security measures and approval processes.',
        examples: ['Financial data analysis', 'Strategic planning documents'],
        requirements: ['Security architecture review', 'Additional encryption', 'Restricted access controls'],
        timeline: '2-3 weeks for review'
      },
      'restricted': { 
        status: 'restricted', 
        note: 'Special approval required',
        details: 'Restricted data requires special permissions and additional security controls.',
        examples: ['Legal documents', 'HR records', 'Security information'],
        requirements: ['Special approval process', 'Enhanced monitoring', 'Compliance validation'],
        timeline: '3-4 weeks for approval'
      }
    },
    'bedrock-playground': {
      'public': { 
        status: 'approved', 
        note: 'Safe for experimentation with public data',
        details: 'Bedrock Playground is perfect for testing and prototyping with public data sources.',
        examples: ['AI model testing', 'Prompt experimentation', 'Public data analysis'],
        requirements: ['Public data only', 'No production use'],
        timeline: 'Immediate access'
      },
      'internal': { 
        status: 'review', 
        note: 'Requires data handling review for internal data',
        details: 'Internal data in playground environments requires careful consideration of data exposure risks.',
        examples: ['Internal data testing', 'Model validation'],
        requirements: ['Data sanitization', 'Limited scope testing', 'Security review'],
        timeline: '1-2 weeks for review'
      },
      'confidential': { 
        status: 'restricted', 
        note: 'Not recommended without additional controls',
        details: 'Playground environments lack the security controls necessary for confidential data.',
        examples: ['Not recommended'],
        requirements: ['Use production environments instead'],
        timeline: 'Not applicable'
      },
      'highly-confidential': { 
        status: 'blocked', 
        note: 'Not allowed in playground environment',
        details: 'Highly confidential data cannot be used in playground or testing environments.',
        examples: ['Not applicable'],
        requirements: ['Use production environments with full security controls'],
        timeline: 'Not applicable'
      },
      'restricted': { 
        status: 'blocked', 
        note: 'Strictly prohibited in playground',
        details: 'Restricted data requires production-grade security controls not available in playground.',
        examples: ['Not applicable'],
        requirements: ['Use approved production platforms'],
        timeline: 'Not applicable'
      }
    },
    'approved-chatbots': {
      'public': { 
        status: 'approved', 
        note: 'Pre-approved for public data interactions',
        details: 'Approved chatbots like Cedric, Mentor, and Field Advisor are designed for public data.',
        examples: ['General assistance', 'Public information queries', 'Standard support tasks'],
        requirements: ['Use within approved scope', 'Follow usage guidelines'],
        timeline: 'Immediate use'
      },
      'internal': { 
        status: 'approved', 
        note: 'Designed for internal Amazon data',
        details: 'These chatbots are specifically designed and approved for internal Amazon data handling.',
        examples: ['Employee assistance', 'Internal process guidance', 'System information'],
        requirements: ['Standard authentication', 'Appropriate data scope'],
        timeline: 'Immediate use'
      },
      'confidential': { 
        status: 'approved', 
        note: 'Built with confidential data protections',
        details: 'Approved chatbots include necessary security controls for confidential data handling.',
        examples: ['Customer support', 'Business process assistance', 'Confidential information lookup'],
        requirements: ['Proper authentication', 'Data access controls', 'Audit logging'],
        timeline: 'Immediate use with proper setup'
      },
      'highly-confidential': { 
        status: 'review', 
        note: 'Case-by-case approval required',
        details: 'Highly confidential data requires individual assessment and approval for each use case.',
        examples: ['Financial data queries', 'Strategic information access'],
        requirements: ['Individual use case review', 'Enhanced monitoring', 'Restricted access'],
        timeline: '1-2 weeks for approval'
      },
      'restricted': { 
        status: 'restricted', 
        note: 'Special permissions needed',
        details: 'Restricted data requires special permissions and additional security measures.',
        examples: ['Legal document access', 'HR information', 'Security data'],
        requirements: ['Special approval process', 'Enhanced security controls', 'Compliance validation'],
        timeline: '2-3 weeks for approval'
      }
    },
    'custom-bedrock': {
      'public': { 
        status: 'approved', 
        note: 'Full control over public data processing',
        details: 'Custom Bedrock integrations provide complete control over security and data handling for public data.',
        examples: ['Custom AI applications', 'Specialized processing', 'Public data analytics'],
        requirements: ['Proper architecture design', 'Security best practices', 'Standard monitoring'],
        timeline: '1-2 weeks for development'
      },
      'internal': { 
        status: 'approved', 
        note: 'Customizable security controls available',
        details: 'Custom implementations can include all necessary security controls for internal data.',
        examples: ['Internal AI applications', 'Custom workflows', 'Specialized processing'],
        requirements: ['Security architecture review', 'IAM configuration', 'Encryption implementation'],
        timeline: '2-3 weeks for secure implementation'
      },
      'confidential': { 
        status: 'approved', 
        note: 'Can implement required security measures',
        details: 'Custom Bedrock integrations can be designed with all necessary security controls for confidential data.',
        examples: ['Confidential data processing', 'Secure AI workflows', 'Protected analytics'],
        requirements: ['Comprehensive security design', 'Encryption at rest and in transit', 'Access controls', 'Audit logging'],
        timeline: '3-4 weeks for secure implementation'
      },
      'highly-confidential': { 
        status: 'review', 
        note: 'Requires comprehensive security review',
        details: 'Highly confidential data requires thorough security architecture review and approval.',
        examples: ['Financial data processing', 'Strategic analytics', 'Sensitive AI applications'],
        requirements: ['Security architecture review', 'Penetration testing', 'Compliance validation', 'Enhanced monitoring'],
        timeline: '4-6 weeks for review and approval'
      },
      'restricted': { 
        status: 'review', 
        note: 'Possible with proper security architecture',
        details: 'Restricted data can be handled with proper security architecture and comprehensive controls.',
        examples: ['Legal document processing', 'HR data analytics', 'Security information processing'],
        requirements: ['Comprehensive security review', 'Special approval process', 'Enhanced controls', 'Continuous monitoring'],
        timeline: '6-8 weeks for approval and implementation'
      }
    }
  },

  // Calculate simple average-based score
  calculateRiskScore: function(assessmentData) {
    let totalScore = 0;
    let vectorResults = {};
    const maxPossibleScore = 40; // 8 vectors × 5 points each
    
    // Process each risk vector
    Object.keys(this.RISK_VECTORS).forEach(vectorKey => {
      let vectorSum = 0;
      let questionCount = 0;
      
      // Get all questions for this vector from assessment data
      Object.keys(assessmentData.riskAssessments || {}).forEach(questionKey => {
        if (questionKey.startsWith(vectorKey.replace('-', ''))) {
          const answer = assessmentData.riskAssessments[questionKey];
          if (answer && answer !== 'Select option') {
            // Extract point value from answer
            const pointMatch = answer.match(/\((\d+)\s*points?\)/);
            if (pointMatch) {
              vectorSum += parseInt(pointMatch[1]);
              questionCount++;
            }
          }
        }
      });
      
      // Calculate simple average and round to nearest integer (1-5 scale)
      const vectorScore = questionCount > 0 ? Math.round(vectorSum / questionCount) : 0;
      
      // Store vector results with detailed analysis
      vectorResults[this.RISK_VECTORS[vectorKey].name] = {
        score: vectorScore,
        maxScore: 5,
        riskLevel: this.getRiskLevel(vectorScore, 5),
        analysis: this.getVectorAnalysis(vectorKey, vectorScore, assessmentData),
        recommendations: this.getVectorRecommendations(vectorKey, vectorScore)
      };
      
      totalScore += vectorScore;
    });
    
    const riskLevel = this.getOverallRiskLevel(totalScore);
    
    return {
      totalScore,
      maxPossibleScore,
      riskLevel,
      riskDescription: this.getRiskDescription(riskLevel),
      vectorResults,
      overallAnalysis: this.getOverallAnalysis(totalScore, riskLevel),
      recommendations: this.getOverallRecommendations(totalScore, riskLevel, vectorResults)
    };
  },

  // Get vector-specific analysis
  getVectorAnalysis: function(vectorKey, score, assessmentData) {
    const analyses = {
      'data-sensitivity': {
        1: 'Excellent: Your application handles only public data with minimal sensitivity concerns.',
        2: 'Good: Low-sensitivity data with basic protection requirements.',
        3: 'Moderate: Some sensitive data requiring standard security controls.',
        4: 'Concerning: High-sensitivity data requiring enhanced security measures.',
        5: 'Critical: Highly sensitive data requiring comprehensive security controls.'
      },
      'access-permissions': {
        1: 'Excellent: Minimal access requirements with standard authentication.',
        2: 'Good: Basic access controls with proper authentication mechanisms.',
        3: 'Moderate: Standard access controls requiring careful management.',
        4: 'Concerning: Elevated access requirements needing enhanced controls.',
        5: 'Critical: High-privilege access requiring comprehensive access management.'
      },
      'output-safety': {
        1: 'Excellent: Minimal output safety concerns with basic filtering.',
        2: 'Good: Standard output controls with appropriate filtering mechanisms.',
        3: 'Moderate: Some output safety concerns requiring enhanced filtering.',
        4: 'Concerning: Significant output safety risks requiring comprehensive controls.',
        5: 'Critical: High output safety risks requiring advanced filtering and monitoring.'
      },
      'prompt-security': {
        1: 'Excellent: Low prompt injection risk with basic input validation.',
        2: 'Good: Standard prompt security with appropriate validation.',
        3: 'Moderate: Some prompt security concerns requiring enhanced validation.',
        4: 'Concerning: Significant prompt injection risks requiring advanced protection.',
        5: 'Critical: High prompt injection risks requiring comprehensive security measures.'
      },
      'external-integrations': {
        1: 'Excellent: No external integrations or only trusted internal services.',
        2: 'Good: Limited external integrations with approved vendors.',
        3: 'Moderate: Some external integrations requiring security validation.',
        4: 'Concerning: Multiple external integrations requiring comprehensive review.',
        5: 'Critical: Extensive external integrations requiring advanced security controls.'
      },
      'business-impact': {
        1: 'Excellent: Limited scope with minimal business impact.',
        2: 'Good: Controlled scope with manageable business impact.',
        3: 'Moderate: Moderate scope requiring careful impact management.',
        4: 'Concerning: Significant scope with substantial business impact.',
        5: 'Critical: Wide scope with critical business impact requiring comprehensive planning.'
      },
      'compliance': {
        1: 'Excellent: Minimal compliance requirements with standard controls.',
        2: 'Good: Basic compliance requirements with appropriate controls.',
        3: 'Moderate: Some compliance requirements requiring enhanced controls.',
        4: 'Concerning: Significant compliance requirements requiring comprehensive measures.',
        5: 'Critical: Extensive compliance requirements requiring advanced controls and monitoring.'
      },
      'monitoring': {
        1: 'Excellent: Basic monitoring with standard logging requirements.',
        2: 'Good: Standard monitoring with appropriate alerting mechanisms.',
        3: 'Moderate: Enhanced monitoring requirements with detailed logging.',
        4: 'Concerning: Comprehensive monitoring requirements with advanced alerting.',
        5: 'Critical: Extensive monitoring requirements with real-time alerting and response.'
      }
    };

    return analyses[vectorKey]?.[score] || 'Analysis not available for this score.';
  },

  // Get vector-specific recommendations
  getVectorRecommendations: function(vectorKey, score) {
    const recommendations = {
      'data-sensitivity': {
        1: ['Continue with standard data handling practices', 'Maintain data classification documentation'],
        2: ['Implement basic data protection measures', 'Regular data classification reviews'],
        3: ['Enhance data encryption and access controls', 'Implement data loss prevention measures'],
        4: ['Comprehensive data protection strategy', 'Advanced encryption and monitoring'],
        5: ['Maximum security data handling', 'Continuous monitoring and compliance validation']
      },
      'access-permissions': {
        1: ['Standard authentication mechanisms', 'Basic access logging'],
        2: ['Multi-factor authentication', 'Regular access reviews'],
        3: ['Role-based access controls', 'Enhanced authentication mechanisms'],
        4: ['Privileged access management', 'Continuous access monitoring'],
        5: ['Zero-trust access model', 'Advanced identity and access management']
      },
      'output-safety': {
        1: ['Basic content filtering', 'Standard output validation'],
        2: ['Enhanced content filtering', 'Regular filter updates'],
        3: ['Advanced content filtering', 'Real-time output monitoring'],
        4: ['Comprehensive content controls', 'Advanced safety mechanisms'],
        5: ['Maximum output safety controls', 'Continuous safety monitoring and validation']
      },
      'prompt-security': {
        1: ['Basic input validation', 'Standard prompt design'],
        2: ['Enhanced input validation', 'Prompt injection testing'],
        3: ['Advanced input sanitization', 'Regular security testing'],
        4: ['Comprehensive prompt security', 'Advanced injection protection'],
        5: ['Maximum prompt security controls', 'Continuous security monitoring']
      },
      'external-integrations': {
        1: ['Standard API security', 'Basic vendor validation'],
        2: ['Enhanced API security', 'Regular vendor assessments'],
        3: ['Comprehensive integration security', 'Advanced vendor validation'],
        4: ['Advanced integration controls', 'Continuous vendor monitoring'],
        5: ['Maximum integration security', 'Comprehensive vendor management']
      },
      'business-impact': {
        1: ['Standard deployment practices', 'Basic rollback procedures'],
        2: ['Enhanced deployment controls', 'Improved rollback mechanisms'],
        3: ['Comprehensive deployment strategy', 'Advanced rollback procedures'],
        4: ['Advanced deployment controls', 'Comprehensive impact management'],
        5: ['Maximum deployment security', 'Advanced impact mitigation strategies']
      },
      'compliance': {
        1: ['Standard compliance documentation', 'Basic audit preparation'],
        2: ['Enhanced compliance tracking', 'Regular compliance reviews'],
        3: ['Comprehensive compliance program', 'Advanced audit preparation'],
        4: ['Advanced compliance controls', 'Continuous compliance monitoring'],
        5: ['Maximum compliance assurance', 'Comprehensive compliance management']
      },
      'monitoring': {
        1: ['Standard logging practices', 'Basic alerting mechanisms'],
        2: ['Enhanced logging and monitoring', 'Improved alerting systems'],
        3: ['Comprehensive monitoring strategy', 'Advanced alerting and response'],
        4: ['Advanced monitoring controls', 'Real-time threat detection'],
        5: ['Maximum monitoring coverage', 'Advanced threat detection and response']
      }
    };

    return recommendations[vectorKey]?.[score] || ['Implement appropriate security controls for this risk level'];
  },

  // Get overall analysis
  getOverallAnalysis: function(totalScore, riskLevel) {
    if (riskLevel === 'Green') {
      return 'Your application demonstrates strong security practices with low overall risk. The assessment indicates that you have implemented appropriate security controls and are following security best practices. Continue with your current approach and maintain these security standards.';
    } else if (riskLevel === 'Amber') {
      return 'Your application shows moderate security risk that requires attention in several areas. While you have some good security practices in place, there are opportunities to strengthen your security posture. Focus on the higher-scoring vectors to reduce overall risk.';
    } else {
      return 'Your application presents significant security risks that require immediate attention and comprehensive security measures. Multiple vectors show high-risk scores indicating the need for enhanced security controls, additional review processes, and potentially architectural changes to reduce risk.';
    }
  },

  // Get overall recommendations
  getOverallRecommendations: function(totalScore, riskLevel, vectorResults) {
    const recommendations = [];
    
    if (riskLevel === 'Green') {
      recommendations.push('Maintain current security practices and continue regular security reviews');
      recommendations.push('Consider implementing additional monitoring for continuous improvement');
      recommendations.push('Document your security practices for future reference and compliance');
    } else if (riskLevel === 'Amber') {
      recommendations.push('Focus on improving the highest-scoring risk vectors first');
      recommendations.push('Implement additional security controls in moderate and high-risk areas');
      recommendations.push('Consider security architecture review for enhanced protection');
      recommendations.push('Establish regular security monitoring and review processes');
    } else {
      recommendations.push('Immediate security review and risk mitigation required');
      recommendations.push('Consider architectural changes to reduce overall risk profile');
      recommendations.push('Implement comprehensive security controls across all high-risk vectors');
      recommendations.push('Establish continuous security monitoring and incident response procedures');
      recommendations.push('Consider phased deployment approach with security validation at each phase');
    }

    // Add vector-specific recommendations for high-scoring vectors
    Object.entries(vectorResults).forEach(([vectorName, result]) => {
      if (result.score >= 4) {
        recommendations.push(`${vectorName}: Implement enhanced security controls due to high risk score`);
      }
    });

    return recommendations;
  },

  // Determine risk level based on score
  getRiskLevel: function(score, maxScore) {
    const percentage = (score / maxScore) * 100;
    if (percentage <= 40) return 'Green';
    if (percentage <= 70) return 'Amber';
    return 'Red';
  },

  // Get overall risk level for 40-point scale
  getOverallRiskLevel: function(totalScore) {
    if (totalScore <= 16) return 'Green';   // Low risk (0-16 out of 40)
    if (totalScore <= 28) return 'Amber';   // Medium risk (17-28 out of 40)
    return 'Red';                           // High risk (29-40 out of 40)
  },

  // Get risk description
  getRiskDescription: function(riskLevel) {
    const descriptions = {
      'Green': 'Low risk - Your application follows security best practices with minimal additional requirements',
      'Amber': 'Medium risk - Some additional security controls and review may be required',
      'Red': 'High risk - Comprehensive security review and additional controls required before deployment'
    };
    return descriptions[riskLevel] || 'Unknown risk level';
  },

  // Check platform-data compatibility
  checkCompatibility: function(platform, dataType) {
    return this.PLATFORM_DATA_MATRIX[platform]?.[dataType] || {
      status: 'unknown',
      note: 'Compatibility information not available',
      details: 'Please consult security team for guidance',
      examples: [],
      requirements: ['Manual review required'],
      timeline: 'To be determined'
    };
  },

  // Generate PDF content
  generatePDFContent: function(assessmentData, results) {
    const timestamp = new Date().toLocaleString();
    
    return `
# SaferAI Security Assessment Report

**Generated:** ${timestamp}
**Project:** ${assessmentData.projectName || 'Unnamed Project'}
**Type:** ${assessmentData.projectType || 'Not specified'}
**Platform:** ${assessmentData.platform || 'Not specified'}

## Executive Summary

**Overall Risk Score:** ${results.totalScore}/${results.maxPossibleScore} (${results.riskLevel})
**Risk Level:** ${results.riskLevel}
**Description:** ${results.riskDescription}

${results.overallAnalysis}

## Risk Vector Analysis

${Object.entries(results.vectorResults).map(([vectorName, result]) => `
### ${vectorName}
- **Score:** ${result.score}/5 (${result.riskLevel})
- **Analysis:** ${result.analysis}
- **Recommendations:**
${result.recommendations.map(rec => `  - ${rec}`).join('\n')}
`).join('\n')}

## Overall Recommendations

${results.recommendations.map(rec => `- ${rec}`).join('\n')}

## Project Details

**Business Justification:** ${assessmentData.businessJustification || 'Not provided'}
**Requestor:** ${assessmentData.requestorName || 'Not provided'}
**Email:** ${assessmentData.requestorEmail || 'Not provided'}
**Business Unit:** ${assessmentData.businessUnit || 'Not provided'}

## Platform-Data Compatibility

${assessmentData.platform && assessmentData.dataTypes ? 
  assessmentData.dataTypes.map(dataType => {
    const compatibility = this.checkCompatibility(assessmentData.platform, dataType);
    return `
**${dataType.toUpperCase()} Data:**
- Status: ${compatibility.status.toUpperCase()}
- Note: ${compatibility.note}
- Requirements: ${compatibility.requirements.join(', ')}
- Timeline: ${compatibility.timeline}
`;
  }).join('\n') : 'Platform and data type information not available'}

## Next Steps

Based on this assessment, the following next steps are recommended:

1. **Review Results:** Carefully review all risk vectors and recommendations
2. **Implement Controls:** Focus on high-risk areas requiring immediate attention
3. **Security Review:** ${results.riskLevel === 'Red' ? 'Mandatory comprehensive security review required' : 
   results.riskLevel === 'Amber' ? 'Security review recommended for moderate-risk areas' : 
   'Standard security review process'}
4. **Documentation:** Maintain comprehensive documentation of security controls
5. **Monitoring:** Implement appropriate monitoring and alerting mechanisms

---

*This assessment was generated by the SaferAI Portal and should be reviewed by qualified security professionals.*
`;
  }
};

export default SaferAIScoringEngine;


// Export helper functions for new components
export const getRiskLevel = (score, type = 'review') => {
  if (type === 'prompt') {
    // Prompt risk: 0-40 points
    if (score <= 10) return { level: 'Low', color: '#28a745', emoji: '🟢' };
    if (score <= 25) return { level: 'Medium', color: '#ffc107', emoji: '🟡' };
    return { level: 'High', color: '#dc3545', emoji: '🔴' };
  } else {
    // Concept/Product risk: 0-40 points
    if (score <= 16) return { level: 'Low', color: '#28a745', emoji: '🟢' };
    if (score <= 28) return { level: 'Medium', color: '#ffc107', emoji: '🟡' };
    return { level: 'High', color: '#dc3545', emoji: '🔴' };
  }
};

export const getRecommendedAction = (score, type = 'review') => {
  const risk = getRiskLevel(score, type);
  
  if (type === 'prompt') {
    if (risk.level === 'Low') return 'Safe to deploy';
    if (risk.level === 'Medium') return 'TT for prompt improvement';
    return 'Raise SIM before deployment';
  } else {
    if (risk.level === 'Low') return type === 'concept' ? 'Safe to proceed' : 'Safe to deploy';
    if (risk.level === 'Medium') return type === 'concept' ? 'File TT for visibility' : 'File TT before launch';
    return type === 'concept' ? 'Raise SIM before build' : 'Raise SIM; block deployment';
  }
};

export const calculateScore = (answers) => {
  return Object.values(answers).reduce((sum, score) => sum + (score || 0), 0);
};
