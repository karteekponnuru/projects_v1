// Questions with guidance - see earlier version created
// This file contains CONCEPT_QUESTIONS and PRODUCT_QUESTIONS with guidance and examples
// Copy from the earlier created version or use the template below

export const CONCEPT_QUESTIONS = {
  // Add all 8 concept questions with guidance field
};

export const PRODUCT_QUESTIONS = {
  // Add all 8 product questions with guidance field
};

export const PLATFORMS = [
  'PartyRock',
  'Amazon Q Business',
  'Bedrock Playground',
  'Approved Chatbots (Cedric, Mentor, Field Advisor)',
  'Custom Bedrock Integration',
  'Other (specify in description)'
];

export const DEVELOPMENT_TYPES = [
  { value: 'low-code', label: 'Low Code (PartyRock, Q Business, No-Code Tools)' },
  { value: 'high-code', label: 'High Code (Custom Bedrock, Lambda, Full Development)' }
];
