# SaferAI Portal - Key Modifications Package

## 🎯 What's New

This package contains the **completely redesigned** SaferAI Portal with:

### 1. ✅ New HomePage with Compass Assistant
- **Compass** - Your conversational SaferAI assistant
- Guides developers through policy, data access, and platform decisions
- Natural conversation flow with contextual responses
- Automatically routes to Concept or Product Review when ready
- Suggests raising Asana SIM for complex cases

### 2. ✅ Advanced PDF Generator
- Professional formatting with tables and color coding
- Proper risk level visualization
- All new form fields included
- Footer: **© TSE CTOSS <> Product Initiative**
- Multi-page support with page numbers
- NOT a screenshot - real PDF generation with jsPDF

## 📦 Files Included

```
saferai-modifications/
├── pages/
│   └── HomePage.jsx          ← NEW: Compass assistant interface
├── lib/
│   ├── pdfGenerator.js       ← NEW: Advanced PDF with proper formatting
│   └── scoringEngine.js      ← Existing (no changes needed)
└── data/
    └── questions.js          ← Template (add guidance fields)
```

## 🚀 Installation

### Step 1: Backup Your Files
```bash
cd your-saferai-portal
cp src/pages/HomePage.jsx src/pages/HomePage.jsx.backup
cp src/lib/pdfGenerator.js src/lib/pdfGenerator.js.backup
```

### Step 2: Copy New Files
```bash
# Copy HomePage
cp saferai-modifications/pages/HomePage.jsx your-portal/src/pages/

# Copy PDF Generator
cp saferai-modifications/lib/pdfGenerator.js your-portal/src/lib/
```

### Step 3: Install Dependencies
```bash
npm install jspdf jspdf-autotable
# or
pnpm add jspdf jspdf-autotable
```

### Step 4: Test
```bash
npm run dev
```

## 🎨 What You'll See

### HomePage - Compass Assistant

When users visit the homepage, they see:

**Compass Avatar** 🧭  
*"Hi! I'm Compass, your SaferAI assistant. I'm here to help you build AI agents safely and compliantly. How can I help you today?"*

**4 Initial Options:**
- What can I build according to policy?
- What data can my agent access?
- Which platform should I use?
- I'm ready to start a review

**Conversational Flow:**
- User clicks an option
- Compass provides detailed guidance
- New options appear based on context
- Eventually routes to Concept or Product Review
- For complex cases, suggests raising Asana SIM

### PDF Output

**Professional Format:**
- Header with SaferAI branding
- Risk badge (color-coded)
- Project information table with ALL fields including:
  - Project Name
  - Description
  - Platform
  - Requestor Login
  - Requestor Org
  - Direct Manager
  - L6 Sponsor
  - L7 Sponsor
- Risk assessment table with color-coded levels
- Overall risk summary box
- Detailed recommendations
- Footer: © TSE CTOSS <> Product Initiative

## 📝 Still TODO

### Add New Form Fields to Review Pages

You still need to add these fields to **ConceptReviewPage.jsx** and **ProductReviewPage.jsx**:

```jsx
// In formData state
const [formData, setFormData] = useState({
  projectName: '',
  description: '',
  platform: '',
  requestorLogin: '',      // ADD
  requestorOrg: '',        // ADD
  directManager: '',       // ADD
  l6Sponsor: '',           // ADD
  l7Sponsor: '',           // ADD
  // ... rest of fields
});

// In form UI
<label>Requestor Login *</label>
<input
  type="text"
  value={formData.requestorLogin}
  onChange={(e) => setFormData({...formData, requestorLogin: e.target.value})}
  required
/>

<label>Requestor Organization *</label>
<input
  type="text"
  value={formData.requestorOrg}
  onChange={(e) => setFormData({...formData, requestorOrg: e.target.value})}
  required
/>

<label>Direct Manager *</label>
<input
  type="text"
  value={formData.directManager}
  onChange={(e) => setFormData({...formData, directManager: e.target.value})}
  required
/>

<label>L6 Sponsor</label>
<input
  type="text"
  value={formData.l6Sponsor}
  onChange={(e) => setFormData({...formData, l6Sponsor: e.target.value})}
/>

<label>L7 Sponsor</label>
<input
  type="text"
  value={formData.l7Sponsor}
  onChange={(e) => setFormData({...formData, l7Sponsor: e.target.value})}
/>
```

### Add Guidance Tooltips

For each risk vector question, add a tooltip:

```jsx
<h3>
  {question.title}
  <span className="tooltip" style={{marginLeft: '10px', cursor: 'help'}}>
    ❓
    <span className="tooltiptext">
      <strong>Guidance:</strong> {question.guidance}
      <br/><br/>
      <strong>Example:</strong> {question.examples}
    </span>
  </span>
</h3>
```

Add to your CSS:
```css
.tooltip {
  position: relative;
  display: inline-block;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 300px;
  background-color: #232f3e;
  color: #fff;
  padding: 12px;
  border-radius: 8px;
  position: absolute;
  z-index: 1000;
  bottom: 125%;
  left: 50%;
  margin-left: -150px;
  opacity: 0;
  transition: opacity 0.3s;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}
```

## ✨ Key Features

**Compass Assistant:**
- Conversational guidance on policies
- Platform recommendations
- Data access rules
- Routes to appropriate review type
- Suggests Asana SIM for complex cases

**Advanced PDF:**
- Real PDF generation (not screenshot)
- Professional tables and formatting
- Color-coded risk levels
- All form fields included
- Amazon branding footer

## 🧪 Testing Checklist

- [ ] HomePage loads with Compass interface
- [ ] Can click through conversation options
- [ ] Eventually shows Concept/Product Review buttons
- [ ] Concept Review form has all new fields
- [ ] Product Review form has all new fields
- [ ] PDF generates with proper formatting
- [ ] PDF includes all form fields
- [ ] PDF footer shows © TSE CTOSS <> Product Initiative
- [ ] Tooltips appear on question hover

## 📧 Support

Questions? Contact:
- Email: swat-team@amazon.com
- Slack: #ctoss-swat

---

**Note:** This package provides the core new features (Compass assistant and advanced PDF). You'll need to add the form fields and tooltips to your review pages following the instructions above.
