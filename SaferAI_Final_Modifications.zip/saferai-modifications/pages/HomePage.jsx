import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const [messages, setMessages] = useState([
    {
      type: 'assistant',
      text: "Hi! I'm Compass, your SaferAI assistant. I'm here to help you build AI agents safely and compliantly. How can I help you today?"
    }
  ]);
  const [showReviewButtons, setShowReviewButtons] = useState(false);
  const [currentOptions, setCurrentOptions] = useState([
    { id: 'policy', text: "What can I build according to policy?" },
    { id: 'data', text: "What data can my agent access?" },
    { id: 'platform', text: "Which platform should I use?" },
    { id: 'ready', text: "I'm ready to start a review" }
  ]);

  const handleOptionClick = (optionId) => {
    let userMessage = currentOptions.find(opt => opt.id === optionId)?.text;
    let assistantResponse = '';
    let newOptions = [];

    switch(optionId) {
      case 'policy':
        assistantResponse = "Great question! According to Amazon's AI policy, you can build agents that:\n\n• Automate repetitive tasks (ticket tagging, summarization)\n• Provide insights and recommendations\n• Generate draft content for human review\n\nYou CANNOT build agents that:\n• Make autonomous decisions affecting customers\n• Access sensitive data without proper review\n• Bypass existing approval workflows\n\nWould you like to know more about a specific use case?";
        newOptions = [
          { id: 'data', text: "Tell me about data access rules" },
          { id: 'platform', text: "Which platform should I use?" },
          { id: 'ready', text: "I'm ready to start a review" }
        ];
        break;

      case 'data':
        assistantResponse = "Data access depends on sensitivity:\n\n🟢 LOW RISK: Test data, public information, internal wikis\n🟡 MEDIUM RISK: Employee data, customer metadata (IDs, summaries)\n🔴 HIGH RISK: Customer content (emails, chats), PII, credentials\n\nFor HIGH RISK data:\n• You MUST complete a SaferAI review\n• May need SWAT approval\n• Requires comprehensive logging\n\nWhat type of data will your agent use?";
        newOptions = [
          { id: 'low-data', text: "Only test/internal data" },
          { id: 'medium-data', text: "Customer metadata" },
          { id: 'high-data', text: "Customer content or PII" },
          { id: 'ready', text: "I'm ready to start a review" }
        ];
        break;

      case 'platform':
        assistantResponse = "Here are your platform options:\n\n🎯 PartyRock: Best for quick prototypes, no coding required\n🤖 Amazon Q Business: Enterprise chatbots with built-in security\n🔬 Bedrock Playground: Testing and experimentation\n💬 Approved Chatbots: Cedric, Mentor, Field Advisor for specific use cases\n⚙️ Custom Bedrock: Full control, requires development\n\nFor most use cases, start with PartyRock or Q Business. Need custom integration? Use Bedrock with Lambda.\n\nWhat's your use case?";
        newOptions = [
          { id: 'prototype', text: "Just prototyping an idea" },
          { id: 'production', text: "Building for production use" },
          { id: 'ready', text: "I'm ready to start a review" }
        ];
        break;

      case 'low-data':
        assistantResponse = "Perfect! Low-risk data means you can move quickly. I recommend:\n\n1. Start with a Concept Review to document your plan\n2. Build on PartyRock or Q Business\n3. Add basic logging\n4. Complete a Product Review before going live\n\nReady to begin?";
        newOptions = [
          { id: 'ready', text: "Yes, start Concept Review" }
        ];
        break;

      case 'medium-data':
        assistantResponse = "Medium-risk data requires more care:\n\n1. Complete a Concept Review FIRST\n2. Implement comprehensive logging (CloudWatch)\n3. Limit access to specific APIs only\n4. Add human review for outputs\n5. Complete Product Review before deployment\n\nYou may need to file a TT for visibility. Ready to start?";
        newOptions = [
          { id: 'ready', text: "Yes, start Concept Review" },
          { id: 'complex', text: "This seems complex, I need help" }
        ];
        break;

      case 'high-data':
        assistantResponse = "⚠️ HIGH RISK - This requires careful planning:\n\n1. STOP - Complete Concept Review FIRST\n2. You'll likely need SWAT approval\n3. Must implement:\n   • Full audit logging\n   • Data encryption\n   • Access controls\n   • Error handling\n4. May need to raise a SIM\n\nI strongly recommend consulting with SWAT before proceeding. Would you like to raise a consultation request?";
        newOptions = [
          { id: 'complex', text: "Yes, I need SWAT consultation" },
          { id: 'ready', text: "I understand, start Concept Review" }
        ];
        break;

      case 'prototype':
        assistantResponse = "For prototyping, use PartyRock!\n\n✅ No coding required\n✅ Quick to build\n✅ Safe sandbox environment\n✅ Easy to share with team\n\nJust remember: Even prototypes need a Concept Review if they'll access real data. Ready to document your concept?";
        newOptions = [
          { id: 'ready', text: "Yes, start Concept Review" }
        ];
        break;

      case 'production':
        assistantResponse = "Production deployments need thorough review:\n\n1. Complete Concept Review\n2. Build with proper architecture\n3. Implement logging and monitoring\n4. Complete Product Review\n5. Get necessary approvals\n\nDepending on your risk level, you may need SWAT sign-off. Let's start with a Concept Review to assess your risk.";
        newOptions = [
          { id: 'ready', text: "Start Concept Review" }
        ];
        break;

      case 'complex':
        assistantResponse = "No problem! For complex use cases or if you need expert guidance, please raise a consultation SIM on Asana.\n\n📋 To raise a SIM:\n1. Go to Asana\n2. Create new task in SWAT project\n3. Tag it as 'AI Consultation'\n4. Include your use case details\n\nThe SWAT team will respond within 1-2 business days. In the meantime, you can still start a Concept Review to document your idea.";
        newOptions = [
          { id: 'ready', text: "Okay, start Concept Review anyway" }
        ];
        break;

      case 'ready':
        assistantResponse = "Excellent! Let's get started.\n\n🎯 Concept Review: Use this BEFORE you build anything. It helps you understand if your idea is safe and what approvals you need.\n\n🚀 Product Review: Use this AFTER you've built something and are ready to deploy. It validates your implementation meets security standards.\n\nWhich one do you need?";
        setShowReviewButtons(true);
        newOptions = [];
        break;

      default:
        assistantResponse = "I'm not sure about that. Let me help you get started with the right review process.";
        newOptions = [
          { id: 'policy', text: "What can I build according to policy?" },
          { id: 'data', text: "What data can my agent access?" },
          { id: 'platform', text: "Which platform should I use?" },
          { id: 'ready', text: "I'm ready to start a review" }
        ];
    }

    setMessages([...messages, 
      { type: 'user', text: userMessage },
      { type: 'assistant', text: assistantResponse }
    ]);
    setCurrentOptions(newOptions);
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.title}>SaferAI Portal</h1>
        <p style={styles.subtitle}>Build AI agents safely and compliantly</p>
      </div>

      <div style={styles.chatContainer}>
        <div style={styles.chatHeader}>
          <div style={styles.avatarContainer}>
            <div style={styles.avatar}>🧭</div>
            <div>
              <div style={styles.assistantName}>Compass</div>
              <div style={styles.assistantTitle}>Your SaferAI Assistant</div>
            </div>
          </div>
        </div>

        <div style={styles.messagesContainer}>
          {messages.map((msg, idx) => (
            <div key={idx} style={msg.type === 'user' ? styles.userMessage : styles.assistantMessage}>
              {msg.type === 'assistant' && <span style={styles.messageAvatar}>🧭</span>}
              <div style={msg.type === 'user' ? styles.userBubble : styles.assistantBubble}>
                {msg.text}
              </div>
              {msg.type === 'user' && <span style={styles.messageAvatar}>👤</span>}
            </div>
          ))}

          {currentOptions.length > 0 && (
            <div style={styles.optionsContainer}>
              {currentOptions.map(option => (
                <button
                  key={option.id}
                  onClick={() => handleOptionClick(option.id)}
                  style={styles.optionButton}
                >
                  {option.text}
                </button>
              ))}
            </div>
          )}

          {showReviewButtons && (
            <div style={styles.reviewButtonsContainer}>
              <Link to="/concept-review" style={styles.reviewButton}>
                <div style={styles.reviewButtonIcon}>🎯</div>
                <div style={styles.reviewButtonTitle}>Concept Review</div>
                <div style={styles.reviewButtonDesc}>Before you build</div>
              </Link>
              <Link to="/product-review" style={styles.reviewButton}>
                <div style={styles.reviewButtonIcon}>🚀</div>
                <div style={styles.reviewButtonTitle}>Product Review</div>
                <div style={styles.reviewButtonDesc}>After you build</div>
              </Link>
            </div>
          )}
        </div>
      </div>

      <div style={styles.footer}>
        <p>Need more help? Contact SWAT team at <a href="mailto:swat-team@amazon.com">swat-team@amazon.com</a> or Slack: #ctoss-swat</p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    padding: '40px 20px'
  },
  header: {
    textAlign: 'center',
    marginBottom: '40px',
    color: 'white'
  },
  title: {
    fontSize: '48px',
    fontWeight: '800',
    marginBottom: '10px',
    textShadow: '2px 2px 4px rgba(0,0,0,0.2)'
  },
  subtitle: {
    fontSize: '20px',
    opacity: 0.9
  },
  chatContainer: {
    maxWidth: '800px',
    margin: '0 auto',
    backgroundColor: 'white',
    borderRadius: '20px',
    boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
    overflow: 'hidden'
  },
  chatHeader: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    padding: '20px',
    color: 'white'
  },
  avatarContainer: {
    display: 'flex',
    alignItems: 'center',
    gap: '15px'
  },
  avatar: {
    width: '50px',
    height: '50px',
    borderRadius: '50%',
    backgroundColor: 'white',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '24px'
  },
  assistantName: {
    fontSize: '20px',
    fontWeight: '700'
  },
  assistantTitle: {
    fontSize: '14px',
    opacity: 0.9
  },
  messagesContainer: {
    padding: '30px',
    minHeight: '400px',
    maxHeight: '600px',
    overflowY: 'auto'
  },
  userMessage: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
    marginBottom: '20px',
    gap: '10px'
  },
  assistantMessage: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    marginBottom: '20px',
    gap: '10px'
  },
  messageAvatar: {
    fontSize: '24px',
    flexShrink: 0
  },
  userBubble: {
    backgroundColor: '#667eea',
    color: 'white',
    padding: '15px 20px',
    borderRadius: '20px 20px 5px 20px',
    maxWidth: '70%',
    lineHeight: '1.6',
    whiteSpace: 'pre-line'
  },
  assistantBubble: {
    backgroundColor: '#f0f0f0',
    color: '#333',
    padding: '15px 20px',
    borderRadius: '20px 20px 20px 5px',
    maxWidth: '70%',
    lineHeight: '1.6',
    whiteSpace: 'pre-line'
  },
  optionsContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginTop: '20px',
    marginLeft: '34px'
  },
  optionButton: {
    backgroundColor: 'white',
    border: '2px solid #667eea',
    color: '#667eea',
    padding: '15px 20px',
    borderRadius: '12px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    textAlign: 'left',
    fontFamily: 'Inter, sans-serif'
  },
  reviewButtonsContainer: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '20px',
    marginTop: '30px'
  },
  reviewButton: {
    backgroundColor: 'white',
    border: '3px solid #667eea',
    borderRadius: '16px',
    padding: '30px',
    textAlign: 'center',
    textDecoration: 'none',
    transition: 'all 0.3s ease',
    cursor: 'pointer'
  },
  reviewButtonIcon: {
    fontSize: '48px',
    marginBottom: '10px'
  },
  reviewButtonTitle: {
    fontSize: '24px',
    fontWeight: '700',
    color: '#333',
    marginBottom: '5px'
  },
  reviewButtonDesc: {
    fontSize: '14px',
    color: '#666'
  },
  footer: {
    textAlign: 'center',
    marginTop: '40px',
    color: 'white',
    fontSize: '14px'
  }
};

export default HomePage;
