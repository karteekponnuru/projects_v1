import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, ExternalLink, HelpCircle, Info, AlertCircle } from 'lucide-react';
import { generateSaferAIPDF } from '@/lib/pdfGenerator.js';
import { PLATFORMS, checkCompatibility, mapDataCategory, getDataCategoryInfo } from '@/lib/compatibilityMatrix.js';
import { getTooltip, getPreflightHelp, getDataMappingHelp } from '@/lib/tooltips.js';

const SWAT_ASANA_URL = 'https://asana.amazon.com/create?project=SWAT_Consultations';

const Tooltip = ({ content }) => (
  <div className="inline-block ml-2 group relative">
    <HelpCircle className="h-4 w-4 text-gray-400 cursor-help" />
    <div className="hidden group-hover:block absolute z-50 w-72 p-3 bg-gray-900 text-white text-sm rounded-lg shadow-lg -left-32 top-6">
      <div className="font-semibold mb-1">{content.title}</div>
      <div className="mb-2">{content.content}</div>
      {content.example && (
        <div className="text-xs text-gray-300 mt-2">
          <span className="font-semibold">Example:</span> {content.example}
        </div>
      )}
      {content.why && (
        <div className="text-xs text-gray-300 mt-1">
          <span className="font-semibold">Why we ask:</span> {content.why}
        </div>
      )}
    </div>
  </div>
);

const ConceptReview = () => {
  const [currentStep, setCurrentStep] = useState(1); // 1: preflight, 2: details, 3: data, 4: questions
  const [preflightAnswers, setPreflightAnswers] = useState({});
  const [showHighRiskWarning, setShowHighRiskWarning] = useState(false);
  
  const [formData, setFormData] = useState({
    projectName: '',
    developer: '',
    org: '',
    loginId: '',
    date: new Date().toISOString().split('T')[0],
    goal: '',
    devType: '',
    stage: '',
    platform: '',
    platformOther: '',
    teamSize: '',
    intendedOutput: '',
    expectedIntegrations: '',
    otherDetails: ''
  });

  const [dataAnswers, setDataAnswers] = useState({});
  const [mappedDataCategory, setMappedDataCategory] = useState('');
  const [compatibilityCheck, setCompatibilityCheck] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [riskScore, setRiskScore] = useState(0);
  const [normalizedScore, setNormalizedScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');

  // Check compatibility when platform or data category changes
  useEffect(() => {
    if (formData.platform && mappedDataCategory) {
      const result = checkCompatibility(formData.platform, mappedDataCategory);
      setCompatibilityCheck(result);
    }
  }, [formData.platform, mappedDataCategory]);

  // Map data category when answers change
  useEffect(() => {
    const category = mapDataCategory(dataAnswers);
    setMappedDataCategory(category);
  }, [dataAnswers]);

  // Check preflight for high-risk indicators
  useEffect(() => {
    const highRisk = 
      preflightAnswers.customerData === 'yes' ||
      preflightAnswers.elevatedAccess === 'yes' ||
      preflightAnswers.externalIntegration === 'yes';
    setShowHighRiskWarning(highRisk);
  }, [preflightAnswers]);

  const questions = [
    {
      category: 'A. Data Sensitivity',
      description: 'What type of data will your agent use?',
      items: [
        {
          id: 'data_type',
          question: 'Which data types will your concept interact with?',
          options: [
            { text: 'Public/mock', score: 0 },
            { text: 'Internal', score: 1 },
            { text: 'Business/Partner', score: 2 },
            { text: 'AWS Support', score: 3 },
            { text: 'Customer/PII', score: 5 }
          ]
        },
        {
          id: 'customer_data',
          question: 'Does your idea process or derive insights from customer-linked data?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'B. Access Permissions',
      description: 'How deep does your tool go?',
      items: [
        {
          id: 'access_level',
          question: 'What kind of access will your solution need?',
          options: [
            { text: 'None', score: 0 },
            { text: 'Basic read', score: 2 },
            { text: 'Write/update', score: 3 },
            { text: 'Elevated/system', score: 5 }
          ]
        },
        {
          id: 'api_interaction',
          question: 'Will it interact with dashboards, APIs, or case data?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Internal only', score: 2 },
            { text: 'External or cross-tenant', score: 4 }
          ]
        }
      ]
    },
    {
      category: 'C. Output Safety',
      description: 'What does your agent produce, and who sees it?',
      items: [
        {
          id: 'output_visibility',
          question: 'Where will the outputs be visible?',
          options: [
            { text: 'Team-only', score: 1 },
            { text: 'Cross-org', score: 3 },
            { text: 'Public/External', score: 5 }
          ]
        },
        {
          id: 'auto_generated',
          question: 'Are outputs auto-generated without human review?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes', score: 3 },
            { text: 'Yes, and shared externally', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'D. Prompt Security',
      description: 'How flexible are user inputs?',
      items: [
        {
          id: 'free_text_prompts',
          question: 'Will users enter free text prompts?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Partially', score: 2 },
            { text: 'Yes', score: 4 }
          ]
        },
        {
          id: 'prompt_exposure',
          question: 'Could prompts expose internal data or credentials?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Likely', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'E. External Integrations',
      description: 'Does it talk to anything beyond Amazon systems?',
      items: [
        {
          id: 'external_services',
          question: 'Are there integrations with non-AWS services?',
          options: [
            { text: 'None', score: 0 },
            { text: 'Internal APIs only', score: 2 },
            { text: 'Slack/Sheets/Email/Other 3P', score: 4 }
          ]
        },
        {
          id: 'external_data',
          question: 'Does your idea send or store data externally?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Occasionally', score: 2 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'F. Business Impact',
      description: 'What happens if something goes wrong?',
      items: [
        {
          id: 'criticality',
          question: 'How critical is this to daily operations?',
          options: [
            { text: 'Low', score: 1 },
            { text: 'Medium', score: 3 },
            { text: 'High', score: 5 }
          ]
        },
        {
          id: 'incorrect_outputs',
          question: 'Would incorrect outputs create customer or business risk?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'G. Compliance & Monitoring',
      description: 'Can your project be traced and verified later?',
      items: [
        {
          id: 'logging',
          question: 'Are logs or activity histories maintained?',
          options: [
            { text: 'Full logs', score: 0 },
            { text: 'Partial logs', score: 2 },
            { text: 'No logs', score: 5 }
          ]
        },
        {
          id: 'project_owner',
          question: 'Is there a clearly identified project owner?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Not yet', score: 3 }
          ]
        }
      ]
    },
    {
      category: 'H. Future Scaling & Governance',
      description: 'Could this grow beyond its initial scope?',
      items: [
        {
          id: 'scaling',
          question: 'Do you expect this to scale across multiple orgs?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Later', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        },
        {
          id: 'permission_increase',
          question: 'Will permissions or data exposure increase as it scales?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 2 },
            { text: 'Yes', score: 4 }
          ]
        }
      ]
    }
  ];

  const preflightHelp = getPreflightHelp();
  const dataMappingHelp = getDataMappingHelp();

  const calculateRisk = () => {
    let totalScore = 0;
    Object.values(answers).forEach(answer => {
      totalScore += answer.score;
    });
    
    setRiskScore(totalScore);
    const normalized = Math.round(totalScore / 2);
    setNormalizedScore(normalized);
    
    if (normalized <= 16) {
      setRiskZone('green');
    } else if (normalized <= 28) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateRisk();
    setSubmitted(true);
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleAnswer = (questionId, optionIndex) => {
    const allQuestions = questions.flatMap(cat => cat.items);
    const question = allQuestions.find(q => q.id === questionId);
    setAnswers({
      ...answers,
      [questionId]: {
        answer: question.options[optionIndex].text,
        score: question.options[optionIndex].score
      }
    });
  };

  const downloadPDF = async () => {
    const zoneDetails = getRiskZoneDetails();
    const dataInfo = getDataCategoryInfo(mappedDataCategory);
    
    const pdfData = {
      projectName: formData.projectName,
      developer: formData.developer,
      org: formData.org,
      loginId: formData.loginId,
      platform: PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform,
      date: formData.date,
      stage: formData.stage,
      devType: formData.devType,
      zone: zoneDetails.title,
      score: normalizedScore,
      maxScore: 40,
      findings: [
        `Raw Score: ${riskScore}/80`,
        `Data Category: ${dataInfo.label}`,
        `Platform: ${PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform}`,
        `Compatibility: ${compatibilityCheck?.compatible ? 'Compatible' : 'Incompatible'}`,
        `Access Level: ${answers.access_level?.answer || 'N/A'}`,
        `Output Visibility: ${answers.output_visibility?.answer || 'N/A'}`
      ],
      suggestions: zoneDetails.nextSteps
    };

    await generateSaferAIPDF(pdfData, 'concept');
  };

  const getRiskZoneDetails = () => {
    const zones = {
      green: {
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        title: 'Green Zone – Ready to Build',
        color: 'bg-green-50 border-green-200',
        message: 'Safe concept; minimal risk. Your concept aligns with policy and approved use cases. You can proceed to development.',
        nextSteps: [
          'Document your implementation plan',
          'Begin development with approved tools',
          'Plan for Product Review after completion',
          'Ensure proper logging and monitoring',
          'Set up regular review cycles'
        ]
      },
      amber: {
        icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
        title: 'Amber Zone – Design with Care',
        color: 'bg-yellow-50 border-yellow-200',
        message: 'Acceptable risk; refine before scaling. Some parameters need validation before full deployment.',
        nextSteps: [
          'Review data sources and ensure proper classification',
          'Validate integration security measures',
          'Consider adding monitoring and logging',
          'Add human review checkpoints for outputs',
          'Resubmit after adjustments',
          'Document security considerations'
        ]
      },
      red: {
        icon: <XCircle className="h-16 w-16 text-red-600" />,
        title: 'Red Zone – Needs Rework',
        color: 'bg-red-50 border-red-200',
        message: 'High exposure; adjust data or scope. Your concept involves restricted data or high-risk operations. SWAT consultation required.',
        nextSteps: [
          'Prepare detailed documentation of your use case',
          'Schedule SWAT consultation immediately',
          'Review alternative approaches',
          'Consider using approved data types',
          'Do not proceed without SWAT approval',
          'Document all security concerns and mitigations'
        ]
      }
    };
    return zones[riskZone] || zones.green;
  };

  const getProgressPercentage = () => {
    const totalQuestions = questions.flatMap(cat => cat.items).length;
    const answeredQuestions = Object.keys(answers).length;
    return Math.round((answeredQuestions / totalQuestions) * 100);
  };

  const generateSwatUrl = () => {
    const zoneDetails = getRiskZoneDetails();
    const dataInfo = getDataCategoryInfo(mappedDataCategory);
    const platformLabel = PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform;
    
    const notes = `
SaferAI Concept Review Submission

Project: ${formData.projectName}
Developer: ${formData.developer} (${formData.loginId})
Organization: ${formData.org}
Date: ${formData.date}

Platform: ${platformLabel}
Data Category: ${dataInfo.label}
Development Stage: ${formData.stage}
Type: ${formData.devType}

Risk Assessment:
- Zone: ${zoneDetails.title}
- Score: ${normalizedScore}/40 (Raw: ${riskScore}/80)
- Compatibility: ${compatibilityCheck?.compatible ? 'Compatible' : compatibilityCheck?.message || 'Unknown'}

Goal: ${formData.goal}

Key Findings:
${Object.entries(answers).slice(0, 5).map(([key, val]) => `- ${key}: ${val.answer} (${val.score} pts)`).join('\n')}

This project requires SWAT review due to ${riskZone === 'red' ? 'high-risk factors' : 'elevated risk score'}.
    `.trim();

    return `${SWAT_ASANA_URL}&name=${encodeURIComponent(formData.projectName + ' - Concept Review')}&notes=${encodeURIComponent(notes)}`;
  };

  if (submitted) {
    const zoneDetails = getRiskZoneDetails();
    const dataInfo = getDataCategoryInfo(mappedDataCategory);
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review Results</p>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-8 py-12">
          <Card className={`border-2 ${zoneDetails.color} mb-8`}>
            <CardHeader>
              <div className="flex items-center gap-4">
                {zoneDetails.icon}
                <div>
                  <CardTitle className="text-2xl mb-2">{zoneDetails.title}</CardTitle>
                  <p className="text-gray-700">{zoneDetails.message}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-2">Risk Score: {normalizedScore} / 40</h3>
                <p className="text-sm text-gray-600 mb-2">(Raw Score: {riskScore} / 80)</p>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full ${
                      riskZone === 'green' ? 'bg-green-500' :
                      riskZone === 'amber' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(normalizedScore / 40) * 100}%` }}
                  ></div>
                </div>
              </div>

              {compatibilityCheck && (
                <div className="mb-6">
                  <Alert className={compatibilityCheck.compatible ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                    <AlertDescription>
                      <div className="flex items-start gap-2">
                        {compatibilityCheck.compatible ? (
                          <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-600 mt-0.5" />
                        )}
                        <div>
                          <p className="font-semibold mb-1">Platform & Data Compatibility</p>
                          <p className="text-sm">{compatibilityCheck.message}</p>
                          {compatibilityCheck.suggestions && compatibilityCheck.suggestions.length > 0 && (
                            <div className="mt-2">
                              <p className="text-sm font-semibold">Suggested alternatives:</p>
                              <ul className="text-sm mt-1 space-y-1">
                                {compatibilityCheck.suggestions.map((sug, idx) => (
                                  <li key={idx}>• {sug.platform} - {sug.description}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                </div>
              )}

              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3">Next Steps:</h3>
                <ul className="space-y-2">
                  {zoneDetails.nextSteps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#FF9900] mt-1">•</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-4 flex-wrap">
                <Button onClick={downloadPDF} className="bg-[#232F3E] hover:bg-[#1a2332]">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF Report
                </Button>
                <a href={generateSwatUrl()} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Submit to SWAT
                  </Button>
                </a>
                <Button onClick={() => { setSubmitted(false); setCurrentStep(1); }} variant="outline">
                  Start New Review
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Concept Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold text-sm text-gray-600">Project Name</p>
                  <p className="text-lg">{formData.projectName}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Developer</p>
                  <p className="text-lg">{formData.developer}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Organization</p>
                  <p className="text-lg">{formData.org}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Platform</p>
                  <p className="text-lg">{PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Data Category</p>
                  <p className="text-lg">{dataInfo.label}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Stage</p>
                  <p className="text-lg">{formData.stage}</p>
                </div>
              </div>
              {formData.goal && (
                <div className="mt-4">
                  <p className="font-semibold text-sm text-gray-600">Goal / Problem Statement</p>
                  <p className="text-base">{formData.goal}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Score Breakdown by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {questions.map((category, idx) => {
                  const categoryScore = category.items.reduce((sum, item) => {
                    return sum + (answers[item.id]?.score || 0);
                  }, 0);
                  return (
                    <div key={idx} className="border-t pt-4 first:border-t-0 first:pt-0">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold text-[#232F3E]">{category.category}</h4>
                        <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                          categoryScore <= 3 ? 'bg-green-100 text-green-700' :
                          categoryScore <= 6 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {categoryScore} / 10 points
                        </span>
                      </div>
                      <div className="space-y-2 ml-4 text-sm">
                        {category.items.map((item) => (
                          <div key={item.id} className="flex justify-between items-start">
                            <span className="text-gray-600 flex-1">{item.question}</span>
                            <div className="text-right ml-4">
                              <span className="font-medium block">{answers[item.id]?.score || 0} pts</span>
                              <span className="text-xs text-gray-500">{answers[item.id]?.answer || 'N/A'}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 1: Pre-flight Screener
  if (currentStep === 1) {
    const allPreflightAnswered = Object.keys(preflightAnswers).length === 3;
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review - Pre-flight Check</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-8 py-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">{preflightHelp.title}</h2>
            <p className="text-lg text-gray-600 mb-2">{preflightHelp.subtitle}</p>
            <p className="text-sm text-gray-500">{preflightHelp.why}</p>
          </div>

          <Card className="mb-8">
            <CardContent className="pt-6 space-y-6">
              {preflightHelp.questions.map((q, idx) => (
                <div key={q.id} className="pb-6 border-b last:border-b-0 last:pb-0">
                  <Label className="text-base mb-3 block font-medium">
                    {idx + 1}. {q.question}
                  </Label>
                  <p className="text-sm text-gray-600 mb-3">{q.help}</p>
                  <RadioGroup
                    value={preflightAnswers[q.id]}
                    onValueChange={(value) => setPreflightAnswers({...preflightAnswers, [q.id]: value})}
                  >
                    <div className="space-y-2">
                      <div className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        preflightAnswers[q.id] === 'yes' ? 'border-[#FF9900] bg-orange-50' : 'border-gray-200'
                      }`}>
                        <RadioGroupItem value="yes" id={`${q.id}-yes`} />
                        <Label htmlFor={`${q.id}-yes`} className="flex-1 cursor-pointer">
                          Yes
                          <span className="text-xs text-gray-500 ml-2">({q.examples.yes})</span>
                        </Label>
                      </div>
                      <div className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        preflightAnswers[q.id] === 'no' ? 'border-[#FF9900] bg-orange-50' : 'border-gray-200'
                      }`}>
                        <RadioGroupItem value="no" id={`${q.id}-no`} />
                        <Label htmlFor={`${q.id}-no`} className="flex-1 cursor-pointer">
                          No
                          <span className="text-xs text-gray-500 ml-2">({q.examples.no})</span>
                        </Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>
              ))}
            </CardContent>
          </Card>

          {showHighRiskWarning && (
            <Alert className="mb-8 border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              <AlertDescription>
                <p className="font-semibold mb-1">Elevated Risk Detected</p>
                <p className="text-sm">Based on your answers, this project may require additional review. We'll guide you through the full assessment to determine the appropriate next steps.</p>
              </AlertDescription>
            </Alert>
          )}

          <Button 
            onClick={() => setCurrentStep(2)}
            disabled={!allPreflightAnswered}
            className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-lg py-6"
          >
            Continue to Project Details
          </Button>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 2: Project Details
  if (currentStep === 2) {
    const requiredFieldsFilled = formData.projectName && formData.developer && formData.org && 
                                  formData.loginId && formData.goal && formData.platform && formData.stage;
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review - Project Details</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-8 py-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Project Details</h2>
            <p className="text-lg text-gray-600">
              Provide basic information about your AI agent concept. Hover over (?) icons for help.
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="projectName">
                    Project Name *
                    <Tooltip content={getTooltip('projectName')} />
                  </Label>
                  <Input
                    id="projectName"
                    value={formData.projectName}
                    onChange={(e) => handleChange('projectName', e.target.value)}
                    placeholder="AutoSummarizer for Ops Reports"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="developer">
                    Developer Name *
                    <Tooltip content={getTooltip('developer')} />
                  </Label>
                  <Input
                    id="developer"
                    value={formData.developer}
                    onChange={(e) => handleChange('developer', e.target.value)}
                    placeholder="John Doe"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="org">
                    Organization *
                    <Tooltip content={getTooltip('organization')} />
                  </Label>
                  <Input
                    id="org"
                    value={formData.org}
                    onChange={(e) => handleChange('org', e.target.value)}
                    placeholder="SPS CT SWAT"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="loginId">
                    Login ID / Email *
                    <Tooltip content={getTooltip('loginId')} />
                  </Label>
                  <Input
                    id="loginId"
                    type="email"
                    value={formData.loginId}
                    onChange={(e) => handleChange('loginId', e.target.value)}
                    placeholder="jdoe@amazon.com"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="goal">
                  Goal / Problem Statement *
                  <Tooltip content={getTooltip('goal')} />
                </Label>
                <Textarea
                  id="goal"
                  value={formData.goal}
                  onChange={(e) => handleChange('goal', e.target.value)}
                  placeholder="Reduce manual effort in summarizing daily reports by 80%"
                  rows={3}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="platform">
                    Primary Platform *
                    <Tooltip content={getTooltip('platform')} />
                  </Label>
                  <Select value={formData.platform} onValueChange={(value) => handleChange('platform', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent>
                      {PLATFORMS.map(platform => (
                        <SelectItem key={platform.value} value={platform.value}>
                          {platform.label}
                          <span className="text-xs text-gray-500 ml-2">- {platform.description}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formData.platform === 'other' && (
                    <Input
                      className="mt-2"
                      value={formData.platformOther}
                      onChange={(e) => handleChange('platformOther', e.target.value)}
                      placeholder="Specify platform name"
                    />
                  )}
                </div>
                <div>
                  <Label htmlFor="stage">
                    Development Stage *
                    <Tooltip content={getTooltip('stage')} />
                  </Label>
                  <Select value={formData.stage} onValueChange={(value) => handleChange('stage', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="idea">Idea</SelectItem>
                      <SelectItem value="prototype">Prototype</SelectItem>
                      <SelectItem value="pilot">Pilot</SelectItem>
                      <SelectItem value="production">Production</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="devType">
                    Type of Development
                    <Tooltip content={getTooltip('devType')} />
                  </Label>
                  <Select value={formData.devType} onValueChange={(value) => handleChange('devType', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="genai_agent">GenAI Agent</SelectItem>
                      <SelectItem value="workflow_automation">Workflow Automation</SelectItem>
                      <SelectItem value="extension">Extension</SelectItem>
                      <SelectItem value="script">Script</SelectItem>
                      <SelectItem value="integration">Integration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="teamSize">
                    Team Size / Roles
                    <Tooltip content={getTooltip('teamSize')} />
                  </Label>
                  <Input
                    id="teamSize"
                    value={formData.teamSize}
                    onChange={(e) => handleChange('teamSize', e.target.value)}
                    placeholder="2 devs, 1 reviewer"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="intendedOutput">
                    Intended Output
                    <Tooltip content={getTooltip('intendedOutput')} />
                  </Label>
                  <Input
                    id="intendedOutput"
                    value={formData.intendedOutput}
                    onChange={(e) => handleChange('intendedOutput', e.target.value)}
                    placeholder="Summary / Email / Report"
                  />
                </div>
                <div>
                  <Label htmlFor="expectedIntegrations">
                    Expected Integrations
                    <Tooltip content={getTooltip('expectedIntegrations')} />
                  </Label>
                  <Input
                    id="expectedIntegrations"
                    value={formData.expectedIntegrations}
                    onChange={(e) => handleChange('expectedIntegrations', e.target.value)}
                    placeholder="Slack / Sheets / None"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="otherDetails">
                  Other Details (Optional)
                  <Tooltip content={getTooltip('otherDetails')} />
                </Label>
                <Textarea
                  id="otherDetails"
                  value={formData.otherDetails}
                  onChange={(e) => handleChange('otherDetails', e.target.value)}
                  placeholder="May later expand to handle multilingual data..."
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button onClick={() => setCurrentStep(1)} variant="outline" className="flex-1">
              Back to Pre-flight
            </Button>
            <Button 
              onClick={() => setCurrentStep(3)}
              disabled={!requiredFieldsFilled}
              className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-lg py-6"
            >
              Continue to Data Category
            </Button>
          </div>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 3: Data Category Mapping
  if (currentStep === 3) {
    const dataInfo = mappedDataCategory ? getDataCategoryInfo(mappedDataCategory) : null;
    const allDataQuestionsAnswered = dataMappingHelp.questions.every(q => dataAnswers[q.id]);
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review - Data Category</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-8 py-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">{dataMappingHelp.title}</h2>
            <p className="text-lg text-gray-600 mb-2">{dataMappingHelp.subtitle}</p>
            <p className="text-sm text-gray-500">{dataMappingHelp.why}</p>
          </div>

          <Card className="mb-8">
            <CardContent className="pt-6 space-y-6">
              {dataMappingHelp.questions.map((q, idx) => (
                <div key={q.id} className="pb-6 border-b last:border-b-0 last:pb-0">
                  <Label className="text-base mb-2 block font-medium">{q.question}</Label>
                  <p className="text-sm text-gray-600 mb-3">{q.help}</p>
                  <p className="text-xs text-gray-500 mb-3">Examples: {q.examples}</p>
                  <RadioGroup
                    value={dataAnswers[q.id]}
                    onValueChange={(value) => setDataAnswers({...dataAnswers, [q.id]: value})}
                  >
                    <div className="space-y-2">
                      <div className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        dataAnswers[q.id] === 'yes' ? 'border-[#FF9900] bg-orange-50' : 'border-gray-200'
                      }`}>
                        <RadioGroupItem value="yes" id={`${q.id}-yes`} />
                        <Label htmlFor={`${q.id}-yes`} className="flex-1 cursor-pointer">Yes</Label>
                      </div>
                      <div className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        dataAnswers[q.id] === 'no' ? 'border-[#FF9900] bg-orange-50' : 'border-gray-200'
                      }`}>
                        <RadioGroupItem value="no" id={`${q.id}-no`} />
                        <Label htmlFor={`${q.id}-no`} className="flex-1 cursor-pointer">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>
              ))}
            </CardContent>
          </Card>

          {dataInfo && (
            <Alert className="mb-8 border-blue-200 bg-blue-50">
              <Info className="h-5 w-5 text-blue-600" />
              <AlertDescription>
                <p className="font-semibold mb-1">Data Category Identified</p>
                <p className="text-sm mb-2">
                  ✓ This maps to: <strong>{dataInfo.label}</strong>
                </p>
                <p className="text-sm text-gray-700">{dataInfo.description}</p>
                <p className="text-xs text-gray-600 mt-2">Risk Level: {dataInfo.riskLevel}</p>
              </AlertDescription>
            </Alert>
          )}

          {compatibilityCheck && !compatibilityCheck.compatible && (
            <Alert className="mb-8 border-red-200 bg-red-50">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <AlertDescription>
                <p className="font-semibold mb-1">Incompatible Combination Detected</p>
                <p className="text-sm mb-2">{compatibilityCheck.message}</p>
                {compatibilityCheck.suggestions && compatibilityCheck.suggestions.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-semibold">Suggested alternatives:</p>
                    <ul className="text-sm mt-1 space-y-1">
                      {compatibilityCheck.suggestions.map((sug, idx) => (
                        <li key={idx}>• {sug.platform} - {sug.description}</li>
                      ))}
                    </ul>
                  </div>
                )}
                <p className="text-sm mt-3 font-semibold text-red-700">
                  Please go back and select a compatible platform, or proceed to submit for SWAT review.
                </p>
              </AlertDescription>
            </Alert>
          )}

          {compatibilityCheck && compatibilityCheck.compatible && (
            <Alert className="mb-8 border-green-200 bg-green-50">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <AlertDescription>
                <p className="font-semibold mb-1">Compatible Combination</p>
                <p className="text-sm">{compatibilityCheck.message}</p>
              </AlertDescription>
            </Alert>
          )}

          <div className="flex gap-4">
            <Button onClick={() => setCurrentStep(2)} variant="outline" className="flex-1">
              Back to Details
            </Button>
            <Button 
              onClick={() => setCurrentStep(4)}
              disabled={!allDataQuestionsAnswered}
              className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-lg py-6"
            >
              Continue to Risk Assessment
            </Button>
          </div>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 4: Risk Assessment Questions
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review - Risk Assessment</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-300">Progress</p>
            <p className="text-2xl font-bold text-[#FF9900]">{getProgressPercentage()}%</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Risk Assessment</h2>
          <p className="text-lg text-gray-600">
            Answer all questions to complete your concept review. Each category has 2 questions.
          </p>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-blue-800">
            <strong>Instructions:</strong> Answer all questions below. Each category has 2 questions rated from 0 to 5 points. 
            Your total score will determine your risk zone and next steps.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {questions.map((category, categoryIdx) => (
            <Card key={categoryIdx}>
              <CardHeader>
                <CardTitle className="text-[#232F3E]">{category.category}</CardTitle>
                <CardDescription>{category.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {category.items.map((item) => (
                  <div key={item.id} className="pb-4 border-b last:border-b-0 last:pb-0">
                    <Label className="text-base mb-3 block font-medium">{item.question}</Label>
                    <RadioGroup
                      value={answers[item.id]?.answer}
                      onValueChange={(value) => {
                        const optionIndex = item.options.findIndex(opt => opt.text === value);
                        handleAnswer(item.id, optionIndex);
                      }}
                      required
                    >
                      <div className="space-y-2">
                        {item.options.map((option, optIdx) => (
                          <div 
                            key={optIdx} 
                            className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                              answers[item.id]?.answer === option.text 
                                ? 'border-[#FF9900] bg-orange-50' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <RadioGroupItem value={option.text} id={`${item.id}-${optIdx}`} />
                            <Label 
                              htmlFor={`${item.id}-${optIdx}`} 
                              className="font-normal flex-1 cursor-pointer"
                            >
                              {option.text}
                              <span className={`ml-2 text-xs font-semibold ${
                                option.score === 0 ? 'text-green-600' :
                                option.score <= 3 ? 'text-yellow-600' :
                                'text-red-600'
                              }`}>
                                ({option.score} {option.score === 1 ? 'point' : 'points'})
                              </span>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}

          <div className="sticky bottom-4 bg-white border-2 border-gray-200 rounded-lg p-4 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">Progress: {getProgressPercentage()}% Complete</span>
              <span className="text-sm text-gray-600">
                {Object.keys(answers).length} / {questions.flatMap(c => c.items).length} answered
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div 
                className="bg-[#FF9900] h-2 rounded-full transition-all duration-300"
                style={{ width: `${getProgressPercentage()}%` }}
              ></div>
            </div>
            <div className="flex gap-4">
              <Button onClick={() => setCurrentStep(3)} variant="outline" className="flex-1" type="button">
                Back to Data Category
              </Button>
              <Button
                type="submit"
                disabled={Object.keys(answers).length < questions.flatMap(c => c.items).length}
                className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-white text-lg py-6"
              >
                Submit Concept Review
              </Button>
            </div>
          </div>
        </form>
      </main>

      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE — SaferAI Framework
        </div>
      </footer>
    </div>
  );
};

export default ConceptReview;

