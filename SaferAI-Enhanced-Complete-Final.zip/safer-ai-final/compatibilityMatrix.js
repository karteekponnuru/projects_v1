/**
 * SaferAI Platform & Data Compatibility Matrix
 * Based on AWS AppSec approved mappings
 */

export const PLATFORMS = [
  { value: 'party_rock', label: 'Party Rock', description: 'Public demos and learning' },
  { value: 'cedric', label: 'Cedric', description: 'Internal summarization and writing' },
  { value: 'amazon_q', label: 'Amazon Q Internal', description: 'AWS Support and internal docs' },
  { value: 'mentor', label: 'Mentor', description: 'Support data with Slack integration' },
  { value: 'field_advisor', label: 'Field Advisor', description: 'AWSentral integration only' },
  { value: 'matome', label: 'Matome', description: 'Quip-based summarization' },
  { value: 'bedrockbot', label: 'BedrockBot', description: 'Bedrock API with Slack' },
  { value: 'loki', label: 'Loki', description: 'Validation workflows' },
  { value: 'clue_powerchat', label: 'Clue / PowerChat', description: 'Limited internal use' },
  { value: 'other', label: 'Other', description: 'Specify custom platform' }
];

export const DATA_CATEGORIES = [
  {
    value: 'public',
    label: 'Public / Sample Data',
    description: 'Publicly available data or synthetic samples',
    riskLevel: 'low',
    examples: 'Public documentation, sample datasets, mock data'
  },
  {
    value: 'internal',
    label: 'Internal / Employee Docs',
    description: 'Amazon internal employee documents and data',
    riskLevel: 'low',
    examples: 'Meeting notes, internal wikis, employee resources'
  },
  {
    value: 'business_partner',
    label: 'Business Partner Data',
    description: 'Partner or seller business information',
    riskLevel: 'medium',
    examples: 'Seller metrics, partner agreements, business data'
  },
  {
    value: 'customer_account',
    label: 'Customer Account Info',
    description: 'Customer account metadata (no content)',
    riskLevel: 'medium',
    examples: 'Account IDs, subscription status, basic metadata'
  },
  {
    value: 'aws_support',
    label: 'AWS Support Data',
    description: 'AWS Support case data and ticket information',
    riskLevel: 'high',
    examples: 'Support tickets, case metadata, technical issues'
  },
  {
    value: 'customer_content',
    label: 'Customer Content',
    description: 'Direct customer messages, emails, or communications',
    riskLevel: 'critical',
    examples: 'Customer emails, chat transcripts, message content'
  },
  {
    value: 'security_sensitive',
    label: 'Highly Sensitive Security Data',
    description: 'Security-related sensitive information',
    riskLevel: 'critical',
    examples: 'Security logs, vulnerability data, credentials'
  }
];

// Compatibility matrix: platform → data category → allowed
export const COMPATIBILITY_MATRIX = {
  party_rock: {
    public: { allowed: true, integration: 'Public only' },
    internal: { allowed: false, reason: 'Party Rock is for public demos only' },
    business_partner: { allowed: false, reason: 'Party Rock is for public demos only' },
    customer_account: { allowed: true, integration: 'Public only' },
    aws_support: { allowed: false, reason: 'Party Rock cannot access AWS Support data' },
    customer_content: { allowed: false, reason: 'Party Rock cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'Party Rock cannot access security data' }
  },
  cedric: {
    public: { allowed: true, integration: 'Slack, Quip' },
    internal: { allowed: true, integration: 'Slack, Quip' },
    business_partner: { allowed: true, integration: 'Slack, Quip' },
    customer_account: { allowed: true, integration: 'Slack, Quip' },
    aws_support: { allowed: false, reason: 'Cedric cannot access AWS Support data' },
    customer_content: { allowed: false, reason: 'Cedric cannot process customer content - use Amazon Q or Mentor instead' },
    security_sensitive: { allowed: false, reason: 'Cedric cannot access highly sensitive security data' }
  },
  amazon_q: {
    public: { allowed: true, integration: 'Internal tools' },
    internal: { allowed: true, integration: 'Internal tools' },
    business_partner: { allowed: true, integration: 'Internal tools' },
    customer_account: { allowed: true, integration: 'Internal tools' },
    aws_support: { allowed: true, integration: 'Internal tools' },
    customer_content: { allowed: false, reason: 'Amazon Q Internal cannot process customer content directly' },
    security_sensitive: { allowed: false, reason: 'Amazon Q cannot access highly sensitive security data' }
  },
  mentor: {
    public: { allowed: true, integration: 'Slack only' },
    internal: { allowed: true, integration: 'Slack only' },
    business_partner: { allowed: true, integration: 'Slack only' },
    customer_account: { allowed: true, integration: 'Slack only' },
    aws_support: { allowed: true, integration: 'Slack only' },
    customer_content: { allowed: false, reason: 'Mentor cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'Mentor cannot access highly sensitive security data' }
  },
  field_advisor: {
    public: { allowed: true, integration: 'AWSentral only' },
    internal: { allowed: true, integration: 'AWSentral only' },
    business_partner: { allowed: true, integration: 'AWSentral only' },
    customer_account: { allowed: true, integration: 'AWSentral only' },
    aws_support: { allowed: true, integration: 'AWSentral only' },
    customer_content: { allowed: false, reason: 'Field Advisor cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'Field Advisor cannot access highly sensitive security data' }
  },
  matome: {
    public: { allowed: true, integration: 'Quip only' },
    internal: { allowed: true, integration: 'Quip only' },
    business_partner: { allowed: true, integration: 'Quip only' },
    customer_account: { allowed: true, integration: 'Quip only' },
    aws_support: { allowed: false, reason: 'Matome cannot access AWS Support data' },
    customer_content: { allowed: false, reason: 'Matome cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'Matome cannot access highly sensitive security data' }
  },
  bedrockbot: {
    public: { allowed: true, integration: 'Slack (Bedrock API)' },
    internal: { allowed: true, integration: 'Slack (Bedrock API)' },
    business_partner: { allowed: true, integration: 'Slack (Bedrock API)' },
    customer_account: { allowed: true, integration: 'Slack (Bedrock API)' },
    aws_support: { allowed: true, integration: 'Slack (Bedrock API)' },
    customer_content: { allowed: false, reason: 'BedrockBot cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'BedrockBot cannot access highly sensitive security data' }
  },
  loki: {
    public: { allowed: true, integration: 'Validation workflows' },
    internal: { allowed: true, integration: 'Validation workflows' },
    business_partner: { allowed: true, integration: 'Validation workflows' },
    customer_account: { allowed: true, integration: 'Validation workflows' },
    aws_support: { allowed: true, integration: 'Validation workflows' },
    customer_content: { allowed: false, reason: 'Loki cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'Loki cannot access highly sensitive security data' }
  },
  clue_powerchat: {
    public: { allowed: true, integration: 'Limited internal' },
    internal: { allowed: true, integration: 'Limited internal' },
    business_partner: { allowed: true, integration: 'Limited internal' },
    customer_account: { allowed: true, integration: 'Limited internal' },
    aws_support: { allowed: true, integration: 'Limited internal' },
    customer_content: { allowed: false, reason: 'Clue/PowerChat cannot process customer content' },
    security_sensitive: { allowed: false, reason: 'Clue/PowerChat cannot access highly sensitive security data' }
  },
  other: {
    public: { allowed: true, integration: 'Requires review', caution: true },
    internal: { allowed: true, integration: 'Requires review', caution: true },
    business_partner: { allowed: true, integration: 'Requires review', caution: true },
    customer_account: { allowed: true, integration: 'Requires review', caution: true },
    aws_support: { allowed: true, integration: 'Requires review', caution: true },
    customer_content: { allowed: false, reason: 'Custom platforms require SWAT approval for customer content' },
    security_sensitive: { allowed: false, reason: 'Custom platforms require SWAT approval for security data' }
  }
};

/**
 * Check if platform and data category combination is compatible
 * @param {string} platform - Platform value
 * @param {string} dataCategory - Data category value
 * @returns {object} Compatibility result
 */
export function checkCompatibility(platform, dataCategory) {
  if (!platform || !dataCategory) {
    return { compatible: true, message: '' };
  }

  const platformRules = COMPATIBILITY_MATRIX[platform];
  if (!platformRules) {
    return { 
      compatible: false, 
      message: 'Unknown platform selected',
      severity: 'error'
    };
  }

  const rule = platformRules[dataCategory];
  if (!rule) {
    return { 
      compatible: false, 
      message: 'Unknown data category selected',
      severity: 'error'
    };
  }

  if (rule.allowed) {
    if (rule.caution) {
      return {
        compatible: true,
        message: `✓ Compatible. ${rule.integration}. Custom platforms require additional review.`,
        severity: 'warning',
        integration: rule.integration
      };
    }
    return {
      compatible: true,
      message: `✓ Compatible. Approved integration: ${rule.integration}`,
      severity: 'success',
      integration: rule.integration
    };
  }

  return {
    compatible: false,
    message: `❌ Incompatible: ${rule.reason}`,
    reason: rule.reason,
    severity: 'error',
    suggestions: getSuggestions(dataCategory)
  };
}

/**
 * Get alternative platform suggestions for a data category
 * @param {string} dataCategory - Data category value
 * @returns {array} Array of compatible platforms
 */
function getSuggestions(dataCategory) {
  const suggestions = [];
  
  for (const [platform, rules] of Object.entries(COMPATIBILITY_MATRIX)) {
    if (rules[dataCategory]?.allowed && platform !== 'other') {
      const platformInfo = PLATFORMS.find(p => p.value === platform);
      if (platformInfo) {
        suggestions.push({
          platform: platformInfo.label,
          description: platformInfo.description,
          integration: rules[dataCategory].integration
        });
      }
    }
  }
  
  return suggestions;
}

/**
 * Get data category from user-friendly questions
 * @param {object} answers - User answers to data questions
 * @returns {string} Data category value
 */
export function mapDataCategory(answers) {
  // Priority order: most restrictive first
  if (answers.securityData === 'yes') return 'security_sensitive';
  if (answers.customerContent === 'yes') return 'customer_content';
  if (answers.awsSupport === 'yes') return 'aws_support';
  if (answers.customerAccount === 'yes') return 'customer_account';
  if (answers.partnerData === 'yes') return 'business_partner';
  if (answers.internalOnly === 'yes') return 'internal';
  return 'public';
}

/**
 * Get user-friendly description of mapped data category
 * @param {string} categoryValue - Data category value
 * @returns {object} Category info
 */
export function getDataCategoryInfo(categoryValue) {
  return DATA_CATEGORIES.find(cat => cat.value === categoryValue) || DATA_CATEGORIES[0];
}

