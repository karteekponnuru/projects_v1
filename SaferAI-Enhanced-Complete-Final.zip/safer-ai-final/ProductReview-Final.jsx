import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, ExternalLink, HelpCircle, Info, AlertCircle, Upload, Loader2 } from 'lucide-react';
import { generateSaferAIPDF } from '@/lib/pdfGenerator.js';
import { PLATFORMS, checkCompatibility, mapDataCategory, getDataCategoryInfo } from '@/lib/compatibilityMatrix.js';
import { getTooltip, getPreflightHelp, getDataMappingHelp } from '@/lib/tooltips.js';

const SWAT_ASANA_URL = 'https://asana.amazon.com/create?project=SWAT_Consultations';
const PROMPT_ANALYZER_API = import.meta.env.VITE_PROMPT_ANALYZER_API || '';

const Tooltip = ({ content }) => (
  <div className="inline-block ml-2 group relative">
    <HelpCircle className="h-4 w-4 text-gray-400 cursor-help" />
    <div className="hidden group-hover:block absolute z-50 w-72 p-3 bg-gray-900 text-white text-sm rounded-lg shadow-lg -left-32 top-6">
      <div className="font-semibold mb-1">{content.title}</div>
      <div className="mb-2">{content.content}</div>
      {content.example && (
        <div className="text-xs text-gray-300 mt-2">
          <span className="font-semibold">Example:</span> {content.example}
        </div>
      )}
      {content.why && (
        <div className="text-xs text-gray-300 mt-1">
          <span className="font-semibold">Why we ask:</span> {content.why}
        </div>
      )}
    </div>
  </div>
);

const ProductReview = () => {
  const [currentStep, setCurrentStep] = useState(1); // 1: preflight, 2: details, 3: prompt, 4: questions
  const [preflightAnswers, setPreflightAnswers] = useState({});
  const [showHighRiskWarning, setShowHighRiskWarning] = useState(false);
  
  const [formData, setFormData] = useState({
    projectName: '',
    developer: '',
    org: '',
    loginId: '',
    date: new Date().toISOString().split('T')[0],
    goal: '',
    devType: '',
    stage: '',
    platform: '',
    platformOther: '',
    teamSize: '',
    intendedOutput: '',
    expectedIntegrations: '',
    otherDetails: '',
    asrTicket: '',
    conceptReviewId: ''
  });

  const [conceptPdf, setConceptPdf] = useState(null);
  const [conceptData, setConceptData] = useState(null);
  const [dataAnswers, setDataAnswers] = useState({});
  const [mappedDataCategory, setMappedDataCategory] = useState('');
  const [compatibilityCheck, setCompatibilityCheck] = useState(null);
  
  const [promptText, setPromptText] = useState('');
  const [promptAnalysis, setPromptAnalysis] = useState(null);
  const [analyzingPrompt, setAnalyzingPrompt] = useState(false);
  const [promptAnalyzed, setPromptAnalyzed] = useState(false);

  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [riskScore, setRiskScore] = useState(0);
  const [normalizedScore, setNormalizedScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');

  // Check compatibility when platform or data category changes
  useEffect(() => {
    if (formData.platform && mappedDataCategory) {
      const result = checkCompatibility(formData.platform, mappedDataCategory);
      setCompatibilityCheck(result);
    }
  }, [formData.platform, mappedDataCategory]);

  // Map data category when answers change
  useEffect(() => {
    const category = mapDataCategory(dataAnswers);
    setMappedDataCategory(category);
  }, [dataAnswers]);

  // Check preflight for high-risk indicators
  useEffect(() => {
    const highRisk = 
      preflightAnswers.customerData === 'yes' ||
      preflightAnswers.elevatedAccess === 'yes' ||
      preflightAnswers.externalIntegration === 'yes';
    setShowHighRiskWarning(highRisk);
  }, [preflightAnswers]);

  const questions = [
    {
      category: 'A. Data Sensitivity',
      description: 'What type of data does your product use?',
      items: [
        {
          id: 'data_type',
          question: 'Which data types does your product interact with?',
          options: [
            { text: 'Public/mock', score: 0 },
            { text: 'Internal', score: 1 },
            { text: 'Business/Partner', score: 2 },
            { text: 'AWS Support', score: 3 },
            { text: 'Customer/PII', score: 5 }
          ]
        },
        {
          id: 'customer_data',
          question: 'Does your product process or derive insights from customer-linked data?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'B. Access Permissions',
      description: 'What access does your product have?',
      items: [
        {
          id: 'access_level',
          question: 'What kind of access does your solution have?',
          options: [
            { text: 'None', score: 0 },
            { text: 'Basic read', score: 2 },
            { text: 'Write/update', score: 3 },
            { text: 'Elevated/system', score: 5 }
          ]
        },
        {
          id: 'api_interaction',
          question: 'Does it interact with dashboards, APIs, or case data?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Internal only', score: 2 },
            { text: 'External or cross-tenant', score: 4 }
          ]
        }
      ]
    },
    {
      category: 'C. Output Safety',
      description: 'What does your product produce?',
      items: [
        {
          id: 'output_visibility',
          question: 'Where are the outputs visible?',
          options: [
            { text: 'Team-only', score: 1 },
            { text: 'Cross-org', score: 3 },
            { text: 'Public/External', score: 5 }
          ]
        },
        {
          id: 'auto_generated',
          question: 'Are outputs auto-generated without human review?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes', score: 3 },
            { text: 'Yes, and shared externally', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'D. Prompt Security',
      description: 'How are user inputs handled?',
      items: [
        {
          id: 'free_text_prompts',
          question: 'Do users enter free text prompts?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Partially', score: 2 },
            { text: 'Yes', score: 4 }
          ]
        },
        {
          id: 'prompt_exposure',
          question: 'Could prompts expose internal data or credentials?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Likely', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'E. External Integrations',
      description: 'What external systems are connected?',
      items: [
        {
          id: 'external_services',
          question: 'Are there integrations with non-AWS services?',
          options: [
            { text: 'None', score: 0 },
            { text: 'Internal APIs only', score: 2 },
            { text: 'Slack/Sheets/Email/Other 3P', score: 4 }
          ]
        },
        {
          id: 'external_data',
          question: 'Does your product send or store data externally?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Occasionally', score: 2 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'F. Business Impact',
      description: 'What is the operational impact?',
      items: [
        {
          id: 'criticality',
          question: 'How critical is this to daily operations?',
          options: [
            { text: 'Low', score: 1 },
            { text: 'Medium', score: 3 },
            { text: 'High', score: 5 }
          ]
        },
        {
          id: 'incorrect_outputs',
          question: 'Would incorrect outputs create customer or business risk?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'G. Compliance & Monitoring',
      description: 'How is the product monitored?',
      items: [
        {
          id: 'logging',
          question: 'Are logs or activity histories maintained?',
          options: [
            { text: 'Full logs', score: 0 },
            { text: 'Partial logs', score: 2 },
            { text: 'No logs', score: 5 }
          ]
        },
        {
          id: 'project_owner',
          question: 'Is there a clearly identified project owner?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Not yet', score: 3 }
          ]
        }
      ]
    },
    {
      category: 'H. Future Scaling & Governance',
      description: 'What are the scaling plans?',
      items: [
        {
          id: 'scaling',
          question: 'Will this scale across multiple orgs?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Later', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        },
        {
          id: 'permission_increase',
          question: 'Will permissions or data exposure increase as it scales?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 2 },
            { text: 'Yes', score: 4 }
          ]
        }
      ]
    }
  ];

  const preflightHelp = getPreflightHelp();
  const dataMappingHelp = getDataMappingHelp();

  const analyzePrompt = async () => {
    if (!promptText.trim()) {
      alert('Please enter a prompt to analyze');
      return;
    }

    setAnalyzingPrompt(true);
    
    try {
      if (PROMPT_ANALYZER_API) {
        const response = await fetch(PROMPT_ANALYZER_API, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: promptText })
        });

        if (!response.ok) throw new Error('API call failed');
        
        const data = await response.json();
        setPromptAnalysis(data);
      } else {
        // Fallback mock analysis
        const mockAnalysis = {
          score: Math.floor(Math.random() * 10) + 1,
          risk_level: Math.random() > 0.7 ? 'HIGH' : Math.random() > 0.4 ? 'MEDIUM' : 'LOW',
          findings: [
            'Prompt contains customer data references',
            'Potential PII exposure detected',
            'No obvious security concerns with prompt structure'
          ],
          suggestions: [
            'Use summary metadata instead of full customer data',
            'Reference case IDs rather than case content',
            'Add input validation for user-provided data'
          ],
          categories: ['customer_data', 'pii'],
          timestamp: new Date().toISOString()
        };
        setPromptAnalysis(mockAnalysis);
      }
      setPromptAnalyzed(true);
    } catch (error) {
      console.error('Prompt analysis error:', error);
      alert('Failed to analyze prompt. Using fallback analysis.');
      const fallbackAnalysis = {
        score: 5,
        risk_level: 'MEDIUM',
        findings: ['Unable to connect to analysis service'],
        suggestions: ['Please review prompt manually for security concerns'],
        categories: [],
        timestamp: new Date().toISOString()
      };
      setPromptAnalysis(fallbackAnalysis);
      setPromptAnalyzed(true);
    } finally {
      setAnalyzingPrompt(false);
    }
  };

  const handleConceptPdfUpload = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'application/pdf') {
      setConceptPdf(file);
      // In a real implementation, you would parse the PDF here
      // For now, we'll simulate concept data
      setConceptData({
        projectName: 'Original Concept Name',
        platform: 'cedric',
        dataCategory: 'internal',
        stage: 'idea',
        goal: 'Original goal statement'
      });
    } else {
      alert('Please upload a valid PDF file');
    }
  };

  const getComparisonData = () => {
    if (!conceptData) return null;

    return [
      {
        parameter: 'Project Name',
        concept: conceptData.projectName,
        product: formData.projectName,
        status: conceptData.projectName === formData.projectName ? 'No Change' : 'Changed'
      },
      {
        parameter: 'Platform',
        concept: PLATFORMS.find(p => p.value === conceptData.platform)?.label || conceptData.platform,
        product: PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform,
        status: conceptData.platform === formData.platform ? 'No Change' : 'Changed'
      },
      {
        parameter: 'Data Category',
        concept: conceptData.dataCategory,
        product: mappedDataCategory,
        status: conceptData.dataCategory === mappedDataCategory ? 'No Change' : 'Broadened'
      },
      {
        parameter: 'Stage',
        concept: conceptData.stage,
        product: formData.stage,
        status: conceptData.stage === formData.stage ? 'No Change' : 'Advanced'
      },
      {
        parameter: 'Goal',
        concept: conceptData.goal.substring(0, 50) + '...',
        product: formData.goal.substring(0, 50) + '...',
        status: conceptData.goal === formData.goal ? 'No Change' : 'Modified'
      }
    ];
  };

  const calculateRisk = () => {
    let totalScore = 0;
    Object.values(answers).forEach(answer => {
      totalScore += answer.score;
    });
    
    // Add prompt analysis score if available
    if (promptAnalysis) {
      totalScore += promptAnalysis.score;
    }
    
    setRiskScore(totalScore);
    const normalized = Math.round(totalScore / 2);
    setNormalizedScore(normalized);
    
    if (normalized <= 16) {
      setRiskZone('green');
    } else if (normalized <= 28) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateRisk();
    setSubmitted(true);
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleAnswer = (questionId, optionIndex) => {
    const allQuestions = questions.flatMap(cat => cat.items);
    const question = allQuestions.find(q => q.id === questionId);
    setAnswers({
      ...answers,
      [questionId]: {
        answer: question.options[optionIndex].text,
        score: question.options[optionIndex].score
      }
    });
  };

  const downloadPDF = async () => {
    const zoneDetails = getRiskZoneDetails();
    const dataInfo = getDataCategoryInfo(mappedDataCategory);
    
    const pdfData = {
      projectName: formData.projectName,
      developer: formData.developer,
      org: formData.org,
      loginId: formData.loginId,
      platform: PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform,
      date: formData.date,
      stage: formData.stage,
      devType: formData.devType,
      zone: zoneDetails.title,
      score: normalizedScore,
      maxScore: 40,
      findings: [
        `Raw Score: ${riskScore}/80`,
        `Data Category: ${dataInfo.label}`,
        `Platform: ${PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform}`,
        `Compatibility: ${compatibilityCheck?.compatible ? 'Compatible' : 'Incompatible'}`,
        `ASR Ticket: ${formData.asrTicket || 'N/A'}`,
        `Prompt Risk: ${promptAnalysis?.risk_level || 'Not analyzed'}`,
        ...(promptAnalysis?.findings || [])
      ],
      suggestions: [
        ...zoneDetails.nextSteps,
        ...(promptAnalysis?.suggestions || [])
      ]
    };

    await generateSaferAIPDF(pdfData, 'product');
  };

  const getRiskZoneDetails = () => {
    const zones = {
      green: {
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        title: 'Green Zone – Ready to Deploy',
        color: 'bg-green-50 border-green-200',
        message: 'Safe product; minimal risk. Your product aligns with policy and approved use cases. You can proceed to deployment.',
        nextSteps: [
          'Complete final security checklist',
          'Set up production monitoring',
          'Document deployment procedures',
          'Plan regular security reviews',
          'Ensure incident response plan is ready'
        ]
      },
      amber: {
        icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
        title: 'Amber Zone – Deploy with Monitoring',
        color: 'bg-yellow-50 border-yellow-200',
        message: 'Acceptable risk; monitor closely. Some parameters need ongoing validation after deployment.',
        nextSteps: [
          'Implement enhanced logging and monitoring',
          'Set up alerts for anomalous behavior',
          'Schedule regular security audits',
          'Add human review checkpoints',
          'Document all security considerations',
          'Plan gradual rollout strategy'
        ]
      },
      red: {
        icon: <XCircle className="h-16 w-16 text-red-600" />,
        title: 'Red Zone – Requires SWAT Review',
        color: 'bg-red-50 border-red-200',
        message: 'High exposure; requires review. Your product involves restricted data or high-risk operations. SWAT consultation required before deployment.',
        nextSteps: [
          'Schedule immediate SWAT consultation',
          'Prepare comprehensive security documentation',
          'Review alternative implementation approaches',
          'Do not deploy without SWAT approval',
          'Document all identified risks and mitigations',
          'Plan for enhanced security controls'
        ]
      }
    };
    return zones[riskZone] || zones.green;
  };

  const getProgressPercentage = () => {
    const totalQuestions = questions.flatMap(cat => cat.items).length;
    const answeredQuestions = Object.keys(answers).length;
    return Math.round((answeredQuestions / totalQuestions) * 100);
  };

  const generateSwatUrl = () => {
    const zoneDetails = getRiskZoneDetails();
    const dataInfo = getDataCategoryInfo(mappedDataCategory);
    const platformLabel = PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform;
    
    const notes = `
SaferAI Product Review Submission

Project: ${formData.projectName}
Developer: ${formData.developer} (${formData.loginId})
Organization: ${formData.org}
Date: ${formData.date}
ASR Ticket: ${formData.asrTicket || 'N/A'}

Platform: ${platformLabel}
Data Category: ${dataInfo.label}
Development Stage: ${formData.stage}
Type: ${formData.devType}

Risk Assessment:
- Zone: ${zoneDetails.title}
- Score: ${normalizedScore}/40 (Raw: ${riskScore}/80)
- Prompt Risk: ${promptAnalysis?.risk_level || 'Not analyzed'}
- Compatibility: ${compatibilityCheck?.compatible ? 'Compatible' : compatibilityCheck?.message || 'Unknown'}

Goal: ${formData.goal}

Prompt Analysis Findings:
${promptAnalysis?.findings?.join('\n') || 'No prompt analysis available'}

Key Risk Factors:
${Object.entries(answers).slice(0, 5).map(([key, val]) => `- ${key}: ${val.answer} (${val.score} pts)`).join('\n')}

This product requires SWAT review due to ${riskZone === 'red' ? 'high-risk factors' : 'elevated risk score'}.
    `.trim();

    return `${SWAT_ASANA_URL}&name=${encodeURIComponent(formData.projectName + ' - Product Review')}&notes=${encodeURIComponent(notes)}`;
  };

  if (submitted) {
    const zoneDetails = getRiskZoneDetails();
    const dataInfo = getDataCategoryInfo(mappedDataCategory);
    const comparisonData = getComparisonData();
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review Results</p>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-8 py-12">
          <Card className={`border-2 ${zoneDetails.color} mb-8`}>
            <CardHeader>
              <div className="flex items-center gap-4">
                {zoneDetails.icon}
                <div>
                  <CardTitle className="text-2xl mb-2">{zoneDetails.title}</CardTitle>
                  <p className="text-gray-700">{zoneDetails.message}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-2">Risk Score: {normalizedScore} / 40</h3>
                <p className="text-sm text-gray-600 mb-2">(Raw Score: {riskScore} / 80)</p>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full ${
                      riskZone === 'green' ? 'bg-green-500' :
                      riskZone === 'amber' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(normalizedScore / 40) * 100}%` }}
                  ></div>
                </div>
              </div>

              {promptAnalysis && (
                <div className="mb-6">
                  <Alert className={`${
                    promptAnalysis.risk_level === 'LOW' ? 'border-green-200 bg-green-50' :
                    promptAnalysis.risk_level === 'MEDIUM' ? 'border-yellow-200 bg-yellow-50' :
                    'border-red-200 bg-red-50'
                  }`}>
                    <AlertDescription>
                      <div className="flex items-start gap-2">
                        {promptAnalysis.risk_level === 'LOW' ? (
                          <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5" />
                        ) : promptAnalysis.risk_level === 'MEDIUM' ? (
                          <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-600 mt-0.5" />
                        )}
                        <div>
                          <p className="font-semibold mb-1">Prompt Security Analysis</p>
                          <p className="text-sm mb-2">Risk Level: {promptAnalysis.risk_level} ({promptAnalysis.score}/10)</p>
                          {promptAnalysis.findings && promptAnalysis.findings.length > 0 && (
                            <div className="mb-2">
                              <p className="text-sm font-semibold">Findings:</p>
                              <ul className="text-sm mt-1 space-y-1">
                                {promptAnalysis.findings.map((finding, idx) => (
                                  <li key={idx}>• {finding}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          {promptAnalysis.suggestions && promptAnalysis.suggestions.length > 0 && (
                            <div>
                              <p className="text-sm font-semibold">Suggestions:</p>
                              <ul className="text-sm mt-1 space-y-1">
                                {promptAnalysis.suggestions.map((suggestion, idx) => (
                                  <li key={idx}>• {suggestion}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                </div>
              )}

              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3">Next Steps:</h3>
                <ul className="space-y-2">
                  {zoneDetails.nextSteps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#FF9900] mt-1">•</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Alert className="mb-6 border-blue-200 bg-blue-50">
                <Info className="h-5 w-5 text-blue-600" />
                <AlertDescription>
                  <p className="font-semibold mb-1">📋 AppSec Consultation Required</p>
                  <p className="text-sm">
                    Please raise a consulting request with AppSec for live deployments. 
                    This ensures your production deployment meets all security requirements.
                  </p>
                </AlertDescription>
              </Alert>

              <div className="flex gap-4 flex-wrap">
                <Button onClick={downloadPDF} className="bg-[#232F3E] hover:bg-[#1a2332]">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF Report
                </Button>
                <a href={generateSwatUrl()} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Submit to SWAT
                  </Button>
                </a>
                <Button onClick={() => { setSubmitted(false); setCurrentStep(1); }} variant="outline">
                  Start New Review
                </Button>
              </div>
            </CardContent>
          </Card>

          {comparisonData && (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Concept vs Product Comparison</CardTitle>
                <CardDescription>Changes between your original concept and final product</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b-2 border-gray-300">
                        <th className="text-left py-3 px-4 font-semibold">Parameter</th>
                        <th className="text-left py-3 px-4 font-semibold">Planned (Concept)</th>
                        <th className="text-left py-3 px-4 font-semibold">Built (Product)</th>
                        <th className="text-left py-3 px-4 font-semibold">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {comparisonData.map((row, idx) => (
                        <tr key={idx} className="border-b border-gray-200">
                          <td className="py-3 px-4 font-medium">{row.parameter}</td>
                          <td className="py-3 px-4 text-gray-600">{row.concept}</td>
                          <td className="py-3 px-4 text-gray-600">{row.product}</td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-1 rounded text-xs font-semibold ${
                              row.status === 'No Change' ? 'bg-green-100 text-green-700' :
                              row.status === 'Changed' ? 'bg-yellow-100 text-yellow-700' :
                              row.status === 'Broadened' ? 'bg-orange-100 text-orange-700' :
                              'bg-blue-100 text-blue-700'
                            }`}>
                              {row.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Product Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold text-sm text-gray-600">Project Name</p>
                  <p className="text-lg">{formData.projectName}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Developer</p>
                  <p className="text-lg">{formData.developer}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Organization</p>
                  <p className="text-lg">{formData.org}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Platform</p>
                  <p className="text-lg">{PLATFORMS.find(p => p.value === formData.platform)?.label || formData.platform}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Data Category</p>
                  <p className="text-lg">{dataInfo.label}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Stage</p>
                  <p className="text-lg">{formData.stage}</p>
                </div>
                {formData.asrTicket && (
                  <div>
                    <p className="font-semibold text-sm text-gray-600">ASR Ticket</p>
                    <p className="text-lg">{formData.asrTicket}</p>
                  </div>
                )}
              </div>
              {formData.goal && (
                <div className="mt-4">
                  <p className="font-semibold text-sm text-gray-600">Goal / Problem Statement</p>
                  <p className="text-base">{formData.goal}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Score Breakdown by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {questions.map((category, idx) => {
                  const categoryScore = category.items.reduce((sum, item) => {
                    return sum + (answers[item.id]?.score || 0);
                  }, 0);
                  return (
                    <div key={idx} className="border-t pt-4 first:border-t-0 first:pt-0">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold text-[#232F3E]">{category.category}</h4>
                        <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                          categoryScore <= 3 ? 'bg-green-100 text-green-700' :
                          categoryScore <= 6 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {categoryScore} / 10 points
                        </span>
                      </div>
                      <div className="space-y-2 ml-4 text-sm">
                        {category.items.map((item) => (
                          <div key={item.id} className="flex justify-between items-start">
                            <span className="text-gray-600 flex-1">{item.question}</span>
                            <div className="text-right ml-4">
                              <span className="font-medium block">{answers[item.id]?.score || 0} pts</span>
                              <span className="text-xs text-gray-500">{answers[item.id]?.answer || 'N/A'}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 1: Pre-flight Screener (same as Concept Review)
  if (currentStep === 1) {
    const allPreflightAnswered = Object.keys(preflightAnswers).length === 3;
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review - Pre-flight Check</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-8 py-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">{preflightHelp.title}</h2>
            <p className="text-lg text-gray-600 mb-2">{preflightHelp.subtitle}</p>
            <p className="text-sm text-gray-500">{preflightHelp.why}</p>
          </div>

          <Card className="mb-8">
            <CardContent className="pt-6 space-y-6">
              {preflightHelp.questions.map((q, idx) => (
                <div key={q.id} className="pb-6 border-b last:border-b-0 last:pb-0">
                  <Label className="text-base mb-3 block font-medium">
                    {idx + 1}. {q.question}
                  </Label>
                  <p className="text-sm text-gray-600 mb-3">{q.help}</p>
                  <RadioGroup
                    value={preflightAnswers[q.id]}
                    onValueChange={(value) => setPreflightAnswers({...preflightAnswers, [q.id]: value})}
                  >
                    <div className="space-y-2">
                      <div className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        preflightAnswers[q.id] === 'yes' ? 'border-[#FF9900] bg-orange-50' : 'border-gray-200'
                      }`}>
                        <RadioGroupItem value="yes" id={`${q.id}-yes`} />
                        <Label htmlFor={`${q.id}-yes`} className="flex-1 cursor-pointer">
                          Yes
                          <span className="text-xs text-gray-500 ml-2">({q.examples.yes})</span>
                        </Label>
                      </div>
                      <div className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        preflightAnswers[q.id] === 'no' ? 'border-[#FF9900] bg-orange-50' : 'border-gray-200'
                      }`}>
                        <RadioGroupItem value="no" id={`${q.id}-no`} />
                        <Label htmlFor={`${q.id}-no`} className="flex-1 cursor-pointer">
                          No
                          <span className="text-xs text-gray-500 ml-2">({q.examples.no})</span>
                        </Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>
              ))}
            </CardContent>
          </Card>

          {showHighRiskWarning && (
            <Alert className="mb-8 border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              <AlertDescription>
                <p className="font-semibold mb-1">Elevated Risk Detected</p>
                <p className="text-sm">Based on your answers, this product may require additional review. We'll guide you through the full assessment to determine the appropriate next steps.</p>
              </AlertDescription>
            </Alert>
          )}

          <Button 
            onClick={() => setCurrentStep(2)}
            disabled={!allPreflightAnswered}
            className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-lg py-6"
          >
            Continue to Project Details
          </Button>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 2: Project Details + ASR + Concept Reference
  if (currentStep === 2) {
    const requiredFieldsFilled = formData.projectName && formData.developer && formData.org && 
                                  formData.loginId && formData.goal && formData.platform && formData.stage;
    
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review - Project Details</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-8 py-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Project Details</h2>
            <p className="text-lg text-gray-600">
              Provide information about your completed AI product. Hover over (?) icons for help.
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="projectName">
                    Project Name *
                    <Tooltip content={getTooltip('projectName')} />
                  </Label>
                  <Input
                    id="projectName"
                    value={formData.projectName}
                    onChange={(e) => handleChange('projectName', e.target.value)}
                    placeholder="AutoSummarizer for Ops Reports"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="developer">
                    Developer Name *
                    <Tooltip content={getTooltip('developer')} />
                  </Label>
                  <Input
                    id="developer"
                    value={formData.developer}
                    onChange={(e) => handleChange('developer', e.target.value)}
                    placeholder="John Doe"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="org">
                    Organization *
                    <Tooltip content={getTooltip('organization')} />
                  </Label>
                  <Input
                    id="org"
                    value={formData.org}
                    onChange={(e) => handleChange('org', e.target.value)}
                    placeholder="SPS CT SWAT"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="loginId">
                    Login ID / Email *
                    <Tooltip content={getTooltip('loginId')} />
                  </Label>
                  <Input
                    id="loginId"
                    type="email"
                    value={formData.loginId}
                    onChange={(e) => handleChange('loginId', e.target.value)}
                    placeholder="jdoe@amazon.com"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="goal">
                  Goal / Problem Statement *
                  <Tooltip content={getTooltip('goal')} />
                </Label>
                <Textarea
                  id="goal"
                  value={formData.goal}
                  onChange={(e) => handleChange('goal', e.target.value)}
                  placeholder="Reduce manual effort in summarizing daily reports by 80%"
                  rows={3}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="platform">
                    Primary Platform *
                    <Tooltip content={getTooltip('platform')} />
                  </Label>
                  <Select value={formData.platform} onValueChange={(value) => handleChange('platform', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent>
                      {PLATFORMS.map(platform => (
                        <SelectItem key={platform.value} value={platform.value}>
                          {platform.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formData.platform === 'other' && (
                    <Input
                      className="mt-2"
                      value={formData.platformOther}
                      onChange={(e) => handleChange('platformOther', e.target.value)}
                      placeholder="Specify platform name"
                    />
                  )}
                </div>
                <div>
                  <Label htmlFor="stage">
                    Development Stage *
                    <Tooltip content={getTooltip('stage')} />
                  </Label>
                  <Select value={formData.stage} onValueChange={(value) => handleChange('stage', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prototype">Prototype</SelectItem>
                      <SelectItem value="pilot">Pilot</SelectItem>
                      <SelectItem value="production">Production</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="devType">
                    Type of Development
                    <Tooltip content={getTooltip('devType')} />
                  </Label>
                  <Select value={formData.devType} onValueChange={(value) => handleChange('devType', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="genai_agent">GenAI Agent</SelectItem>
                      <SelectItem value="workflow_automation">Workflow Automation</SelectItem>
                      <SelectItem value="extension">Extension</SelectItem>
                      <SelectItem value="script">Script</SelectItem>
                      <SelectItem value="integration">Integration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="teamSize">
                    Team Size / Roles
                    <Tooltip content={getTooltip('teamSize')} />
                  </Label>
                  <Input
                    id="teamSize"
                    value={formData.teamSize}
                    onChange={(e) => handleChange('teamSize', e.target.value)}
                    placeholder="2 devs, 1 reviewer"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="intendedOutput">
                    Intended Output
                    <Tooltip content={getTooltip('intendedOutput')} />
                  </Label>
                  <Input
                    id="intendedOutput"
                    value={formData.intendedOutput}
                    onChange={(e) => handleChange('intendedOutput', e.target.value)}
                    placeholder="Summary / Email / Report"
                  />
                </div>
                <div>
                  <Label htmlFor="expectedIntegrations">
                    Expected Integrations
                    <Tooltip content={getTooltip('expectedIntegrations')} />
                  </Label>
                  <Input
                    id="expectedIntegrations"
                    value={formData.expectedIntegrations}
                    onChange={(e) => handleChange('expectedIntegrations', e.target.value)}
                    placeholder="Slack / Sheets / None"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="otherDetails">
                  Other Details (Optional)
                  <Tooltip content={getTooltip('otherDetails')} />
                </Label>
                <Textarea
                  id="otherDetails"
                  value={formData.otherDetails}
                  onChange={(e) => handleChange('otherDetails', e.target.value)}
                  placeholder="May later expand to handle multilingual data..."
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Security & Review Information</CardTitle>
              <CardDescription>Link to existing reviews and security assessments</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="asrTicket">
                  ASR Ticket Number
                  <Tooltip content={getTooltip('asrTicket')} />
                </Label>
                <Input
                  id="asrTicket"
                  value={formData.asrTicket}
                  onChange={(e) => handleChange('asrTicket', e.target.value)}
                  placeholder="ASR-12345"
                />
                <p className="text-xs text-gray-500 mt-1">Leave blank if you don't have an ASR ticket yet</p>
              </div>

              <div>
                <Label htmlFor="conceptReviewId">
                  Concept Review ID (Optional)
                  <Tooltip content={getTooltip('conceptReviewId')} />
                </Label>
                <Input
                  id="conceptReviewId"
                  value={formData.conceptReviewId}
                  onChange={(e) => handleChange('conceptReviewId', e.target.value)}
                  placeholder="CR-2025-001"
                />
              </div>

              <div>
                <Label htmlFor="conceptPdf">
                  Upload Concept Review PDF (Optional)
                </Label>
                <div className="mt-2">
                  <label htmlFor="conceptPdf" className="flex items-center justify-center w-full p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-[#FF9900] transition-colors">
                    <div className="text-center">
                      <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600">
                        {conceptPdf ? conceptPdf.name : 'Click to upload or drag and drop'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">PDF files only</p>
                    </div>
                    <input
                      id="conceptPdf"
                      type="file"
                      accept=".pdf"
                      onChange={handleConceptPdfUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                {conceptPdf && (
                  <p className="text-sm text-green-600 mt-2">✓ {conceptPdf.name} uploaded</p>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button onClick={() => setCurrentStep(1)} variant="outline" className="flex-1">
              Back to Pre-flight
            </Button>
            <Button 
              onClick={() => setCurrentStep(3)}
              disabled={!requiredFieldsFilled}
              className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-lg py-6"
            >
              Continue to Prompt Analysis
            </Button>
          </div>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 3: Prompt Analysis
  if (currentStep === 3) {
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review - Prompt Analysis</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-8 py-12">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Prompt Security Analysis</h2>
            <p className="text-lg text-gray-600">
              Paste a sample prompt from your product to analyze potential security risks.
            </p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Sample Prompt</CardTitle>
              <CardDescription>
                Provide a representative prompt that users might enter in your product
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                placeholder="Example: Summarize all customer emails from the last week regarding billing issues..."
                rows={6}
                className="mb-4"
              />
              <Button
                onClick={analyzePrompt}
                disabled={analyzingPrompt || !promptText.trim()}
                className="bg-[#FF9900] hover:bg-[#ec8f00]"
              >
                {analyzingPrompt ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  'Analyze Prompt'
                )}
              </Button>
            </CardContent>
          </Card>

          {promptAnalysis && (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Analysis Results</CardTitle>
              </CardHeader>
              <CardContent>
                <Alert className={`mb-4 ${
                  promptAnalysis.risk_level === 'LOW' ? 'border-green-200 bg-green-50' :
                  promptAnalysis.risk_level === 'MEDIUM' ? 'border-yellow-200 bg-yellow-50' :
                  'border-red-200 bg-red-50'
                }`}>
                  <AlertDescription>
                    <div className="flex items-start gap-2">
                      {promptAnalysis.risk_level === 'LOW' ? (
                        <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5" />
                      ) : promptAnalysis.risk_level === 'MEDIUM' ? (
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600 mt-0.5" />
                      )}
                      <div>
                        <p className="font-semibold mb-2">
                          Risk Level: {promptAnalysis.risk_level} ({promptAnalysis.score}/10)
                        </p>
                        {promptAnalysis.findings && promptAnalysis.findings.length > 0 && (
                          <div className="mb-3">
                            <p className="font-semibold text-sm mb-1">Findings:</p>
                            <ul className="text-sm space-y-1">
                              {promptAnalysis.findings.map((finding, idx) => (
                                <li key={idx}>• {finding}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {promptAnalysis.suggestions && promptAnalysis.suggestions.length > 0 && (
                          <div>
                            <p className="font-semibold text-sm mb-1">Suggestions:</p>
                            <ul className="text-sm space-y-1">
                              {promptAnalysis.suggestions.map((suggestion, idx) => (
                                <li key={idx}>• {suggestion}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}

          <div className="flex gap-4">
            <Button onClick={() => setCurrentStep(2)} variant="outline" className="flex-1">
              Back to Details
            </Button>
            <Button 
              onClick={() => setCurrentStep(4)}
              disabled={!promptAnalyzed}
              className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-lg py-6"
            >
              Continue to Risk Assessment
            </Button>
          </div>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  // Step 4: Risk Assessment Questions (same structure as Concept Review)
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review - Risk Assessment</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-300">Progress</p>
            <p className="text-2xl font-bold text-[#FF9900]">{getProgressPercentage()}%</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Risk Assessment</h2>
          <p className="text-lg text-gray-600">
            Answer all questions about your completed product. Each category has 2 questions.
          </p>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-blue-800">
            <strong>Instructions:</strong> Answer all questions below based on your final product implementation. 
            Your total score will determine your risk zone and deployment recommendations.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {questions.map((category, categoryIdx) => (
            <Card key={categoryIdx}>
              <CardHeader>
                <CardTitle className="text-[#232F3E]">{category.category}</CardTitle>
                <CardDescription>{category.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {category.items.map((item) => (
                  <div key={item.id} className="pb-4 border-b last:border-b-0 last:pb-0">
                    <Label className="text-base mb-3 block font-medium">{item.question}</Label>
                    <RadioGroup
                      value={answers[item.id]?.answer}
                      onValueChange={(value) => {
                        const optionIndex = item.options.findIndex(opt => opt.text === value);
                        handleAnswer(item.id, optionIndex);
                      }}
                      required
                    >
                      <div className="space-y-2">
                        {item.options.map((option, optIdx) => (
                          <div 
                            key={optIdx} 
                            className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                              answers[item.id]?.answer === option.text 
                                ? 'border-[#FF9900] bg-orange-50' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <RadioGroupItem value={option.text} id={`${item.id}-${optIdx}`} />
                            <Label 
                              htmlFor={`${item.id}-${optIdx}`} 
                              className="font-normal flex-1 cursor-pointer"
                            >
                              {option.text}
                              <span className={`ml-2 text-xs font-semibold ${
                                option.score === 0 ? 'text-green-600' :
                                option.score <= 3 ? 'text-yellow-600' :
                                'text-red-600'
                              }`}>
                                ({option.score} {option.score === 1 ? 'point' : 'points'})
                              </span>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}

          <div className="sticky bottom-4 bg-white border-2 border-gray-200 rounded-lg p-4 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">Progress: {getProgressPercentage()}% Complete</span>
              <span className="text-sm text-gray-600">
                {Object.keys(answers).length} / {questions.flatMap(c => c.items).length} answered
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div 
                className="bg-[#FF9900] h-2 rounded-full transition-all duration-300"
                style={{ width: `${getProgressPercentage()}%` }}
              ></div>
            </div>
            <div className="flex gap-4">
              <Button onClick={() => setCurrentStep(3)} variant="outline" className="flex-1" type="button">
                Back to Prompt Analysis
              </Button>
              <Button
                type="submit"
                disabled={Object.keys(answers).length < questions.flatMap(c => c.items).length}
                className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-white text-lg py-6"
              >
                Submit Product Review
              </Button>
            </div>
          </div>
        </form>
      </main>

      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE — SaferAI Framework
        </div>
      </footer>
    </div>
  );
};

export default ProductReview;

