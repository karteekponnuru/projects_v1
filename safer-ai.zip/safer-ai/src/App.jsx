import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import Home from './pages/Home';
import Mechanism from './pages/Mechanism';
import ConceptReview from './pages/ConceptReview';
import ProductReview from './pages/ProductReview';
import './App.css';

function Navigation() {
  const location = useLocation();
  
  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-[#232F3E] text-white py-4 px-8 border-b border-gray-700">
      <div className="max-w-7xl mx-auto flex gap-6">
        <Link to="/">
          <Button 
            variant="ghost" 
            className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/') ? 'text-[#FF9900]' : ''}`}
          >
            Home
          </Button>
        </Link>
        <Link to="/mechanism">
          <Button 
            variant="ghost" 
            className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/mechanism') ? 'text-[#FF9900]' : ''}`}
          >
            Mechanism
          </Button>
        </Link>
        <Link to="/concept-review">
          <Button 
            variant="ghost" 
            className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/concept-review') ? 'text-[#FF9900]' : ''}`}
          >
            Concept Review
          </Button>
        </Link>
        <Link to="/product-review">
          <Button 
            variant="ghost" 
            className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/product-review') ? 'text-[#FF9900]' : ''}`}
          >
            Product Review
          </Button>
        </Link>
      </div>
    </nav>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Navigation />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/mechanism" element={<Mechanism />} />
          <Route path="/concept-review" element={<ConceptReview />} />
          <Route path="/product-review" element={<ProductReview />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

