import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, Upload, ExternalLink, Loader2 } from 'lucide-react';

const ProductReview = () => {
  const [step, setStep] = useState(1);
  const [conceptPDF, setConceptPDF] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [promptAnalyzing, setPromptAnalyzing] = useState(false);
  const [promptScore, setPromptScore] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [totalScore, setTotalScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');

  const questions = [
    {
      section: 'Project Changes',
      items: [
        {
          id: 'changes',
          question: 'Did you make any major changes since your Concept Review?',
          options: [
            { text: 'No changes', score: 0 },
            { text: 'Added small improvements', score: 2 },
            { text: 'Added new features or data', score: 5 }
          ]
        },
        {
          id: 'platform_change',
          question: 'Did you use a different platform or tool from what you planned?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes, but internal', score: 2 },
            { text: 'Yes, a new or external one', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Prompts & Instructions',
      items: [
        {
          id: 'prompt_test',
          question: 'Did you test your prompt using the SaferAI Analyzer?',
          options: [
            { text: 'Yes, and no issues found', score: 0 },
            { text: 'Yes, with a few warnings', score: 2 },
            { text: "Didn't test or high-risk warnings", score: 5 }
          ]
        },
        {
          id: 'prompt_sensitive',
          question: 'Do your prompts include any internal or sensitive info?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Maybe some internal words', score: 3 },
            { text: 'Yes, customer or private data', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Data Handling',
      items: [
        {
          id: 'data_type',
          question: 'What kind of data does your bot now use?',
          options: [
            { text: 'Public or sample data', score: 0 },
            { text: 'Internal data', score: 2 },
            { text: 'Customer or private data', score: 5 }
          ]
        },
        {
          id: 'data_external',
          question: 'Does your bot send or store data outside Amazon systems?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes, but internal tools', score: 2 },
            { text: 'Yes, to third-party apps', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Permissions',
      items: [
        {
          id: 'access_level',
          question: 'What access does your bot need?',
          options: [
            { text: 'View-only', score: 0 },
            { text: 'Can edit/update some things', score: 3 },
            { text: 'Full admin or case access', score: 5 }
          ]
        },
        {
          id: 'credentials',
          question: 'Does your bot keep or reuse login details automatically?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Sometimes', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Outputs',
      items: [
        {
          id: 'output_visibility',
          question: 'Who can see the outputs of your bot?',
          options: [
            { text: 'My team only', score: 0 },
            { text: 'Other internal teams', score: 3 },
            { text: 'Anyone external', score: 5 }
          ]
        },
        {
          id: 'output_review',
          question: 'Are the outputs reviewed by a human before use?',
          options: [
            { text: 'Always', score: 0 },
            { text: 'Sometimes', score: 3 },
            { text: 'Never', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Integrations',
      items: [
        {
          id: 'integrations',
          question: 'Does your bot connect with any other tools?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Internal ones like Slack or Quip', score: 2 },
            { text: 'External public ones', score: 5 }
          ]
        },
        {
          id: 'token_storage',
          question: 'Are passwords or tokens stored securely?',
          options: [
            { text: 'Yes, handled safely', score: 0 },
            { text: 'Stored locally', score: 2 },
            { text: 'Hardcoded', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Stability',
      items: [
        {
          id: 'testing',
          question: 'Have you tested it for errors or weird results?',
          options: [
            { text: "Yes, it's reliable", score: 0 },
            { text: 'Sometimes glitches', score: 3 },
            { text: 'Not yet tested', score: 5 }
          ]
        },
        {
          id: 'failure_handling',
          question: 'If it fails, can it stop safely without breaking things?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Maybe', score: 3 },
            { text: 'No', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'Monitoring',
      items: [
        {
          id: 'logging',
          question: 'Do you have logs or some way to track what it does?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Partially', score: 2 },
            { text: 'No', score: 5 }
          ]
        },
        {
          id: 'monitoring',
          question: 'Is there someone responsible for watching how it behaves?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Not decided', score: 3 },
            { text: 'No', score: 5 }
          ]
        }
      ]
    }
  ];

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setConceptPDF(file);
    }
  };

  const analyzePrompt = async () => {
    setPromptAnalyzing(true);
    
    // Simulate API call to Lambda
    setTimeout(() => {
      // Simple risk analysis based on keywords
      let score = 0;
      const lowerPrompt = prompt.toLowerCase();
      
      if (lowerPrompt.includes('customer') || lowerPrompt.includes('ticket') || lowerPrompt.includes('case')) {
        score += 4;
      }
      if (lowerPrompt.includes('email') || lowerPrompt.includes('personal')) {
        score += 3;
      }
      if (lowerPrompt.includes('admin') || lowerPrompt.includes('delete')) {
        score += 3;
      }
      
      setPromptScore(Math.min(score, 10));
      setPromptAnalyzing(false);
    }, 2000);
  };

  const handleAnswer = (questionId, optionIndex) => {
    const allQuestions = questions.flatMap(section => section.items);
    const question = allQuestions.find(q => q.id === questionId);
    setAnswers({
      ...answers,
      [questionId]: {
        answer: question.options[optionIndex].text,
        score: question.options[optionIndex].score
      }
    });
  };

  const calculateFinalScore = () => {
    let score = 0;
    Object.values(answers).forEach(answer => {
      score += answer.score;
    });
    
    if (promptScore !== null) {
      score += promptScore;
    }
    
    // Normalize to 45 scale
    const normalizedScore = Math.round((score / 90) * 45);
    setTotalScore(normalizedScore);
    
    if (normalizedScore <= 18) {
      setRiskZone('green');
    } else if (normalizedScore <= 32) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }
  };

  const handleSubmit = () => {
    calculateFinalScore();
    setSubmitted(true);
  };

  const getRiskZoneDetails = () => {
    const zones = {
      green: {
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        title: 'Green Zone – Safe to Launch',
        color: 'bg-green-50 border-green-200',
        message: 'Your product works as planned with safe boundaries. Ready for deployment.',
        suggestions: [
          'Document deployment procedures',
          'Set up monitoring dashboards',
          'Schedule regular review cycles',
          'Proceed with launch'
        ]
      },
      amber: {
        icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
        title: 'Amber Zone – Needs Fixes',
        color: 'bg-yellow-50 border-yellow-200',
        message: 'Minor risks or unclear prompts detected. Address these before full deployment.',
        suggestions: [
          'Avoid customer wording in prompts',
          'Re-test after trimming integrations',
          'Add human review checkpoints',
          'Enhance logging and monitoring',
          'Resubmit after fixes'
        ]
      },
      red: {
        icon: <XCircle className="h-16 w-16 text-red-600" />,
        title: 'Red Zone – Rework Needed',
        color: 'bg-red-50 border-red-200',
        message: 'Data, permissions, or output handling is too risky. SWAT consultation required.',
        suggestions: [
          'Schedule SWAT consultation immediately',
          'Review data classification and access levels',
          'Consider alternative architectures',
          'Do not deploy without SWAT approval',
          'Document all security concerns'
        ]
      }
    };
    return zones[riskZone] || zones.green;
  };

  const downloadPDF = () => {
    alert('PDF download functionality would be implemented here. In production, this would generate a comprehensive PDF report of the product review.');
  };

  if (submitted) {
    const zoneDetails = getRiskZoneDetails();
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review Results</p>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-8 py-12">
          <Card className={`border-2 ${zoneDetails.color} mb-8`}>
            <CardHeader>
              <div className="flex items-center gap-4">
                {zoneDetails.icon}
                <div>
                  <CardTitle className="text-2xl mb-2">{zoneDetails.title}</CardTitle>
                  <p className="text-gray-700">{zoneDetails.message}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-2">Final Score: {totalScore} / 45</h3>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full ${
                      riskZone === 'green' ? 'bg-green-500' :
                      riskZone === 'amber' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(totalScore / 45) * 100}%` }}
                  ></div>
                </div>
              </div>

              {promptScore !== null && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-semibold mb-2">Prompt Analysis Results</h3>
                  <p className="text-sm">Risk score: {promptScore} / 10</p>
                  {promptScore > 5 && (
                    <p className="text-sm text-red-600 mt-2">
                      ⚠️ Prompt contains references to sensitive data or operations
                    </p>
                  )}
                </div>
              )}

              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3">Suggestions:</h3>
                <ul className="space-y-2">
                  {zoneDetails.suggestions.map((suggestion, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#FF9900] mt-1">•</span>
                      <span>{suggestion}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-4">
                <Button onClick={downloadPDF} className="bg-[#232F3E] hover:bg-[#1a2332]">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF Report
                </Button>
                {riskZone === 'red' && (
                  <a href="https://asana.amazon.com/create?project=SWAT_Consultations" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Contact SWAT
                    </Button>
                  </a>
                )}
                <Button onClick={() => { setSubmitted(false); setStep(1); }} variant="outline">
                  Start New Review
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Score Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {questions.map((section, idx) => (
                  <div key={idx}>
                    <h4 className="font-semibold mb-2">{section.section}</h4>
                    <div className="space-y-2 ml-4">
                      {section.items.map((item) => (
                        <div key={item.id} className="flex justify-between text-sm">
                          <span className="text-gray-600">{item.question}</span>
                          <span className="font-medium">
                            {answers[item.id]?.score || 0} points
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                {promptScore !== null && (
                  <div className="pt-4 border-t">
                    <div className="flex justify-between">
                      <span className="font-semibold">Prompt Analysis</span>
                      <span className="font-medium">{promptScore} points</span>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">SaferAI</h1>
          <p className="text-sm text-gray-300 mt-1">Product Review</p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Product Review</h2>
          <p className="text-lg text-gray-600">
            Review your completed AI agent to ensure it matches your original concept and meets security standards.
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className={`flex items-center ${step >= 1 ? 'text-[#FF9900]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-[#FF9900] text-white' : 'bg-gray-200'}`}>1</div>
              <span className="ml-2 text-sm font-medium">Upload Concept</span>
            </div>
            <div className={`flex-1 h-1 mx-4 ${step >= 2 ? 'bg-[#FF9900]' : 'bg-gray-200'}`}></div>
            <div className={`flex items-center ${step >= 2 ? 'text-[#FF9900]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-[#FF9900] text-white' : 'bg-gray-200'}`}>2</div>
              <span className="ml-2 text-sm font-medium">Prompt Analysis</span>
            </div>
            <div className={`flex-1 h-1 mx-4 ${step >= 3 ? 'bg-[#FF9900]' : 'bg-gray-200'}`}></div>
            <div className={`flex items-center ${step >= 3 ? 'text-[#FF9900]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-[#FF9900] text-white' : 'bg-gray-200'}`}>3</div>
              <span className="ml-2 text-sm font-medium">Review Questions</span>
            </div>
          </div>
        </div>

        {/* Step 1: Upload Concept Review */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Upload Concept Review (Optional)</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Upload your Concept Review PDF to compare planned vs. built features.
              </p>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <Label htmlFor="concept-upload" className="cursor-pointer">
                  <span className="text-[#FF9900] hover:underline">Click to upload</span> or drag and drop
                </Label>
                <Input
                  id="concept-upload"
                  type="file"
                  accept=".pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                {conceptPDF && (
                  <p className="mt-4 text-sm text-green-600">✓ {conceptPDF.name} uploaded</p>
                )}
              </div>
              <div className="mt-6 flex gap-4">
                <Button onClick={() => setStep(2)} className="bg-[#FF9900] hover:bg-[#ec8f00]">
                  Continue to Prompt Analysis
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Prompt Analysis */}
        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 2: Prompt Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Paste your main prompt or example input to analyze for security risks.
              </p>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter your prompt here..."
                rows={6}
                className="mb-4"
              />
              <div className="flex gap-4">
                <Button
                  onClick={analyzePrompt}
                  disabled={!prompt || promptAnalyzing}
                  className="bg-[#232F3E] hover:bg-[#1a2332]"
                >
                  {promptAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    'Analyze Prompt'
                  )}
                </Button>
                {promptScore !== null && (
                  <Button onClick={() => setStep(3)} className="bg-[#FF9900] hover:bg-[#ec8f00]">
                    Continue to Questions
                  </Button>
                )}
              </div>
              {promptScore !== null && (
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Analysis Results</h4>
                  <p className="text-sm mb-2">Risk score: {promptScore} / 10</p>
                  {promptScore > 5 ? (
                    <div className="text-sm text-red-600">
                      <p className="font-medium">⚠️ Findings:</p>
                      <ul className="list-disc ml-5 mt-2">
                        <li>Prompt may reference sensitive data</li>
                        <li>Consider using summary metadata instead of full content</li>
                      </ul>
                    </div>
                  ) : (
                    <p className="text-sm text-green-600">✓ No major issues detected</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Step 3: Review Questions */}
        {step === 3 && (
          <div className="space-y-6">
            {questions.map((section, sectionIdx) => (
              <Card key={sectionIdx}>
                <CardHeader>
                  <CardTitle>{section.section}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {section.items.map((item) => (
                    <div key={item.id}>
                      <Label className="text-base mb-3 block">{item.question}</Label>
                      <RadioGroup
                        value={answers[item.id]?.answer}
                        onValueChange={(value) => {
                          const optionIndex = item.options.findIndex(opt => opt.text === value);
                          handleAnswer(item.id, optionIndex);
                        }}
                      >
                        {item.options.map((option, optIdx) => (
                          <div key={optIdx} className="flex items-center space-x-2">
                            <RadioGroupItem value={option.text} id={`${item.id}-${optIdx}`} />
                            <Label htmlFor={`${item.id}-${optIdx}`} className="font-normal">
                              {option.text}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}

            <Button
              onClick={handleSubmit}
              disabled={Object.keys(answers).length < questions.flatMap(s => s.items).length}
              className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white text-lg py-6"
            >
              Submit Product Review
            </Button>
          </div>
        )}
      </main>

      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE
        </div>
      </footer>
    </div>
  );
};

export default ProductReview;

