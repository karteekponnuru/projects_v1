import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

const Mechanism = () => {
  const riskVectors = [
    { name: 'Data Sensitivity', description: 'What type of data the agent will process', example: 'Customer content → higher risk' },
    { name: 'Access Level', description: 'Whether it requires privileged systems', example: 'Case data access → higher risk' },
    { name: 'Integrations', description: 'Whether data leaves the Amazon environment', example: 'Slack or Sheets API → moderate risk' },
    { name: 'Output Safety', description: 'If generated outputs could contain sensitive info', example: 'Public docs or open messages → moderate risk' },
    { name: 'Prompt Security', description: 'Whether prompts expose internal context', example: 'Overly broad LLM prompts → moderate risk' },
    { name: 'Business Impact', description: 'How critical or automated the function is', example: 'High-impact workflows → higher risk' },
    { name: 'Governance & Logging', description: 'If usage can be audited', example: 'Missing log → medium risk' },
    { name: 'Monitoring', description: 'If outputs can be continuously reviewed', example: 'No review → medium risk' }
  ];

  const compatibilityMatrix = [
    {
      platform: 'Party Rock',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '❌', internal_docs: '❌', partner_data: '❌', security_data: '❌' },
      integration: '✅ Public only'
    },
    {
      platform: 'Cedric',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '❌', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '⚠️ Slack, Quip'
    },
    {
      platform: 'Amazon Q Internal',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '✅', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '⚠️ Internal tools'
    },
    {
      platform: 'Mentor',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '✅', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '⚠️ Slack only'
    },
    {
      platform: 'Field Advisor',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '✅', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '⚠️ AWSentral only'
    },
    {
      platform: 'Matome',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '❌', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '✅ Quip only'
    },
    {
      platform: 'BedrockBot',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '✅', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '✅ Slack (Bedrock API)'
    },
    {
      platform: 'Loki',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '✅', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '⚠️ Validation workflows'
    },
    {
      platform: 'Clue / PowerChat',
      data: { customer_account: '✅', customer_content: '❌', aws_support: '✅', internal_docs: '✅', partner_data: '✅', security_data: '❌' },
      integration: '⚠️ Limited internal'
    }
  ];

  const examples = [
    {
      zone: 'Green Zone',
      icon: <CheckCircle2 className="h-12 w-12 text-green-600" />,
      color: 'bg-green-50 border-green-200',
      idea: 'Summarize internal meeting notes using Cedric.',
      data: 'Internal Business Docs',
      result: 'Green Zone – Ready to Build',
      explanation: 'Cedric supports summarization of internal documents with no sensitive exposure.'
    },
    {
      zone: 'Amber Zone',
      icon: <AlertTriangle className="h-12 w-12 text-yellow-600" />,
      color: 'bg-yellow-50 border-yellow-200',
      idea: 'Automate workflow status updates using Mentor.',
      data: 'AWS Support Data',
      result: 'Amber Zone – Design with Care',
      explanation: 'Mentor supports AWS Support Data but automation functions should include usage logging.'
    },
    {
      zone: 'Red Zone',
      icon: <XCircle className="h-12 w-12 text-red-600" />,
      color: 'bg-red-50 border-red-200',
      idea: 'Use Cedric to analyze customer chat transcripts.',
      data: 'Customer Content',
      result: 'Red Zone – Needs Rework',
      explanation: 'Customer content is not approved for Cedric. Choose an app approved for that data type.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">SaferAI</h1>
          <p className="text-sm text-gray-300 mt-1">
            Security Assessment Framework for Evaluating Risk in AI Agents
          </p>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-gray-50 to-white py-16 px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">How SaferAI Works</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transparent, consistent, risk-aware evaluation for every AI idea.
          </p>
        </div>
      </section>

      {/* Evaluation Flow */}
      <section className="py-12 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-gray-900 mb-8">How SaferAI Evaluates an Idea</h3>
          <div className="grid md:grid-cols-4 gap-4 mb-12">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-lg">1. Input Capture</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">You describe your use case and select the app and data type.</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-lg">2. Policy Matching</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">SaferAI checks your selections against AWS AppSec-approved rules.</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-lg">3. Risk Profiling</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">It assesses data sensitivity, integration points, and output exposure.</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-lg">4. Outcome & Guidance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">You receive a named classification with clear reasoning and next steps.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Risk Vectors */}
      <section className="py-12 px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">The SaferAI Risk Model</h3>
          <p className="text-lg text-gray-600 mb-8">
            SaferAI uses eight vectors to assess potential exposure or misuse. Each is scored internally, 
            and the combined score places the idea in one of three risk zones.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {riskVectors.map((vector, idx) => (
              <Card key={idx} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-base">{vector.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-2">{vector.description}</p>
                  <p className="text-xs text-gray-500 italic">{vector.example}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Risk Zones */}
      <section className="py-12 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-gray-900 mb-8">Risk Zones</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-2 border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <CheckCircle2 className="h-6 w-6" />
                  Green Zone
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Ready to Build</p>
                <p className="text-sm text-gray-700 mb-2">Idea aligns with policy and approved use cases</p>
                <p className="text-sm font-medium text-green-700">Action: Developer can proceed</p>
              </CardContent>
            </Card>

            <Card className="border-2 border-yellow-200 bg-yellow-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-800">
                  <AlertTriangle className="h-6 w-6" />
                  Amber Zone
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Design with Care</p>
                <p className="text-sm text-gray-700 mb-2">Some parameters need validation before scaling</p>
                <p className="text-sm font-medium text-yellow-700">Action: Check data sources and integrations</p>
              </CardContent>
            </Card>

            <Card className="border-2 border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-800">
                  <XCircle className="h-6 w-6" />
                  Red Zone
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Needs Rework</p>
                <p className="text-sm text-gray-700 mb-2">Idea involves restricted data or unapproved tools</p>
                <p className="text-sm font-medium text-red-700">Action: Modify design and retry</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Compatibility Matrix */}
      <section className="py-12 px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Platform & Data Compatibility Matrix</h3>
          <p className="text-lg text-gray-600 mb-8">
            This matrix helps developers pick the right platform for their use case.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-lg shadow">
              <thead className="bg-[#232F3E] text-white">
                <tr>
                  <th className="p-3 text-left">Platform</th>
                  <th className="p-3 text-center">Customer Account Info</th>
                  <th className="p-3 text-center">Customer Content</th>
                  <th className="p-3 text-center">AWS Support Data</th>
                  <th className="p-3 text-center">Internal Docs</th>
                  <th className="p-3 text-center">Partner Data</th>
                  <th className="p-3 text-center">Security Data</th>
                  <th className="p-3 text-center">Integration Allowed</th>
                </tr>
              </thead>
              <tbody>
                {compatibilityMatrix.map((row, idx) => (
                  <tr key={idx} className="border-b hover:bg-gray-50">
                    <td className="p-3 font-medium">{row.platform}</td>
                    <td className="p-3 text-center">{row.data.customer_account}</td>
                    <td className="p-3 text-center">{row.data.customer_content}</td>
                    <td className="p-3 text-center">{row.data.aws_support}</td>
                    <td className="p-3 text-center">{row.data.internal_docs}</td>
                    <td className="p-3 text-center">{row.data.partner_data}</td>
                    <td className="p-3 text-center">{row.data.security_data}</td>
                    <td className="p-3 text-center text-sm">{row.integration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex gap-4 text-sm">
            <span className="flex items-center gap-2"><span className="text-green-600">✅</span> Safe</span>
            <span className="flex items-center gap-2"><span className="text-yellow-600">⚠️</span> Caution</span>
            <span className="flex items-center gap-2"><span className="text-red-600">❌</span> Not Allowed</span>
          </div>
        </div>
      </section>

      {/* Real-World Examples */}
      <section className="py-12 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-3xl font-bold text-gray-900 mb-8">Real-World Examples</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {examples.map((example, idx) => (
              <Card key={idx} className={`border-2 ${example.color}`}>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    {example.icon}
                    <CardTitle className="text-lg">{example.zone}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="font-semibold mb-2">Idea:</p>
                  <p className="text-sm mb-3">{example.idea}</p>
                  <p className="font-semibold mb-1">Data: <span className="font-normal">{example.data}</span></p>
                  <p className="font-semibold mb-1">Result: <span className="font-normal">{example.result}</span></p>
                  <p className="text-sm text-gray-700 mt-3">{example.explanation}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Developer Guidance */}
      <section className="py-12 px-8 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">SaferAI's Goal</h3>
          <p className="text-lg text-gray-700 mb-4">
            SaferAI isn't about control — it's about clarity. Every builder deserves to know what's safe to create, 
            what needs extra care, and how to stay within policy boundaries.
          </p>
          <p className="text-xl font-semibold text-[#FF9900]">
            Build boldly. SaferAI will make sure you do it safely.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE
        </div>
      </footer>
    </div>
  );
};

export default Mechanism;

