import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { X, ArrowRight } from 'lucide-react';

const Home = () => {
  const [showChat, setShowChat] = useState(false);
  const [chatFlow, setChatFlow] = useState('');
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState({});

  const startChat = (flow) => {
    setChatFlow(flow);
    setShowChat(true);
    setCurrentStep(0);
    setAnswers({});
  };

  const closeChat = () => {
    setShowChat(false);
    setChatFlow('');
    setCurrentStep(0);
    setAnswers({});
  };

  const handleAnswer = (question, answer) => {
    setAnswers({ ...answers, [question]: answer });
    setCurrentStep(currentStep + 1);
  };

  const chatFlows = {
    getting_started: [
      {
        question: 'What are you trying to build or automate?',
        options: [
          { text: 'Summarize or analyze internal data', next: 'data_check' },
          { text: 'Automate TT or SIM workflows', result: 'swat_review' },
          { text: 'Generate or review documents (PRFAQ, MBR, etc.)', next: 'data_check' },
          { text: 'Integrate with external tools or APIs', result: 'tt_required' },
          { text: 'Build a new GenAI app or model', result: 'swat_review' }
        ]
      },
      {
        id: 'data_check',
        question: 'What kind of data will your agent use?',
        options: [
          { text: 'Customer data or content', result: 'swat_review' },
          { text: 'AWS Support data', next: 'app_selection' },
          { text: 'Internal business docs/contracts', next: 'app_selection' },
          { text: 'Employee or operational data', next: 'app_selection' },
          { text: 'Public/non-sensitive data', result: 'safe_proceed' }
        ]
      },
      {
        id: 'app_selection',
        question: 'Which app or tool are you planning to use?',
        options: [
          { text: 'Cedric', result: 'safe_proceed' },
          { text: 'Amazon Q Internal', result: 'safe_proceed' },
          { text: 'Mentor', result: 'safe_proceed' },
          { text: 'Party Rock', result: 'safe_proceed' },
          { text: 'Other / Not sure', result: 'safe_proceed' }
        ]
      }
    ],
    questions: [
      {
        question: 'Will your automation access or modify TTs or SIMs?',
        options: [
          { text: 'Yes', result: 'swat_review' },
          { text: 'No', next: 'data_usage' }
        ]
      },
      {
        id: 'data_usage',
        question: 'Will your agent process customer data or internal operational data?',
        options: [
          { text: 'Customer Data', result: 'swat_review' },
          { text: 'Internal Data', next: 'access_check' }
        ]
      },
      {
        id: 'access_check',
        question: 'Does your agent require Unfettered Search or Case Locker access?',
        options: [
          { text: 'Yes', result: 'swat_review' },
          { text: 'No', next: 'integration_check' }
        ]
      },
      {
        id: 'integration_check',
        question: 'Will your agent use or share data with external tools (like Slack, Google Sheets, or APIs)?',
        options: [
          { text: 'Yes', result: 'tt_required' },
          { text: 'No', result: 'safe_proceed' }
        ]
      }
    ],
    ready_to_build: [
      {
        question: 'Have you already designed your agent or automation?',
        options: [
          { text: 'Yes, ready for review', result: 'start_review' },
          { text: 'Still planning', next: 'use_case' }
        ]
      },
      {
        id: 'use_case',
        question: 'What will your agent do?',
        options: [
          { text: 'Document summarization', next: 'data_type' },
          { text: 'Ticket automation', result: 'swat_review' },
          { text: 'Data analysis', next: 'data_type' },
          { text: 'External integration', result: 'tt_required' }
        ]
      },
      {
        id: 'data_type',
        question: 'What data will it use?',
        options: [
          { text: 'Internal documents', result: 'safe_proceed' },
          { text: 'Customer data', result: 'swat_review' },
          { text: 'Public data', result: 'safe_proceed' }
        ]
      }
    ]
  };

  const getResult = (resultType) => {
    const results = {
      safe_proceed: {
        icon: '✅',
        title: 'Safe to Build',
        message: 'Your idea aligns with policy and approved use cases. You can proceed with development.',
        action: 'Proceed and document usage',
        color: 'bg-green-50 border-green-200'
      },
      tt_required: {
        icon: '⚠️',
        title: 'Needs TT',
        message: 'External integration or special API use requires visibility. Please raise a TT for security vetting.',
        action: 'Raise a TT',
        color: 'bg-yellow-50 border-yellow-200'
      },
      swat_review: {
        icon: '🔴',
        title: 'Requires SWAT Review',
        message: 'Customer data, UFS, or production system access detected. SWAT consultation required before proceeding.',
        action: 'Raise SWAT Consultation',
        color: 'bg-red-50 border-red-200',
        link: 'https://asana.amazon.com/create?project=SWAT_Consultations'
      },
      start_review: {
        icon: '⚙️',
        title: 'Ready for Review',
        message: 'Great! You can start the formal review process.',
        action: 'Go to Concept Review',
        color: 'bg-blue-50 border-blue-200',
        link: '/concept-review'
      }
    };
    return results[resultType] || results.safe_proceed;
  };

  const getCurrentQuestion = () => {
    const flow = chatFlows[chatFlow];
    if (!flow || currentStep >= flow.length) return null;

    let question = flow[currentStep];
    
    // Handle navigation through steps
    if (currentStep > 0 && answers[flow[currentStep - 1].question]) {
      const lastAnswer = answers[flow[currentStep - 1].question];
      const selectedOption = flow[currentStep - 1].options.find(opt => opt.text === lastAnswer);
      
      if (selectedOption?.next) {
        // Find the next question by id
        const nextQuestion = flow.find(q => q.id === selectedOption.next);
        if (nextQuestion) {
          question = nextQuestion;
        }
      }
    }

    return question;
  };

  const renderChatContent = () => {
    const currentQuestion = getCurrentQuestion();
    
    if (!currentQuestion) {
      // Check if we have a result
      const lastQuestion = chatFlows[chatFlow][chatFlows[chatFlow].length - 1];
      const lastAnswer = answers[lastQuestion.question];
      if (lastAnswer) {
        const selectedOption = lastQuestion.options.find(opt => opt.text === lastAnswer);
        if (selectedOption?.result) {
          const result = getResult(selectedOption.result);
          return (
            <div className={`p-6 rounded-lg border-2 ${result.color}`}>
              <div className="text-4xl mb-4">{result.icon}</div>
              <h3 className="text-xl font-bold mb-2">{result.title}</h3>
              <p className="mb-4 text-gray-700">{result.message}</p>
              {result.link ? (
                <a href={result.link} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                    {result.action} <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </a>
              ) : (
                <Button className="bg-[#FF9900] hover:bg-[#ec8f00]" onClick={closeChat}>
                  {result.action}
                </Button>
              )}
            </div>
          );
        }
      }
      return null;
    }

    // Check if current answer leads to a result
    if (currentStep > 0) {
      const prevQuestion = chatFlows[chatFlow][currentStep - 1];
      const prevAnswer = answers[prevQuestion.question];
      if (prevAnswer) {
        const selectedOption = prevQuestion.options.find(opt => opt.text === prevAnswer);
        if (selectedOption?.result) {
          const result = getResult(selectedOption.result);
          return (
            <div className={`p-6 rounded-lg border-2 ${result.color}`}>
              <div className="text-4xl mb-4">{result.icon}</div>
              <h3 className="text-xl font-bold mb-2">{result.title}</h3>
              <p className="mb-4 text-gray-700">{result.message}</p>
              {result.link ? (
                <a href={result.link} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                    {result.action} <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </a>
              ) : (
                <Button className="bg-[#FF9900] hover:bg-[#ec8f00]" onClick={closeChat}>
                  {result.action}
                </Button>
              )}
            </div>
          );
        }
      }
    }

    return (
      <div>
        <div className="mb-6">
          <p className="text-lg font-medium mb-4">{currentQuestion.question}</p>
          <div className="space-y-2">
            {currentQuestion.options.map((option, idx) => (
              <Button
                key={idx}
                onClick={() => handleAnswer(currentQuestion.question, option.text)}
                className="w-full justify-start text-left bg-white hover:bg-gray-50 text-gray-900 border border-gray-300"
              >
                {option.text}
              </Button>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">
              Security Assessment Framework for Evaluating Risk in AI Agents
            </p>
          </div>
          <div className="flex gap-4 text-sm">
            <a href="#" className="hover:text-[#FF9900] transition-colors">Help</a>
            <a href="#" className="hover:text-[#FF9900] transition-colors">Documentation</a>
            <a href="#" className="hover:text-[#FF9900] transition-colors">Contact SWAT</a>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">SaferAI Guidance Bot</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Build confidently. I'll help you understand what's safe to build, what data you can use, 
            and when to raise a request.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer bg-[#F3F3F3]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">🧩</span>
                Getting Started
              </CardTitle>
              <CardDescription className="text-base">
                "I don't know what kind of automation or agent I can build."
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => startChat('getting_started')}
                className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white"
              >
                Start Guidance
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer bg-[#F3F3F3]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">💬</span>
                Have Questions
              </CardTitle>
              <CardDescription className="text-base">
                "I want to understand what's allowed or what data I can use."
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => startChat('questions')}
                className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white"
              >
                Ask Me
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer bg-[#F3F3F3]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">⚙️</span>
                Ready to Build
              </CardTitle>
              <CardDescription className="text-base">
                "I already have an idea or agent and want to check if it's compliant."
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => startChat('ready_to_build')}
                className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white"
              >
                Start Review
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Chat Panel */}
      {showChat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <div className="sticky top-0 bg-[#232F3E] text-white p-4 flex justify-between items-center rounded-t-lg">
              <h3 className="text-xl font-bold">SaferAI Guidance Bot</h3>
              <button onClick={closeChat} className="hover:bg-[#FF9900] p-2 rounded transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                <p className="text-gray-700">
                  👋 Hi! I'm your Guidance Bot. Let's figure out if your idea or automation is allowed to build safely.
                </p>
              </div>
              {renderChatContent()}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE
        </div>
      </footer>
    </div>
  );
};

export default Home;

