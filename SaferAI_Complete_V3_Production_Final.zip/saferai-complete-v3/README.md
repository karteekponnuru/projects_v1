# SaferAI Portal V3 - Complete Production Application

## 🎯 Overview

SaferAI Portal is a comprehensive AI security assessment tool that helps Amazon operations developers build AI solutions safely and compliantly. The portal features a **Guidance Bot** as the primary entry point, guiding users through concept and product reviews with structured risk assessment.

## ✨ Key Features

### 1. **Guidance Bot - Primary Entry Point**
- **Not a support widget** - it's the main feature
- Three clear entry paths on homepage:
  - 🧩 Getting Started - For users exploring what's acceptable
  - 💬 Have Questions - For policy and data rule clarification
  - ⚙️ Ready to Build - Direct access to Concept/Product Review
- Structured conversational flow with button-driven interactions
- Risk assessment and next-step recommendations

### 2. **Concept Review** (Before Build)
- 8 risk vector assessment (40 points max)
- New fields: Developer Login, Org Details, Development Type
- Platform compatibility guidance
- Go/no-go decision with PDF report
- Auto-save functionality

### 3. **Product Review** (After Build)
- 8 risk vector assessment + AI prompt analysis
- Same new fields as Concept Review
- Updated compliance question (no "Approved by SWAT" option)
- Comparison with previous Concept Review
- Enhanced PDF generation

### 4. **Post-Assessment Guidance**
- Risk-based contact recommendations:
  - 🟢 Low Risk → Proceed confidently
  - 🟡 Medium
