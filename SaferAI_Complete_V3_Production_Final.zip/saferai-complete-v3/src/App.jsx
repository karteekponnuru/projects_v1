import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import HomePage from './pages/HomePage';
import ConceptReviewPage from './pages/ConceptReviewPage';
import ProductReviewPage from './pages/ProductReviewPage';
import MechanismPage from './pages/MechanismPage';

function App() {
  return (
    <Router>
      <div style={{ minHeight: '100vh', backgroundColor: '#f5f7fa' }}>
        {/* Navigation */}
        <nav style={{
          backgroundColor: '#232f3e',
          padding: '15px 0',
          boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
          position: 'sticky',
          top: 0,
          zIndex: 1000
        }}>
          <div style={{
            maxWidth: '1400px',
            margin: '0 auto',
            padding: '0 20px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '15px'
          }}>
            <Link to="/" style={{
              fontSize: '24px',
              fontWeight: 'bold',
              color: '#ffffff',
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '10px'
            }}>
              <span style={{ fontSize: '28px' }}>🛡️</span>
              SaferAI Portal
            </Link>
            
            <div style={{ display: 'flex', gap: '20px', alignItems: 'center', flexWrap: 'wrap' }}>
              {[
                { to: '/', label: 'Home' },
                { to: '/mechanism', label: 'Platform Guide' },
                { to: '/concept-review', label: 'Concept Review' },
                { to: '/product-review', label: 'Product Review' }
              ].map(link => (
                <Link
                  key={link.to}
                  to={link.to}
                  style={{
                    color: '#ffffff',
                    textDecoration: 'none',
                    fontSize: '15px',
                    fontWeight: '500',
                    padding: '8px 15px',
                    borderRadius: '6px',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.15)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/concept-review" element={<ConceptReviewPage />} />
            <Route path="/product-review" element={<ProductReviewPage />} />
            <Route path="/mechanism" element={<MechanismPage />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer style={{
          backgroundColor: '#232f3e',
          color: '#ffffff',
          padding: '40px 20px',
          marginTop: '80px',
          textAlign: 'center'
        }}>
          <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
            <p style={{ marginBottom: '10px', fontSize: '16px', fontWeight: '500' }}>
              SaferAI Portal - Democratizing AI Security Assessment
            </p>
            <p style={{ fontSize: '14px', opacity: 0.8, marginBottom: '15px' }}>
              Built by CTOSS SWAT Team
            </p>
            <div style={{ fontSize: '14px', opacity: 0.9 }}>
              <span>📧 swat-team@amazon.com</span>
              <span style={{ margin: '0 15px' }}>|</span>
              <span>💬 #ctoss-swat</span>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
