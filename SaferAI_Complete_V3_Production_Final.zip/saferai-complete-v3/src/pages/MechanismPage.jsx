import React, { useState } from 'react';
import { SaferAIScoringEngine } from '../lib/scoringEngine';

const MechanismPage = () => {
  const [selectedCell, setSelectedCell] = useState(null);
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [selectedDataType, setSelectedDataType] = useState('all');
  const [showScoring, setShowScoring] = useState(false);

  const containerStyle = {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '40px 20px'
  };

  const sectionStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    padding: '40px',
    marginBottom: '30px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  };

  const titleStyle = {
    fontSize: '32px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '20px',
    textAlign: 'center'
  };

  const subtitleStyle = {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '20px'
  };

  const descriptionStyle = {
    fontSize: '16px',
    color: '#666666',
    lineHeight: '1.6',
    marginBottom: '30px'
  };

  const platforms = {
    'partyrock': 'PartyRock',
    'amazon-q-business': 'Amazon Q Business',
    'bedrock-playground': 'Bedrock Playground',
    'approved-chatbots': 'Approved Chatbots',
    'custom-bedrock': 'Custom Bedrock'
  };

  const dataTypes = {
    'public': 'Public',
    'internal': 'Internal',
    'confidential': 'Confidential',
    'highly-confidential': 'Highly Confidential',
    'restricted': 'Restricted'
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return '#28a745';
      case 'review': return '#ffc107';
      case 'restricted': return '#fd7e14';
      case 'blocked': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'approved': return 'Approved';
      case 'review': return 'Needs Review';
      case 'restricted': return 'Restricted';
      case 'blocked': return 'Blocked';
      default: return 'Unknown';
    }
  };

  const filterStyle = {
    display: 'flex',
    gap: '20px',
    marginBottom: '30px',
    flexWrap: 'wrap',
    alignItems: 'center'
  };

  const selectStyle = {
    padding: '8px 12px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    fontSize: '14px',
    backgroundColor: '#ffffff'
  };

  const matrixStyle = {
    overflowX: 'auto',
    marginBottom: '30px'
  };

  const tableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    minWidth: '800px'
  };

  const headerStyle = {
    backgroundColor: '#f8f9fa',
    padding: '15px 10px',
    textAlign: 'center',
    fontWeight: 'bold',
    border: '1px solid #dee2e6',
    fontSize: '14px'
  };

  const cellStyle = {
    padding: '12px 8px',
    textAlign: 'center',
    border: '1px solid #dee2e6',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    fontSize: '12px',
    fontWeight: 'bold'
  };

  const modalStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    padding: '20px'
  };

  const modalContentStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    padding: '30px',
    maxWidth: '600px',
    width: '100%',
    maxHeight: '80vh',
    overflowY: 'auto',
    position: 'relative'
  };

  const closeButtonStyle = {
    position: 'absolute',
    top: '15px',
    right: '20px',
    background: 'none',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#666666'
  };

  const buttonStyle = {
    backgroundColor: '#ff9900',
    color: '#ffffff',
    padding: '12px 24px',
    borderRadius: '4px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    marginRight: '10px',
    marginBottom: '10px',
    transition: 'background-color 0.2s ease'
  };

  const shouldShowCell = (platform, dataType) => {
    if (selectedPlatform !== 'all' && platform !== selectedPlatform) return false;
    if (selectedDataType !== 'all' && dataType !== selectedDataType) return false;
    return true;
  };

  const openCellDetails = (platform, dataType) => {
    const compatibility = SaferAIScoringEngine.checkCompatibility(platform, dataType);
    setSelectedCell({
      platform: platforms[platform],
      dataType: dataTypes[dataType],
      ...compatibility
    });
  };

  return (
    <div style={containerStyle}>
      {/* Introduction */}
      <div style={sectionStyle}>
        <h1 style={titleStyle}>SaferAI Assessment Mechanism</h1>
        <p style={descriptionStyle}>
          Understanding how SaferAI evaluates AI applications on Amazon internal platforms. 
          This page explains our assessment methodology, platform compatibility matrix, 
          and scoring system to help you prepare for your security review.
        </p>
      </div>

      {/* Platform-Data Compatibility Matrix */}
      <div style={sectionStyle}>
        <h2 style={subtitleStyle}>Platform-Data Compatibility Matrix</h2>
        <p style={descriptionStyle}>
          Interactive matrix showing which Amazon internal platforms are compatible with different data types. 
          Click on any cell to see detailed requirements, examples, and approval timelines.
        </p>

        {/* Filters */}
        <div style={filterStyle}>
          <div>
            <label style={{ marginRight: '8px', fontWeight: 'bold' }}>Platform:</label>
            <select 
              value={selectedPlatform} 
              onChange={(e) => setSelectedPlatform(e.target.value)}
              style={selectStyle}
            >
              <option value="all">All Platforms</option>
              {Object.entries(platforms).map(([key, name]) => (
                <option key={key} value={key}>{name}</option>
              ))}
            </select>
          </div>
          <div>
            <label style={{ marginRight: '8px', fontWeight: 'bold' }}>Data Type:</label>
            <select 
              value={selectedDataType} 
              onChange={(e) => setSelectedDataType(e.target.value)}
              style={selectStyle}
            >
              <option value="all">All Data Types</option>
              {Object.entries(dataTypes).map(([key, name]) => (
                <option key={key} value={key}>{name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Legend */}
        <div style={{ marginBottom: '20px', display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '20px', height: '20px', backgroundColor: '#28a745', borderRadius: '4px' }}></div>
            <span style={{ fontSize: '14px' }}>Approved</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '20px', height: '20px', backgroundColor: '#ffc107', borderRadius: '4px' }}></div>
            <span style={{ fontSize: '14px' }}>Needs Review</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '20px', height: '20px', backgroundColor: '#fd7e14', borderRadius: '4px' }}></div>
            <span style={{ fontSize: '14px' }}>Restricted</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '20px', height: '20px', backgroundColor: '#dc3545', borderRadius: '4px' }}></div>
            <span style={{ fontSize: '14px' }}>Blocked</span>
          </div>
        </div>

        {/* Matrix Table */}
        <div style={matrixStyle}>
          <table style={tableStyle}>
            <thead>
              <tr>
                <th style={headerStyle}>Platform / Data Type</th>
                {Object.entries(dataTypes).map(([key, name]) => (
                  shouldShowCell('all', key) && (
                    <th key={key} style={headerStyle}>{name}</th>
                  )
                ))}
              </tr>
            </thead>
            <tbody>
              {Object.entries(platforms).map(([platformKey, platformName]) => (
                shouldShowCell(platformKey, 'all') && (
                  <tr key={platformKey}>
                    <td style={{...headerStyle, textAlign: 'left', fontWeight: 'bold'}}>
                      {platformName}
                    </td>
                    {Object.entries(dataTypes).map(([dataKey, dataName]) => {
                      if (!shouldShowCell('all', dataKey)) return null;
                      
                      const compatibility = SaferAIScoringEngine.checkCompatibility(platformKey, dataKey);
                      const bgColor = getStatusColor(compatibility.status);
                      
                      return (
                        <td 
                          key={`${platformKey}-${dataKey}`}
                          style={{
                            ...cellStyle,
                            backgroundColor: bgColor,
                            color: '#ffffff',
                            opacity: 0.9
                          }}
                          onClick={() => openCellDetails(platformKey, dataKey)}
                          onMouseEnter={(e) => {
                            e.target.style.opacity = '1';
                            e.target.style.transform = 'scale(1.05)';
                          }}
                          onMouseLeave={(e) => {
                            e.target.style.opacity = '0.9';
                            e.target.style.transform = 'scale(1)';
                          }}
                        >
                          {getStatusText(compatibility.status)}
                        </td>
                      );
                    })}
                  </tr>
                )
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Scoring System */}
      <div style={sectionStyle}>
        <h2 style={subtitleStyle}>Assessment Scoring System</h2>
        <p style={descriptionStyle}>
          SaferAI uses a simple 40-point scoring system to evaluate AI applications across 8 key security vectors. 
          Each vector is scored from 1-5 points based on risk level, with the total score determining overall risk.
        </p>

        <button 
          onClick={() => setShowScoring(!showScoring)}
          style={{...buttonStyle, marginBottom: '20px'}}
        >
          {showScoring ? 'Hide' : 'Show'} Interactive Scoring Calculator
        </button>

        {showScoring && (
          <div style={{
            backgroundColor: '#f8f9fa',
            padding: '30px',
            borderRadius: '8px',
            marginBottom: '20px'
          }}>
            <h3 style={{fontSize: '20px', marginBottom: '20px', color: '#232f3e'}}>
              Interactive Scoring Calculator
            </h3>
            <ScoringCalculator />
          </div>
        )}

        {/* Risk Vectors */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '20px',
          marginBottom: '30px'
        }}>
          {Object.entries(SaferAIScoringEngine.RISK_VECTORS).map(([key, vector]) => (
            <div key={key} style={{
              backgroundColor: '#f8f9fa',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid #e0e0e0'
            }}>
              <h4 style={{
                fontSize: '18px',
                fontWeight: 'bold',
                color: '#232f3e',
                marginBottom: '10px'
              }}>
                {vector.name}
              </h4>
              <p style={{
                fontSize: '14px',
                color: '#666666',
                marginBottom: '15px'
              }}>
                {vector.description}
              </p>
              <div style={{fontSize: '12px', color: '#888888'}}>
                <strong>Max Score:</strong> {vector.maxScore} points
              </div>
            </div>
          ))}
        </div>

        {/* Risk Levels */}
        <div style={{marginBottom: '30px'}}>
          <h3 style={{fontSize: '20px', marginBottom: '20px', color: '#232f3e'}}>
            Risk Level Thresholds
          </h3>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '20px'
          }}>
            <div style={{
              backgroundColor: '#d4edda',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid #c3e6cb'
            }}>
              <h4 style={{color: '#155724', marginBottom: '10px'}}>
                🟢 Green (0-16 points)
              </h4>
              <p style={{fontSize: '14px', color: '#155724'}}>
                Low risk - Your application follows security best practices with minimal additional requirements
              </p>
            </div>
            <div style={{
              backgroundColor: '#fff3cd',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid #ffeaa7'
            }}>
              <h4 style={{color: '#856404', marginBottom: '10px'}}>
                🟡 Amber (17-28 points)
              </h4>
              <p style={{fontSize: '14px', color: '#856404'}}>
                Medium risk - Some additional security controls and review may be required
              </p>
            </div>
            <div style={{
              backgroundColor: '#f8d7da',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid #f5c6cb'
            }}>
              <h4 style={{color: '#721c24', marginBottom: '10px'}}>
                🔴 Red (29-40 points)
              </h4>
              <p style={{fontSize: '14px', color: '#721c24'}}>
                High risk - Comprehensive security review and additional controls required
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Assessment Process */}
      <div style={sectionStyle}>
        <h2 style={subtitleStyle}>Assessment Process</h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '30px'
        }}>
          <div style={{textAlign: 'center'}}>
            <div style={{
              fontSize: '48px',
              marginBottom: '15px',
              color: '#ff9900'
            }}>1️⃣</div>
            <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
              Platform Selection
            </h4>
            <p style={{fontSize: '14px', color: '#666666'}}>
              Choose your Amazon internal platform and check compatibility with your data types
            </p>
          </div>
          <div style={{textAlign: 'center'}}>
            <div style={{
              fontSize: '48px',
              marginBottom: '15px',
              color: '#ff9900'
            }}>2️⃣</div>
            <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
              Risk Assessment
            </h4>
            <p style={{fontSize: '14px', color: '#666666'}}>
              Complete 40 questions across 8 security vectors with contextual help and guidance
            </p>
          </div>
          <div style={{textAlign: 'center'}}>
            <div style={{
              fontSize: '48px',
              marginBottom: '15px',
              color: '#ff9900'
            }}>3️⃣</div>
            <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
              Analysis & Recommendations
            </h4>
            <p style={{fontSize: '14px', color: '#666666'}}>
              Receive detailed analysis, risk score, and specific recommendations for improvement
            </p>
          </div>
          <div style={{textAlign: 'center'}}>
            <div style={{
              fontSize: '48px',
              marginBottom: '15px',
              color: '#ff9900'
            }}>4️⃣</div>
            <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
              Documentation
            </h4>
            <p style={{fontSize: '14px', color: '#666666'}}>
              Generate comprehensive PDF report with all findings and recommendations
            </p>
          </div>
        </div>
      </div>

      {/* Modal for cell details */}
      {selectedCell && (
        <div style={modalStyle} onClick={() => setSelectedCell(null)}>
          <div style={modalContentStyle} onClick={(e) => e.stopPropagation()}>
            <button 
              style={closeButtonStyle}
              onClick={() => setSelectedCell(null)}
            >
              ×
            </button>
            <h3 style={{
              fontSize: '24px',
              marginBottom: '20px',
              color: '#232f3e'
            }}>
              {selectedCell.platform} + {selectedCell.dataType} Data
            </h3>
            <div style={{
              padding: '15px',
              backgroundColor: getStatusColor(selectedCell.status),
              color: '#ffffff',
              borderRadius: '8px',
              marginBottom: '20px',
              textAlign: 'center',
              fontWeight: 'bold'
            }}>
              Status: {getStatusText(selectedCell.status).toUpperCase()}
            </div>
            <div style={{marginBottom: '20px'}}>
              <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
                Overview
              </h4>
              <p style={{fontSize: '16px', color: '#666666', lineHeight: '1.6'}}>
                {selectedCell.details}
              </p>
            </div>
            {selectedCell.examples && selectedCell.examples.length > 0 && (
              <div style={{marginBottom: '20px'}}>
                <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
                  Examples
                </h4>
                <ul style={{paddingLeft: '20px', color: '#666666'}}>
                  {selectedCell.examples.map((example, index) => (
                    <li key={index} style={{marginBottom: '5px'}}>{example}</li>
                  ))}
                </ul>
              </div>
            )}
            <div style={{marginBottom: '20px'}}>
              <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
                Requirements
              </h4>
              <ul style={{paddingLeft: '20px', color: '#666666'}}>
                {selectedCell.requirements.map((req, index) => (
                  <li key={index} style={{marginBottom: '5px'}}>{req}</li>
                ))}
              </ul>
            </div>
            <div style={{marginBottom: '20px'}}>
              <h4 style={{fontSize: '18px', marginBottom: '10px', color: '#232f3e'}}>
                Timeline
              </h4>
              <p style={{fontSize: '16px', color: '#666666'}}>
                {selectedCell.timeline}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Interactive Scoring Calculator Component
const ScoringCalculator = () => {
  const [scores, setScores] = useState({});
  
  const updateScore = (vector, score) => {
    setScores(prev => ({...prev, [vector]: score}));
  };

  const totalScore = Object.values(scores).reduce((sum, score) => sum + (score || 0), 0);
  const getRiskLevel = (score) => {
    if (score <= 16) return { level: 'Green', color: '#28a745' };
    if (score <= 28) return { level: 'Amber', color: '#ffc107' };
    return { level: 'Red', color: '#dc3545' };
  };

  const risk = getRiskLevel(totalScore);

  return (
    <div>
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '20px',
        marginBottom: '30px'
      }}>
        {Object.entries(SaferAIScoringEngine.RISK_VECTORS).map(([key, vector]) => (
          <div key={key} style={{
            backgroundColor: '#ffffff',
            padding: '20px',
            borderRadius: '8px',
            border: '1px solid #ddd'
          }}>
            <h4 style={{fontSize: '16px', marginBottom: '15px', color: '#232f3e'}}>
              {vector.name}
            </h4>
            <div style={{display: 'flex', gap: '10px', flexWrap: 'wrap'}}>
              {[1, 2, 3, 4, 5].map(score => (
                <button
                  key={score}
                  onClick={() => updateScore(key, score)}
                  style={{
                    padding: '8px 12px',
                    borderRadius: '4px',
                    border: '1px solid #ddd',
                    backgroundColor: scores[key] === score ? '#ff9900' : '#ffffff',
                    color: scores[key] === score ? '#ffffff' : '#333333',
                    cursor: 'pointer',
                    fontSize: '14px'
                  }}
                >
                  {score}
                </button>
              ))}
            </div>
            <div style={{marginTop: '10px', fontSize: '14px', color: '#666666'}}>
              Current: {scores[key] || 0}/5
            </div>
          </div>
        ))}
      </div>
      
      <div style={{
        backgroundColor: '#ffffff',
        padding: '30px',
        borderRadius: '8px',
        border: '2px solid ' + risk.color,
        textAlign: 'center'
      }}>
        <h3 style={{fontSize: '24px', marginBottom: '10px', color: '#232f3e'}}>
          Total Score: {totalScore}/40
        </h3>
        <div style={{
          fontSize: '20px',
          fontWeight: 'bold',
          color: risk.color,
          marginBottom: '10px'
        }}>
          Risk Level: {risk.level}
        </div>
        <p style={{fontSize: '16px', color: '#666666'}}>
          {SaferAIScoringEngine.getRiskDescription(risk.level)}
        </p>
      </div>
    </div>
  );
};

export default MechanismPage;
