import React, { useState, useRef, useEffect } from 'react';

const GuidanceBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      type: 'bot',
      text: 'Hi! I\'m your SaferAI guidance assistant. I can help you understand:\n\n• Platform compatibility and data classification\n• Scoring methodology and risk levels\n• How to complete concept and product reviews\n• What to do based on your risk assessment\n\nWhat would you like to know?'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const quickQuestions = [
    "What platforms can I use for my data type?",
    "How is the risk score calculated?",
    "What's the difference between concept and product review?",
    "What should I do if I get a high risk score?",
    "How do I handle PII data?",
    "What is prompt security testing?"
  ];

  const getResponse = (question) => {
    const lowerQ = question.toLowerCase();
    
    // Platform compatibility questions
    if (lowerQ.includes('platform') || lowerQ.includes('partyrock') || lowerQ.includes('bedrock') || lowerQ.includes('q business')) {
      return `**Platform Compatibility:**

SaferAI supports several Amazon internal platforms:

**Low-Code Solutions:**
• **PartyRock**: Best for Public and Internal data only. No PII or customer data.
• **Amazon Q Business**: Handles Public, Internal, and Confidential data with proper configuration.
• **Bedrock Playground**: For testing and development with Public/Internal data.
• **Approved Chatbots** (Cedric, Mentor, Field Advisor): Varies by chatbot configuration.

**High-Code Solutions:**
• **Custom Bedrock Integration**: Can handle all data types with proper security controls (Lambda, API Gateway, S3).

**Key Rule:** Always check the Platform-Data Compatibility Matrix on the Mechanism page for approved combinations!`;
    }
    
    // Scoring questions
    if (lowerQ.includes('score') || lowerQ.includes('calculate') || lowerQ.includes('risk level')) {
      return `**Risk Scoring System:**

SaferAI uses a simple 40-point system:

**8 Risk Vectors** (5 points each):
1. Data Sensitivity/Handling
2. Access Permissions/Level
3. Output Safety/Behavior
4. Prompt Security/Input Handling
5. External Integrations
6. Business Impact/Logging
7. Compliance & Review/Failure Handling
8. Monitoring/Compliance

**Each question** scores 0-5 points based on risk level.
**Total score** = Sum of all answers (0-40 points)

**Risk Levels:**
🟢 **Low (0-16)**: Safe to proceed
🟡 **Medium (17-28)**: File TT for visibility
🔴 **High (29-40)**: Raise SIM before proceeding

The scoring is transparent - you can see exactly how each answer contributes to your total!`;
    }
    
    // Concept vs Product review
    if (lowerQ.includes('difference') || lowerQ.includes('concept') || lowerQ.includes('product')) {
      return `**Concept Review vs Product Review:**

**Concept Review (Before Build):**
• Use this when planning your AI project
• Questions focus on what you "will" do
• Helps determine if your idea is feasible
• Guides platform selection
• Result: Go/No-Go decision before investing time

**Product Review (After Build):**
• Use this when your AI agent is built
• Questions focus on what you "did" build
• Includes actual prompt security testing
• Verifies implementation matches security requirements
• Can compare against your original concept review
• Result: Deployment approval decision

**Best Practice:** Always do a Concept Review first to avoid building something that won't pass security review!`;
    }
    
    // High risk score
    if (lowerQ.includes('high risk') || lowerQ.includes('red') || lowerQ.includes('29') || lowerQ.includes('sim')) {
      return `**High Risk Score (29-40 points):**

If you receive a high risk score, **do not proceed** without additional review:

**Immediate Actions:**
1. **Raise a SIM** (Security Incident Management) ticket
2. **Contact CTOSS SWAT team** for guidance
3. **Do not deploy** until approved

**Common Causes:**
• Processing PII, credentials, or security-sensitive data
• Admin or Unfettered Search access
• Autonomous actions without human review
• External/public user access
• No monitoring or logging
• Not reviewed by security team

**Options to Reduce Risk:**
• Use a different platform with better controls
• Reduce data sensitivity (anonymize, mask)
• Add human-in-the-loop approval
• Implement comprehensive logging
• Restrict access scope
• Add input validation and output review

Remember: High risk doesn't mean "no" - it means "needs expert review"!`;
    }
    
    // PII handling
    if (lowerQ.includes('pii') || lowerQ.includes('personal') || lowerQ.includes('customer data')) {
      return `**Handling PII and Customer Data:**

**Data Classification Levels:**
• **Public**: Marketing materials, public docs (✅ Most platforms)
• **Internal**: Business data, metrics (✅ Most platforms)
• **Confidential**: Employee data, internal strategies (⚠️ Limited platforms)
• **Restricted**: PII, customer content, credentials (🔴 Custom Bedrock only)

**PII Best Practices:**
1. **Avoid if possible**: Can you solve the problem without PII?
2. **Minimize collection**: Only collect what you absolutely need
3. **Mask/Anonymize**: Remove or hash identifiable information
4. **Use Custom Bedrock**: Don't use low-code platforms for PII
5. **Implement encryption**: Data at rest and in transit
6. **Add audit logging**: Track all PII access
7. **Set retention policies**: Delete data when no longer needed
8. **Get security review**: Always required for PII

**Platform Compatibility:**
• ❌ PartyRock: No PII allowed
• ❌ Bedrock Playground: No PII allowed
• ⚠️ Amazon Q Business: Limited, with approval
• ✅ Custom Bedrock: Yes, with proper controls`;
    }
    
    // Prompt security
    if (lowerQ.includes('prompt security') || lowerQ.includes('prompt test') || lowerQ.includes('injection')) {
      return `**Prompt Security Testing:**

During Product Review, SaferAI analyzes your actual prompt using AWS Bedrock to check for vulnerabilities.

**8 Security Checks (5 points each):**
1. **Role Clarity**: Does the prompt clearly define boundaries?
2. **Secret Exposure**: Any embedded keys, tokens, or credentials?
3. **Injection Resistance**: Can users override instructions?
4. **Input Sanitization**: Does it validate user input?
5. **Prompt Transparency**: Can users extract hidden instructions?
6. **Data/Instruction Separation**: Are they clearly separated?
7. **Safe Fallback**: Does it handle uncertainty securely?
8. **Output Validation**: Are outputs reviewed before action?

**Prompt Risk Levels:**
🟢 **Low (0-10)**: Safe to deploy
🟡 **Medium (11-25)**: Needs improvement
🔴 **High (26-40)**: Must fix before deployment

**Common Issues:**
• Hardcoded secrets in prompts
• No input validation
• Weak role definitions
• No fallback handling
• Instructions can be overridden

**Best Practices:**
• Use clear, specific role definitions
• Store secrets in environment variables
• Validate and sanitize all inputs
• Separate data from instructions
• Test with adversarial inputs`;
    }
    
    // Default helpful response
    return `I can help you with:

**Platform & Data:**
• Which platforms support which data types
• Data classification guidelines
• Platform-specific security requirements

**Scoring & Risk:**
• How the 40-point scoring works
• What each risk level means
• How to reduce your risk score

**Review Process:**
• When to use Concept vs Product review
• How to complete each review
• What to do with your results

**Security Topics:**
• Handling PII and sensitive data
• Prompt security best practices
• Access control and permissions
• Monitoring and logging requirements

Try asking a specific question, or click one of the quick questions above!`;
  };

  const handleSend = () => {
    if (!inputText.trim()) return;

    // Add user message
    const userMessage = { type: 'user', text: inputText };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate thinking delay
    setTimeout(() => {
      const botResponse = { type: 'bot', text: getResponse(inputText) };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 800);
  };

  const handleQuickQuestion = (question) => {
    setMessages(prev => [...prev, { type: 'user', text: question }]);
    setIsTyping(true);

    setTimeout(() => {
      const botResponse = { type: 'bot', text: getResponse(question) };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 800);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Styles
  const fabStyle = {
    position: 'fixed',
    bottom: '30px',
    right: '30px',
    width: '60px',
    height: '60px',
    borderRadius: '50%',
    backgroundColor: '#ff9900',
    color: '#ffffff',
    border: 'none',
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    cursor: 'pointer',
    fontSize: '28px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.3s ease',
    zIndex: 1000
  };

  const chatWindowStyle = {
    position: 'fixed',
    bottom: '100px',
    right: '30px',
    width: '400px',
    height: '600px',
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
    display: isOpen ? 'flex' : 'none',
    flexDirection: 'column',
    zIndex: 1000,
    overflow: 'hidden'
  };

  const headerStyle = {
    backgroundColor: '#232f3e',
    color: '#ffffff',
    padding: '20px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopLeftRadius: '12px',
    borderTopRightRadius: '12px'
  };

  const messagesContainerStyle = {
    flex: 1,
    overflowY: 'auto',
    padding: '20px',
    backgroundColor: '#f8f9fa'
  };

  const messageStyle = (type) => ({
    marginBottom: '15px',
    display: 'flex',
    justifyContent: type === 'user' ? 'flex-end' : 'flex-start'
  });

  const messageBubbleStyle = (type) => ({
    maxWidth: '80%',
    padding: '12px 16px',
    borderRadius: '12px',
    backgroundColor: type === 'user' ? '#ff9900' : '#ffffff',
    color: type === 'user' ? '#ffffff' : '#232f3e',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    whiteSpace: 'pre-wrap',
    lineHeight: '1.5',
    fontSize: '14px'
  });

  const inputContainerStyle = {
    padding: '15px',
    backgroundColor: '#ffffff',
    borderTop: '1px solid #e0e0e0',
    display: 'flex',
    gap: '10px'
  };

  const inputStyle = {
    flex: 1,
    padding: '10px 15px',
    border: '1px solid #e0e0e0',
    borderRadius: '20px',
    fontSize: '14px',
    outline: 'none',
    resize: 'none',
    fontFamily: 'inherit'
  };

  const sendButtonStyle = {
    backgroundColor: '#ff9900',
    color: '#ffffff',
    border: 'none',
    borderRadius: '50%',
    width: '40px',
    height: '40px',
    cursor: 'pointer',
    fontSize: '18px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'background-color 0.2s ease'
  };

  const quickQuestionsStyle = {
    padding: '10px 20px',
    backgroundColor: '#ffffff',
    borderTop: '1px solid #e0e0e0',
    maxHeight: '120px',
    overflowY: 'auto'
  };

  const quickQuestionButtonStyle = {
    display: 'block',
    width: '100%',
    textAlign: 'left',
    padding: '8px 12px',
    marginBottom: '5px',
    backgroundColor: '#f8f9fa',
    border: '1px solid #e0e0e0',
    borderRadius: '6px',
    fontSize: '12px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    color: '#232f3e'
  };

  return (
    <>
      {/* Floating Action Button */}
      <button
        style={fabStyle}
        onClick={() => setIsOpen(!isOpen)}
        onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
        onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
        title="Get Help"
      >
        {isOpen ? '✕' : '💬'}
      </button>

      {/* Chat Window */}
      <div style={chatWindowStyle}>
        {/* Header */}
        <div style={headerStyle}>
          <div>
            <div style={{ fontWeight: 'bold', fontSize: '18px' }}>SaferAI Assistant</div>
            <div style={{ fontSize: '12px', opacity: 0.8 }}>Always here to help</div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              color: '#ffffff',
              fontSize: '24px',
              cursor: 'pointer',
              padding: '0',
              width: '30px',
              height: '30px'
            }}
          >
            ✕
          </button>
        </div>

        {/* Quick Questions */}
        {messages.length === 1 && (
          <div style={quickQuestionsStyle}>
            <div style={{ fontSize: '12px', fontWeight: 'bold', marginBottom: '8px', color: '#666' }}>
              Quick questions:
            </div>
            {quickQuestions.slice(0, 3).map((q, idx) => (
              <button
                key={idx}
                style={quickQuestionButtonStyle}
                onClick={() => handleQuickQuestion(q)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#e8f4ff';
                  e.currentTarget.style.borderColor = '#ff9900';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#f8f9fa';
                  e.currentTarget.style.borderColor = '#e0e0e0';
                }}
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Messages */}
        <div style={messagesContainerStyle}>
          {messages.map((msg, idx) => (
            <div key={idx} style={messageStyle(msg.type)}>
              <div style={messageBubbleStyle(msg.type)}>
                {msg.text}
              </div>
            </div>
          ))}
          {isTyping && (
            <div style={messageStyle('bot')}>
              <div style={messageBubbleStyle('bot')}>
                <span style={{ opacity: 0.6 }}>Typing...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div style={inputContainerStyle}>
          <textarea
            style={inputStyle}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me anything about SaferAI..."
            rows="1"
          />
          <button
            style={sendButtonStyle}
            onClick={handleSend}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#e88b00'}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#ff9900'}
          >
            ➤
          </button>
        </div>
      </div>
    </>
  );
};

export default GuidanceBot;
