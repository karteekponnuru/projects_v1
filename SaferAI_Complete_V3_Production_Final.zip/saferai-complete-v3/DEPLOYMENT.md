# SaferAI Portal - Deployment Guide

## Quick Start

### Installation
```bash
cd saferai-complete-v3
pnpm install
```

### Development
```bash
pnpm run dev
```
Access at http://localhost:5173

### Production Build
```bash
pnpm run build
```
Output in `dist/` directory

## AWS Deployment

### S3 + CloudFront Setup

1. **Create S3 Bucket**
```bash
aws s3 mb s3://saferai-portal
aws s3 website s3://saferai-portal --index-document index.html
```

2. **Upload Build**
```bash
pnpm run build
aws s3 sync dist/ s3://saferai-portal/ --delete
```

3. **CloudFront Distribution**
- Create distribution pointing to S3 bucket
- Set default root object: index.html
- Enable HTTPS

4. **Invalidate Cache**
```bash
aws cloudfront create-invalidation --distribution-id YOUR_ID --paths "/*"
```

## Configuration

### API Endpoint
Edit `src/config.js`:
```javascript
export const API_CONFIG = {
  PRODUCT_REVIEW_ENDPOINT: 'https://your-api-gateway-url/prod-v1/product-review'
};
```

### Asana Integration (Optional)
Add Asana token to environment or config for consultation ticket creation.

## Testing

Run build to verify:
```bash
pnpm run build
```

Should complete without errors.

## Support

For deployment issues:
- Email: swat-team@amazon.com
- Slack: #ctoss-swat
