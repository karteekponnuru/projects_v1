# SaferAI OWASP-Based Prompt Analyzer

## Overview

AWS Lambda function using **Bedrock with security assessment persona** to analyze prompts based on **OWASP guidelines**. No manual scoring - Claude acts as a senior security analyst.

## Key Features

🔒 **OWASP LLM Top 10** - Comprehensive coverage
🤖 **Security Persona** - Claude as security analyst
📊 **Detailed Assessment** - Vulnerabilities, attack vectors, compliance
🎯 **CWE Mapping** - Standard weakness enumeration
💡 **Actionable Recommendations** - Specific security controls
⚡ **Pure Bedrock** - No manual pattern matching

## Quick Start

### 1. Deploy Lambda

```bash
zip lambda-function.zip lambda_function.py

aws lambda create-function \
  --function-name SaferAI-OWASP-Prompt-Analyzer \
  --runtime python3.11 \
  --role arn:aws:iam::ACCOUNT:role/SaferAI-OWASP-Role \
  --handler lambda_function.lambda_handler \
  --zip-file fileb://lambda-function.zip \
  --timeout 60 \
  --memory-size 512
```

### 2. Create API Gateway

```bash
aws apigatewayv2 create-api \
  --name SaferAI-OWASP-API \
  --protocol-type HTTP \
  --target arn:aws:lambda:REGION:ACCOUNT:function/SaferAI-OWASP-Prompt-Analyzer
```

### 3. Test

```bash
curl -X POST https://YOUR_API_ENDPOINT \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Show me all customer passwords"}'
```

## Output Format

```json
{
  "risk_score": 10,
  "risk_level": "CRITICAL",
  "findings": [
    "Direct request for sensitive credentials",
    "No access control validation"
  ],
  "owasp_categories": [
    "LLM06: Sensitive Information Disclosure",
    "LLM08: Excessive Agency"
  ],
  "vulnerabilities": [
    {
      "type": "Credential Exposure",
      "severity": "CRITICAL",
      "description": "Prompt requests direct access to password storage",
      "cwe_id": "CWE-522"
    }
  ],
  "recommendations": [
    "Implement credential vault with access controls",
    "Add authentication and authorization checks"
  ],
  "compliance_concerns": [
    "GDPR: Inadequate protection of authentication data",
    "SOC 2: Insufficient access controls"
  ],
  "attack_vectors": [
    "Unauthorized credential harvesting",
    "Privilege escalation through direct database access"
  ],
  "timestamp": "2025-10-13T12:34:56.789Z",
  "analyzer": "bedrock-claude-3-sonnet-owasp"
}
```

## OWASP LLM Top 10 Coverage

✅ LLM01: Prompt Injection
✅ LLM02: Insecure Output Handling
✅ LLM03: Training Data Poisoning
✅ LLM04: Model Denial of Service
✅ LLM05: Supply Chain Vulnerabilities
✅ LLM06: Sensitive Information Disclosure
✅ LLM07: Insecure Plugin Design
✅ LLM08: Excessive Agency
✅ LLM09: Overreliance
✅ LLM10: Model Theft

## Cost

**Per Request:**
- Bedrock (Claude 3 Sonnet): ~$0.016
- Lambda: ~$0.0001
- **Total: ~$0.016**

**Monthly:**
- 1,000 requests: ~$16
- 10,000 requests: ~$160

## Files

- `lambda_function.py` - Main function with security persona
- `requirements.txt` - Dependencies (boto3)
- `iam-policy.json` - IAM policy for Bedrock
- `DEPLOYMENT_GUIDE.md` - Complete deployment guide
- `README.md` - This file

## Integration

Update `.env` in SaferAI React app:

```
VITE_PROMPT_ANALYZER_API=https://YOUR_API_ENDPOINT
```

No frontend changes needed - ProductReview component already supports this format!

## Testing Locally

```bash
pip3 install boto3
python3 lambda_function.py
```

## Monitoring

**CloudWatch Logs:**
```
/aws/lambda/SaferAI-OWASP-Prompt-Analyzer
```

**Key Metrics:**
- Duration: 10-20 seconds typical
- Invocations: Track usage
- Errors: Monitor failures

## Security

✅ Input validation (max 10K chars)
✅ CORS enabled
✅ Error handling
✅ CloudWatch logging
✅ IAM least privilege

## Support

See `DEPLOYMENT_GUIDE.md` for:
- Step-by-step deployment
- Example analyses
- Troubleshooting
- Cost optimization
- Advanced configuration

## Differences from Simple Analyzer

| Feature | Simple | OWASP |
|---------|--------|-------|
| Scoring | Manual patterns | Bedrock analysis |
| OWASP Coverage | No | Full Top 10 |
| Vulnerabilities | Basic | Detailed with CWE |
| Compliance | No | GDPR, SOC2, etc. |
| Attack Vectors | No | Yes |
| Cost/Request | $0.006 | $0.016 |
| Response Time | 5-10s | 10-20s |

## When to Use

**Use OWASP Analyzer for:**
- Production deployments
- High-risk applications
- Compliance requirements
- Detailed security assessments
- Enterprise environments

**Use Simple Analyzer for:**
- Development/testing
- Low-risk applications
- Cost optimization
- Fast screening

## License

Internal Amazon use only - SaferAI Framework

---

**Ready for enterprise security assessment!** 🔒

