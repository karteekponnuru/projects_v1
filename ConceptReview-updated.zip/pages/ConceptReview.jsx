import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, ExternalLink } from 'lucide-react';
import { generateSaferAIPDF } from '@/lib/pdfGenerator.js';

const ConceptReview = () => {
  const [formData, setFormData] = useState({
    // Basic Project Details
    projectName: '',
    developer: '',
    org: '',
    loginId: '',
    date: new Date().toISOString().split('T')[0],
    goal: '',
    devType: '',
    stage: '',
    platform: '',
    dataCategory: '',
    intendedOutput: '',
    expectedIntegrations: '',
    teamSize: '',
    otherDetails: ''
  });

  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [riskScore, setRiskScore] = useState(0);
  const [normalizedScore, setNormalizedScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');

  const questions = [
    {
      category: 'A. Data Sensitivity',
      items: [
        {
          id: 'data_type',
          question: 'What type of data will your agent use?',
          options: [
            { text: 'Public/mock', score: 0 },
            { text: 'Internal', score: 1 },
            { text: 'Business/Partner', score: 2 },
            { text: 'AWS Support', score: 3 },
            { text: 'Customer/PII', score: 5 }
          ]
        },
        {
          id: 'customer_data',
          question: 'Does your idea process or derive insights from customer-linked data?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'B. Access Permissions',
      items: [
        {
          id: 'access_level',
          question: 'What kind of access will your solution need?',
          options: [
            { text: 'None', score: 0 },
            { text: 'Basic read', score: 2 },
            { text: 'Write/update', score: 3 },
            { text: 'Elevated/system', score: 5 }
          ]
        },
        {
          id: 'api_interaction',
          question: 'Will it interact with dashboards, APIs, or case data?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Internal only', score: 2 },
            { text: 'External or cross-tenant', score: 4 }
          ]
        }
      ]
    },
    {
      category: 'C. Output Safety',
      items: [
        {
          id: 'output_visibility',
          question: 'Where will the outputs be visible?',
          options: [
            { text: 'Team-only', score: 1 },
            { text: 'Cross-org', score: 3 },
            { text: 'Public/External', score: 5 }
          ]
        },
        {
          id: 'auto_generated',
          question: 'Are outputs auto-generated without human review?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes', score: 3 },
            { text: 'Yes, and shared externally', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'D. Prompt Security',
      items: [
        {
          id: 'free_text_prompts',
          question: 'Will users enter free text prompts?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Partially', score: 2 },
            { text: 'Yes', score: 4 }
          ]
        },
        {
          id: 'prompt_exposure',
          question: 'Could prompts expose internal data or credentials?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Likely', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'E. External Integrations',
      items: [
        {
          id: 'external_services',
          question: 'Are there integrations with non-AWS services?',
          options: [
            { text: 'None', score: 0 },
            { text: 'Internal APIs only', score: 2 },
            { text: 'Slack/Sheets/Email/Other 3P', score: 4 }
          ]
        },
        {
          id: 'external_data',
          question: 'Does your idea send or store data externally?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Occasionally', score: 2 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'F. Business Impact',
      items: [
        {
          id: 'criticality',
          question: 'How critical is this to daily operations?',
          options: [
            { text: 'Low', score: 1 },
            { text: 'Medium', score: 3 },
            { text: 'High', score: 5 }
          ]
        },
        {
          id: 'incorrect_outputs',
          question: 'Would incorrect outputs create customer or business risk?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      category: 'G. Compliance & Monitoring',
      items: [
        {
          id: 'logging',
          question: 'Are logs or activity histories maintained?',
          options: [
            { text: 'Full logs', score: 0 },
            { text: 'Partial logs', score: 2 },
            { text: 'No logs', score: 5 }
          ]
        },
        {
          id: 'project_owner',
          question: 'Is there a clearly identified project owner?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Not yet', score: 3 }
          ]
        }
      ]
    },
    {
      category: 'H. Future Scaling & Governance',
      items: [
        {
          id: 'scaling',
          question: 'Do you expect this to scale across multiple orgs?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Later', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        },
        {
          id: 'permission_increase',
          question: 'Will permissions or data exposure increase as it scales?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Possibly', score: 2 },
            { text: 'Yes', score: 4 }
          ]
        }
      ]
    }
  ];

  const calculateRisk = () => {
    let totalScore = 0;
    Object.values(answers).forEach(answer => {
      totalScore += answer.score;
    });
    
    setRiskScore(totalScore);
    
    // Normalize to 40 scale
    const normalized = Math.round(totalScore / 2);
    setNormalizedScore(normalized);
    
    // Determine risk zone
    if (normalized <= 16) {
      setRiskZone('green');
    } else if (normalized <= 28) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateRisk();
    setSubmitted(true);
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleAnswer = (questionId, optionIndex) => {
    const allQuestions = questions.flatMap(cat => cat.items);
    const question = allQuestions.find(q => q.id === questionId);
    setAnswers({
      ...answers,
      [questionId]: {
        answer: question.options[optionIndex].text,
        score: question.options[optionIndex].score
      }
    });
  };

  const downloadPDF = async () => {
    const zoneDetails = getRiskZoneDetails();
    
    const pdfData = {
      projectName: formData.projectName,
      developer: formData.developer,
      org: formData.org,
      loginId: formData.loginId,
      platform: formData.platform,
      date: formData.date,
      stage: formData.stage,
      devType: formData.devType,
      zone: zoneDetails.title,
      score: normalizedScore,
      maxScore: 40,
      findings: [
        `Raw Score: ${riskScore}/80`,
        `Data Type: ${answers.data_type?.answer || 'N/A'}`,
        `Access Level: ${answers.access_level?.answer || 'N/A'}`,
        `Output Visibility: ${answers.output_visibility?.answer || 'N/A'}`,
        `External Integrations: ${answers.external_services?.answer || 'N/A'}`,
        `Business Criticality: ${answers.criticality?.answer || 'N/A'}`
      ],
      suggestions: zoneDetails.nextSteps
    };

    await generateSaferAIPDF(pdfData, 'concept');
  };

  const getRiskZoneDetails = () => {
    const zones = {
      green: {
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        title: 'Green Zone – Ready to Build',
        color: 'bg-green-50 border-green-200',
        message: 'Safe concept; minimal risk. Your concept aligns with policy and approved use cases. You can proceed to development.',
        action: 'Proceed to Product Review',
        nextSteps: [
          'Document your implementation plan',
          'Begin development with approved tools',
          'Plan for Product Review after completion',
          'Ensure proper logging and monitoring'
        ]
      },
      amber: {
        icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
        title: 'Amber Zone – Design with Care',
        color: 'bg-yellow-50 border-yellow-200',
        message: 'Acceptable risk; refine before scaling. Some parameters need validation before full deployment.',
        action: 'Review and Adjust',
        nextSteps: [
          'Review data sources and ensure proper classification',
          'Validate integration security measures',
          'Consider adding monitoring and logging',
          'Add human review checkpoints for outputs',
          'Resubmit after adjustments'
        ]
      },
      red: {
        icon: <XCircle className="h-16 w-16 text-red-600" />,
        title: 'Red Zone – Needs Rework',
        color: 'bg-red-50 border-red-200',
        message: 'High exposure; adjust data or scope. Your concept involves restricted data or high-risk operations. SWAT consultation required.',
        action: 'Contact SWAT',
        nextSteps: [
          'Prepare detailed documentation of your use case',
          'Schedule SWAT consultation',
          'Review alternative approaches',
          'Consider using approved data types',
          'Do not proceed without SWAT approval'
        ]
      }
    };
    return zones[riskZone] || zones.green;
  };

  if (submitted) {
    const zoneDetails = getRiskZoneDetails();
    return (
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review Results</p>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-8 py-12">
          <Card className={`border-2 ${zoneDetails.color} mb-8`}>
            <CardHeader>
              <div className="flex items-center gap-4">
                {zoneDetails.icon}
                <div>
                  <CardTitle className="text-2xl mb-2">{zoneDetails.title}</CardTitle>
                  <p className="text-gray-700">{zoneDetails.message}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-2">Risk Score: {normalizedScore} / 40</h3>
                <p className="text-sm text-gray-600 mb-2">(Raw Score: {riskScore} / 80)</p>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full ${
                      riskZone === 'green' ? 'bg-green-500' :
                      riskZone === 'amber' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(normalizedScore / 40) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3">Next Steps:</h3>
                <ul className="space-y-2">
                  {zoneDetails.nextSteps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#FF9900] mt-1">•</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-4">
                <Button onClick={downloadPDF} className="bg-[#232F3E] hover:bg-[#1a2332]">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF Report
                </Button>
                {riskZone === 'red' && (
                  <a href="https://asana.amazon.com/create?project=SWAT_Consultations" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Contact SWAT
                    </Button>
                  </a>
                )}
                <Button onClick={() => setSubmitted(false)} variant="outline">
                  Start New Review
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Project Summary */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Concept Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold text-sm text-gray-600">Project Name</p>
                  <p className="text-lg">{formData.projectName}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Developer</p>
                  <p className="text-lg">{formData.developer}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Organization</p>
                  <p className="text-lg">{formData.org}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Development Type</p>
                  <p className="text-lg">{formData.devType}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Stage</p>
                  <p className="text-lg">{formData.stage}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Platform</p>
                  <p className="text-lg">{formData.platform}</p>
                </div>
              </div>
              {formData.goal && (
                <div className="mt-4">
                  <p className="font-semibold text-sm text-gray-600">Goal / Problem Statement</p>
                  <p className="text-base">{formData.goal}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Score Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Score Breakdown by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {questions.map((category, idx) => {
                  const categoryScore = category.items.reduce((sum, item) => {
                    return sum + (answers[item.id]?.score || 0);
                  }, 0);
                  return (
                    <div key={idx}>
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold">{category.category}</h4>
                        <span className="text-sm font-medium">{categoryScore} / 10 points</span>
                      </div>
                      <div className="space-y-1 ml-4 text-sm text-gray-600">
                        {category.items.map((item) => (
                          <div key={item.id} className="flex justify-between">
                            <span>{item.question}</span>
                            <span className="font-medium">{answers[item.id]?.answer || 'Not answered'}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">SaferAI</h1>
          <p className="text-sm text-gray-300 mt-1">Concept Review</p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Concept Review</h2>
          <p className="text-lg text-gray-600">
            Submit your AI agent concept for evaluation. This review helps identify potential risks early 
            in the development process and ensures your project aligns with Amazon's security policies.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Project Details */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Project Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="projectName">Project Name *</Label>
                  <Input
                    id="projectName"
                    value={formData.projectName}
                    onChange={(e) => handleChange('projectName', e.target.value)}
                    placeholder="AutoSummarizer for Ops Reports"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="developer">Developer Name *</Label>
                  <Input
                    id="developer"
                    value={formData.developer}
                    onChange={(e) => handleChange('developer', e.target.value)}
                    placeholder="John Doe"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="org">Organization *</Label>
                  <Input
                    id="org"
                    value={formData.org}
                    onChange={(e) => handleChange('org', e.target.value)}
                    placeholder="SPS CT SWAT"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="loginId">Login ID *</Label>
                  <Input
                    id="loginId"
                    value={formData.loginId}
                    onChange={(e) => handleChange('loginId', e.target.value)}
                    placeholder="jdoe@amazon.com"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleChange('date', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="teamSize">Team Size / Roles</Label>
                  <Input
                    id="teamSize"
                    value={formData.teamSize}
                    onChange={(e) => handleChange('teamSize', e.target.value)}
                    placeholder="2 devs, 1 reviewer"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="goal">Goal / Problem Statement *</Label>
                <Textarea
                  id="goal"
                  value={formData.goal}
                  onChange={(e) => handleChange('goal', e.target.value)}
                  placeholder="Reduce manual effort in summarizing daily reports"
                  rows={3}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="devType">Type of Development *</Label>
                  <Input
                    id="devType"
                    value={formData.devType}
                    onChange={(e) => handleChange('devType', e.target.value)}
                    placeholder="GenAI Agent / Extension / Workflow Automation / Script"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="stage">Development Stage *</Label>
                  <Input
                    id="stage"
                    value={formData.stage}
                    onChange={(e) => handleChange('stage', e.target.value)}
                    placeholder="Idea / Prototype / Pilot / Production"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="platform">Primary Platform *</Label>
                  <Input
                    id="platform"
                    value={formData.platform}
                    onChange={(e) => handleChange('platform', e.target.value)}
                    placeholder="Cedric / Amazon Q Internal / BedrockBot / Other"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="dataCategory">Data Category *</Label>
                  <Input
                    id="dataCategory"
                    value={formData.dataCategory}
                    onChange={(e) => handleChange('dataCategory', e.target.value)}
                    placeholder="Internal / AWS Support / Partner / Customer / Public"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="intendedOutput">Intended Output *</Label>
                  <Input
                    id="intendedOutput"
                    value={formData.intendedOutput}
                    onChange={(e) => handleChange('intendedOutput', e.target.value)}
                    placeholder="Summary / Email / Ticket Update / Report"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="expectedIntegrations">Expected Integrations *</Label>
                  <Input
                    id="expectedIntegrations"
                    value={formData.expectedIntegrations}
                    onChange={(e) => handleChange('expectedIntegrations', e.target.value)}
                    placeholder="Slack / Sheets / Quip / None"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="otherDetails">Other Details (Optional)</Label>
                <Textarea
                  id="otherDetails"
                  value={formData.otherDetails}
                  onChange={(e) => handleChange('otherDetails', e.target.value)}
                  placeholder="May later expand to handle multilingual data..."
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          {/* Risk Category Questions */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900">Risk Category Questions</h3>
            <p className="text-gray-600">
              Answer all questions below. Each category has 2 questions rated from 0 to 5 points.
            </p>

            {questions.map((category, categoryIdx) => (
              <Card key={categoryIdx}>
                <CardHeader>
                  <CardTitle>{category.category}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {category.items.map((item) => (
                    <div key={item.id}>
                      <Label className="text-base mb-3 block">{item.question}</Label>
                      <RadioGroup
                        value={answers[item.id]?.answer}
                        onValueChange={(value) => {
                          const optionIndex = item.options.findIndex(opt => opt.text === value);
                          handleAnswer(item.id, optionIndex);
                        }}
                        required
                      >
                        {item.options.map((option, optIdx) => (
                          <div key={optIdx} className="flex items-center space-x-2">
                            <RadioGroupItem value={option.text} id={`${item.id}-${optIdx}`} />
                            <Label htmlFor={`${item.id}-${optIdx}`} className="font-normal">
                              {option.text} ({option.score} {option.score === 1 ? 'point' : 'points'})
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          <Button 
            type="submit" 
            disabled={Object.keys(answers).length < questions.flatMap(c => c.items).length}
            className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white text-lg py-6"
          >
            Submit Concept Review
          </Button>
        </form>
      </main>

      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE
        </div>
      </footer>
    </div>
  );
};

export default ConceptReview;

