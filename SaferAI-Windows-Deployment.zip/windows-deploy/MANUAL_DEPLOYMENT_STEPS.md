# Manual Deployment Steps for Windows

## Your Configuration

- **S3 Bucket:** `saferai-frontend-6172025`
- **CloudFront Distribution ID:** `E181FIKHAED29M`
- **CloudFront Domain:** `https://d2qg163ib56cki.cloudfront.net`

---

## Step-by-Step Commands

### Step 1: Build the React App

```cmd
cd safer-ai
pnpm run build
```

**Expected output:** Build completes successfully, creates `dist/` folder

---

### Step 2: Upload to S3

```cmd
aws s3 sync dist/ s3://saferai-frontend-6172025/ --delete
```

**What this does:**
- Uploads all files from `dist/` to S3
- `--delete` removes old files that no longer exist

**Expected output:**
```
upload: dist/index.html to s3://saferai-frontend-6172025/index.html
upload: dist/assets/index-abc123.js to s3://saferai-frontend-6172025/assets/index-abc123.js
...
```

---

### Step 3: Fix JavaScript MIME Types

```cmd
aws s3 cp s3://saferai-frontend-6172025/assets/ s3://saferai-frontend-6172025/assets/ ^
  --recursive ^
  --exclude "*" ^
  --include "*.js" ^
  --content-type "application/javascript" ^
  --metadata-directive REPLACE ^
  --cache-control "public, max-age=31536000"
```

**What this does:**
- Sets correct MIME type for all `.js` files
- Adds 1-year cache headers (files are hashed, so safe to cache)

---

### Step 4: Fix CSS MIME Types

```cmd
aws s3 cp s3://saferai-frontend-6172025/assets/ s3://saferai-frontend-6172025/assets/ ^
  --recursive ^
  --exclude "*" ^
  --include "*.css" ^
  --content-type "text/css" ^
  --metadata-directive REPLACE ^
  --cache-control "public, max-age=31536000"
```

**What this does:**
- Sets correct MIME type for all `.css` files

---

### Step 5: Fix HTML MIME Types

```cmd
aws s3 cp s3://saferai-frontend-6172025/ s3://saferai-frontend-6172025/ ^
  --recursive ^
  --exclude "*" ^
  --include "*.html" ^
  --content-type "text/html" ^
  --cache-control "no-cache, no-store, must-revalidate" ^
  --metadata-directive REPLACE
```

**What this does:**
- Sets correct MIME type for HTML files
- Disables caching (so updates are immediate)

---

### Step 6: Fix JSON MIME Types

```cmd
aws s3 cp s3://saferai-frontend-6172025/ s3://saferai-frontend-6172025/ ^
  --recursive ^
  --exclude "*" ^
  --include "*.json" ^
  --content-type "application/json" ^
  --cache-control "no-cache" ^
  --metadata-directive REPLACE
```

**What this does:**
- Sets correct MIME type for JSON files (like manifest.json)

---

### Step 7: Invalidate CloudFront Cache

```cmd
aws cloudfront create-invalidation ^
  --distribution-id E181FIKHAED29M ^
  --paths "/*"
```

**What this does:**
- Tells CloudFront to clear its cache
- Forces CloudFront to fetch fresh files from S3

**Expected output:**
```json
{
    "Invalidation": {
        "Id": "I2J3K4L5M6N7O8P9",
        "Status": "InProgress",
        "CreateTime": "2025-10-14T10:30:00.000Z"
    }
}
```

---

### Step 8: Wait and Test

**Wait:** 5-10 minutes for CloudFront invalidation to complete

**Then test:**
1. Visit: `https://d2qg163ib56cki.cloudfront.net`
2. Hard refresh: `Ctrl + Shift + R`
3. Check if site loads without MIME errors

---

## Verification Commands

### Check if files exist in S3:

```cmd
aws s3 ls s3://saferai-frontend-6172025/assets/
```

### Check MIME type of a specific file:

```cmd
aws s3api head-object ^
  --bucket saferai-frontend-6172025 ^
  --key assets/index-abc123.js ^
  --query ContentType
```

**Expected output:** `"application/javascript"`

### Check CloudFront invalidation status:

```cmd
aws cloudfront get-invalidation ^
  --distribution-id E181FIKHAED29M ^
  --id YOUR_INVALIDATION_ID
```

---

## Troubleshooting

### Issue: "Access Denied" error

**Solution:**
```cmd
# Check AWS credentials
aws sts get-caller-identity

# Configure if needed
aws configure
```

### Issue: Files uploaded but MIME types still wrong

**Solution:**
- Run Steps 3-6 again
- Wait a few minutes
- Check with `head-object` command

### Issue: CloudFront still serving old content

**Solution:**
```cmd
# Create another invalidation
aws cloudfront create-invalidation ^
  --distribution-id E181FIKHAED29M ^
  --paths "/*"

# Wait 10-15 minutes
# Clear browser cache completely
```

### Issue: "Command not found" errors

**Solution:**
- Install AWS CLI: https://aws.amazon.com/cli/
- Add to PATH
- Restart terminal

---

## Quick Reference

### One-Line Deployment (After First Time)

```cmd
cd safer-ai && pnpm run build && aws s3 sync dist/ s3://saferai-frontend-6172025/ --delete && aws cloudfront create-invalidation --distribution-id E181FIKHAED29M --paths "/*"
```

### Check Deployment Status

```cmd
# Check S3
aws s3 ls s3://saferai-frontend-6172025/

# Check CloudFront
aws cloudfront get-distribution --distribution-id E181FIKHAED29M --query Distribution.Status
```

---

## Success Indicators

✅ Build completes without errors  
✅ Files uploaded to S3  
✅ MIME types set correctly  
✅ CloudFront invalidation created  
✅ Site loads at `https://d2qg163ib56cki.cloudfront.net`  
✅ No MIME type errors in browser console  
✅ JavaScript files load with `200` status  

---

## Need Help?

If manual deployment is too complex, just use the automated batch script:

```cmd
deploy-saferai-READY.bat
```

It does all these steps automatically! 🚀

