# SaferAI CloudFront Deployment - Quick Start

## Your Configuration ✅

```
S3 Bucket:           saferai-frontend-6172025
Distribution ID:     E181FIKHAED29M
CloudFront URL:      https://d2qg163ib56cki.cloudfront.net
API Gateway URL:     https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1
```

---

## 🚀 Fastest Way to Deploy

### Option 1: Automated Script (Recommended)

1. **Double-click:** `deploy-saferai-READY.bat`
2. **Wait:** Script runs all steps automatically
3. **Done:** Visit your site in 5-10 minutes

**That's it!** ✅

---

### Option 2: Manual Commands

If you prefer manual control, see `MANUAL_DEPLOYMENT_STEPS.md`

---

## 📋 What the Script Does

1. ✅ Builds your React app
2. ✅ Uploads to S3
3. ✅ Fixes all MIME types (JS, CSS, HTML, JSON)
4. ✅ Invalidates CloudFront cache
5. ✅ Shows summary and next steps

---

## ⏱️ Timeline

| Step | Time |
|------|------|
| Run script | 2-3 minutes |
| CloudFront invalidation | 5-10 minutes |
| **Total** | **~10-15 minutes** |

---

## 🧪 After Deployment

### 1. Wait 5-10 Minutes

CloudFront needs time to invalidate cache and fetch new files.

### 2. Visit Your Site

```
https://d2qg163ib56cki.cloudfront.net
```

### 3. Hard Refresh Browser

**Windows:** `Ctrl + Shift + R`  
**Mac:** `Cmd + Shift + R`

### 4. Check for Errors

Open browser DevTools (F12) → Console tab

**✅ Success:** No errors, site loads normally  
**❌ Still errors:** Wait longer or see troubleshooting below

---

## 🔍 Troubleshooting

### Issue: Still seeing MIME type errors

**Solution:**
1. Wait 5 more minutes
2. Hard refresh again
3. Try incognito/private mode
4. Clear browser cache completely

### Issue: Script fails at S3 upload

**Solution:**
```cmd
# Check AWS credentials
aws sts get-caller-identity

# If not configured
aws configure
```

### Issue: Script fails at CloudFront invalidation

**Solution:**
- Check IAM permissions include `cloudfront:CreateInvalidation`
- Or manually invalidate in AWS Console

### Issue: Site loads but API doesn't work

**Solution:**
1. Check `.env` file exists in `safer-ai/` folder
2. Verify it contains: `VITE_PROMPT_ANALYZER_API=https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1`
3. Rebuild: `pnpm run build`
4. Re-run deployment script

---

## 📁 Files in This Package

| File | Purpose |
|------|---------|
| `deploy-saferai-READY.bat` | ⭐ Automated deployment script |
| `MANUAL_DEPLOYMENT_STEPS.md` | Step-by-step manual commands |
| `QUICK_START.md` | This file - quick reference |
| `TROUBLESHOOTING.md` | Detailed troubleshooting guide |

---

## 🎯 First Time Setup Checklist

Before running the script:

- [ ] AWS CLI installed
- [ ] AWS credentials configured (`aws configure`)
- [ ] Node.js and pnpm installed
- [ ] `safer-ai/` folder exists
- [ ] `.env` file created with API Gateway URL
- [ ] Script is in parent folder of `safer-ai/`

---

## 📞 Need Help?

### Check These First:

1. **AWS credentials working?**
   ```cmd
   aws sts get-caller-identity
   ```

2. **Build works locally?**
   ```cmd
   cd safer-ai
   pnpm run build
   ```

3. **Files in S3?**
   ```cmd
   aws s3 ls s3://saferai-frontend-6172025/
   ```

4. **CloudFront status?**
   ```cmd
   aws cloudfront get-distribution --distribution-id E181FIKHAED29M --query Distribution.Status
   ```

### Still Stuck?

See `TROUBLESHOOTING.md` for detailed solutions.

---

## 🎉 Success!

Once deployed, your SaferAI app will be live at:

**https://d2qg163ib56cki.cloudfront.net**

Features working:
- ✅ Home page with guidance bot
- ✅ Mechanism page
- ✅ Concept Review with risk assessment
- ✅ Product Review with OWASP prompt analysis
- ✅ PDF downloads
- ✅ SWAT submission buttons

---

## 🔄 Future Deployments

After first deployment, just run:

```cmd
deploy-saferai-READY.bat
```

Every time you make changes! The script handles everything.

---

**Ready to deploy? Double-click `deploy-saferai-READY.bat` now!** 🚀

