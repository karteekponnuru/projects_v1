# SaferAI Deployment Troubleshooting Guide

## Your Configuration

- **S3 Bucket:** `saferai-frontend-6172025`
- **Distribution ID:** `E181FIKHAED29M`
- **CloudFront URL:** `https://d2qg163ib56cki.cloudfront.net`
- **API Gateway:** `https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1`

---

## Common Issues & Solutions

### 1. MIME Type Error (Still Happening)

**Error:**
```
Loading module from "https://d2qg163ib56cki.cloudfront.net/assets/index-xxx.js" 
was blocked because of a disallowed MIME type ("text/html")
```

**Root Cause:** CloudFront serving cached HTML error page instead of JS files

**Solutions:**

#### A. Wait Longer
- CloudFront invalidation takes 5-15 minutes
- Check status:
  ```cmd
  aws cloudfront list-invalidations --distribution-id E181FIKHAED29M
  ```

#### B. Manual Invalidation
```cmd
aws cloudfront create-invalidation ^
  --distribution-id E181FIKHAED29M ^
  --paths "/*"
```

#### C. Check S3 MIME Types
```cmd
aws s3api head-object ^
  --bucket saferai-frontend-6172025 ^
  --key assets/index-abc123.js ^
  --query ContentType
```

Should return: `"application/javascript"`

If not, re-run MIME type fix:
```cmd
aws s3 cp s3://saferai-frontend-6172025/assets/ s3://saferai-frontend-6172025/assets/ ^
  --recursive ^
  --exclude "*" ^
  --include "*.js" ^
  --content-type "application/javascript" ^
  --metadata-directive REPLACE
```

#### D. Clear Browser Cache
- Hard refresh: `Ctrl + Shift + R`
- Or clear all cache: Settings → Privacy → Clear browsing data
- Or use Incognito mode

#### E. Check CloudFront Error Pages
1. Go to CloudFront Console
2. Select distribution `E181FIKHAED29M`
3. Go to **Error Pages** tab
4. Should have:
   - **403** → `/index.html` (200)
   - **404** → `/index.html` (200)

If missing, create them.

---

### 2. AWS CLI Errors

**Error:** `'aws' is not recognized as an internal or external command`

**Solution:**
1. Install AWS CLI: https://aws.amazon.com/cli/
2. Add to PATH
3. Restart terminal
4. Test: `aws --version`

---

**Error:** `Unable to locate credentials`

**Solution:**
```cmd
aws configure
```

Enter:
- AWS Access Key ID
- AWS Secret Access Key
- Default region: `ap-south-1`
- Default output: `json`

Test:
```cmd
aws sts get-caller-identity
```

---

**Error:** `Access Denied` when uploading to S3

**Solution:**

Check IAM permissions include:
```json
{
  "Effect": "Allow",
  "Action": [
    "s3:PutObject",
    "s3:GetObject",
    "s3:DeleteObject",
    "s3:ListBucket",
    "s3:PutObjectAcl"
  ],
  "Resource": [
    "arn:aws:s3:::saferai-frontend-6172025",
    "arn:aws:s3:::saferai-frontend-6172025/*"
  ]
}
```

---

**Error:** `Access Denied` for CloudFront invalidation

**Solution:**

Add permission:
```json
{
  "Effect": "Allow",
  "Action": [
    "cloudfront:CreateInvalidation",
    "cloudfront:GetInvalidation",
    "cloudfront:ListInvalidations"
  ],
  "Resource": "arn:aws:cloudfront::*:distribution/E181FIKHAED29M"
}
```

---

### 3. Build Errors

**Error:** `pnpm: command not found`

**Solution:**
```cmd
npm install -g pnpm
```

---

**Error:** Build fails with dependency errors

**Solution:**
```cmd
cd safer-ai
rm -rf node_modules
pnpm install
pnpm run build
```

---

**Error:** `Cannot find module '@/components/ui/button'`

**Solution:**

Check these files exist:
- `src/components/ui/button.jsx`
- `src/components/ui/card.jsx`
- `src/components/ui/input.jsx`

If missing, reinstall shadcn components:
```cmd
npx shadcn-ui@latest add button card input
```

---

### 4. API Not Working

**Error:** Prompt analysis doesn't work in Product Review

**Diagnosis:**

1. Check `.env` file exists:
   ```cmd
   cd safer-ai
   type .env
   ```

   Should show:
   ```
   VITE_PROMPT_ANALYZER_API=https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1
   ```

2. Test API directly:
   ```cmd
   curl -X POST https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1 ^
     -H "Content-Type: application/json" ^
     -d "{\"prompt\":\"test\"}"
   ```

   Should return JSON with risk analysis.

**Solutions:**

#### A. .env Not Found
```cmd
cd safer-ai
echo VITE_PROMPT_ANALYZER_API=https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1 > .env
```

#### B. .env Not Loaded
- Restart dev server
- Rebuild: `pnpm run build`
- Re-deploy

#### C. CORS Error
Check API Gateway has CORS enabled:
- Go to API Gateway Console
- Select your API
- Configure CORS:
  - Allow origin: `*` or `https://d2qg163ib56cki.cloudfront.net`
  - Allow methods: `POST, OPTIONS`
  - Allow headers: `Content-Type`

#### D. Lambda Not Deployed
Check Lambda exists:
```cmd
aws lambda get-function --function-name SaferAI-OWASP-Prompt-Analyzer
```

If not found, deploy Lambda first.

---

### 5. CloudFront Shows Old Version

**Symptoms:**
- Code changes don't appear
- Old content still showing
- Already invalidated cache

**Solutions:**

#### A. Check Invalidation Status
```cmd
aws cloudfront get-invalidation ^
  --distribution-id E181FIKHAED29M ^
  --id YOUR_INVALIDATION_ID
```

Wait until Status is `Completed`.

#### B. Create New Invalidation
```cmd
aws cloudfront create-invalidation ^
  --distribution-id E181FIKHAED29M ^
  --paths "/*"
```

#### C. Disable CloudFront Temporarily
For testing, access S3 directly:
```
https://saferai-frontend-6172025.s3.ap-south-1.amazonaws.com/index.html
```

If S3 works but CloudFront doesn't, it's a caching issue.

#### D. Check CloudFront Behaviors
1. Go to CloudFront Console
2. Select distribution
3. Check **Behaviors** tab
4. Default behavior should:
   - Origin: `saferai-frontend-6172025.s3.ap-south-1.amazonaws.com`
   - Viewer Protocol: Redirect HTTP to HTTPS
   - Allowed Methods: GET, HEAD, OPTIONS
   - Cache Policy: CachingOptimized

---

### 6. React Router Not Working

**Symptoms:**
- Direct URLs like `/concept-review` show 404
- Refresh on any page except home shows error

**Solution:**

Configure CloudFront Error Pages:

1. Go to CloudFront Console
2. Select distribution `E181FIKHAED29M`
3. **Error Pages** tab
4. Create custom error responses:

**For 403:**
- HTTP Error Code: `403`
- Customize Error Response: `Yes`
- Response Page Path: `/index.html`
- HTTP Response Code: `200`

**For 404:**
- HTTP Error Code: `404`
- Customize Error Response: `Yes`
- Response Page Path: `/index.html`
- HTTP Response Code: `200`

This ensures React Router handles all routes.

---

### 7. Deployment Script Fails

**Error:** `The system cannot find the path specified`

**Solution:**

Run script from correct location:
```
your-project/
├── deploy-saferai-READY.bat  ← Run from here
└── safer-ai/
    ├── package.json
    └── src/
```

```cmd
cd your-project
deploy-saferai-READY.bat
```

---

**Error:** Script stops at build step

**Solution:**

Build manually first to see error:
```cmd
cd safer-ai
pnpm run build
```

Fix any build errors, then re-run script.

---

### 8. Files Uploaded But Site Broken

**Diagnosis:**

Check what's in S3:
```cmd
aws s3 ls s3://saferai-frontend-6172025/ --recursive
```

Should see:
```
index.html
assets/index-abc123.js
assets/index-xyz789.css
assets/logo.svg
...
```

**Issues:**

#### A. Wrong Structure
If you see `dist/index.html`, you uploaded the `dist` folder itself.

**Fix:**
```cmd
cd safer-ai
aws s3 sync dist/ s3://saferai-frontend-6172025/ --delete
```

Note the `/` after `dist/` - important!

#### B. Missing Files
If `assets/` folder is empty:

**Fix:**
```cmd
cd safer-ai
pnpm run build
aws s3 sync dist/ s3://saferai-frontend-6172025/ --delete
```

---

### 9. Slow Load Times

**Symptoms:**
- Site loads but very slowly
- Large file sizes

**Solutions:**

#### A. Enable Compression
CloudFront should compress files automatically.

Check in CloudFront Console → Behaviors → Compress Objects Automatically: `Yes`

#### B. Optimize Build
```javascript
// vite.config.js
export default defineConfig({
  build: {
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true
      }
    }
  }
})
```

Rebuild and redeploy.

---

### 10. PDF Download Not Working

**Symptoms:**
- "Download PDF" button doesn't work
- Console shows errors

**Solution:**

Check dependencies installed:
```cmd
cd safer-ai
pnpm list pdf-lib file-saver
```

If missing:
```cmd
pnpm add pdf-lib file-saver
```

Rebuild and redeploy.

---

## Diagnostic Commands

### Check Everything

```cmd
REM AWS credentials
aws sts get-caller-identity

REM S3 bucket exists
aws s3 ls s3://saferai-frontend-6172025/

REM CloudFront distribution
aws cloudfront get-distribution --distribution-id E181FIKHAED29M --query Distribution.Status

REM Recent invalidations
aws cloudfront list-invalidations --distribution-id E181FIKHAED29M --max-items 5

REM Lambda function
aws lambda get-function --function-name SaferAI-OWASP-Prompt-Analyzer

REM API Gateway
curl https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1
```

---

## Still Not Working?

### Nuclear Option: Complete Reset

```cmd
REM 1. Clean build
cd safer-ai
rm -rf node_modules dist
pnpm install
pnpm run build

REM 2. Clear S3 completely
aws s3 rm s3://saferai-frontend-6172025/ --recursive

REM 3. Upload fresh
aws s3 sync dist/ s3://saferai-frontend-6172025/

REM 4. Fix MIME types
deploy-saferai-READY.bat

REM 5. Wait 15 minutes

REM 6. Clear browser cache completely

REM 7. Try in incognito mode
```

---

## Contact Support

If none of these solutions work:

1. Check CloudWatch Logs for Lambda errors
2. Check S3 bucket permissions
3. Check CloudFront distribution settings
4. Verify all IAM permissions
5. Try deploying to a new S3 bucket + CloudFront distribution

---

## Success Checklist

- [ ] Build completes without errors
- [ ] Files uploaded to S3
- [ ] MIME types correct (`application/javascript` for JS)
- [ ] CloudFront invalidation completed
- [ ] CloudFront error pages configured (403/404 → index.html)
- [ ] Site loads at `https://d2qg163ib56cki.cloudfront.net`
- [ ] No console errors
- [ ] API calls work
- [ ] PDF downloads work
- [ ] All pages accessible

---

**Good luck! The deployment script should handle most of these automatically.** 🚀

