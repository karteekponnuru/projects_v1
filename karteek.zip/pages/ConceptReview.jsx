import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, ExternalLink } from 'lucide-react';
import { generateSaferAIPDF } from '@/lib/pdfGenerator.js';

const ConceptReview = () => {
  const [formData, setFormData] = useState({
    // Basic Project Details
    projectName: '',
    developer: '',
    org: '',
    loginId: '',
    date: new Date().toISOString().split('T')[0],
    goal: '',
    devType: '',
    stage: '',
    
    // Technical Details
    platform: '',
    dataType: '',
    useCase: '',
    integration: '',
    accessLevel: '',
    outputType: '',
    
    // Additional Info
    teamSize: '',
    otherDetails: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [riskScore, setRiskScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');

  const calculateRisk = () => {
    let score = 0;

    // Data Type scoring
    if (formData.dataType === 'customer') score += 10;
    else if (formData.dataType === 'aws_support') score += 5;
    else if (formData.dataType === 'internal') score += 2;

    // Platform scoring
    if (formData.platform === 'custom') score += 5;
    else if (formData.platform === 'bedrockbot') score += 3;

    // Integration scoring
    if (formData.integration === 'external') score += 8;
    else if (formData.integration === 'internal') score += 3;

    // Access Level scoring
    if (formData.accessLevel === 'admin') score += 10;
    else if (formData.accessLevel === 'edit') score += 5;
    else if (formData.accessLevel === 'view') score += 2;

    // Output Type scoring
    if (formData.outputType === 'external') score += 8;
    else if (formData.outputType === 'internal_teams') score += 4;

    // Stage scoring
    if (formData.stage === 'production') score += 3;
    else if (formData.stage === 'pilot') score += 2;

    setRiskScore(score);

    // Determine risk zone
    if (score <= 15) {
      setRiskZone('green');
    } else if (score <= 30) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateRisk();
    setSubmitted(true);
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const downloadPDF = async () => {
    const zoneDetails = getRiskZoneDetails();
    
    const pdfData = {
      projectName: formData.projectName,
      developer: formData.developer,
      org: formData.org,
      loginId: formData.loginId,
      platform: formData.platform.replace('_', ' ').toUpperCase(),
      date: formData.date,
      stage: formData.stage.replace('_', ' ').toUpperCase(),
      devType: formData.devType.replace('_', ' '),
      zone: zoneDetails.title,
      score: riskScore,
      maxScore: 50,
      findings: [
        `Data Type: ${formData.dataType.replace('_', ' ')}`,
        `Use Case: ${formData.useCase.replace('_', ' ')}`,
        `Integration: ${formData.integration}`,
        `Access Level: ${formData.accessLevel}`,
        `Output Visibility: ${formData.outputType.replace('_', ' ')}`
      ],
      suggestions: zoneDetails.nextSteps
    };

    await generateSaferAIPDF(pdfData, 'concept');
  };

  const getRiskZoneDetails = () => {
    const zones = {
      green: {
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        title: 'Green Zone – Ready to Build',
        color: 'bg-green-50 border-green-200',
        message: 'Your concept aligns with policy and approved use cases. You can proceed to development.',
        action: 'Proceed to Product Review',
        nextSteps: [
          'Document your implementation plan',
          'Begin development with approved tools',
          'Plan for Product Review after completion',
          'Ensure proper logging and monitoring'
        ]
      },
      amber: {
        icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
        title: 'Amber Zone – Design with Care',
        color: 'bg-yellow-50 border-yellow-200',
        message: 'Some parameters need validation before scaling. Review the suggestions below.',
        action: 'Review and Adjust',
        nextSteps: [
          'Review data sources and ensure proper classification',
          'Validate integration security measures',
          'Consider adding monitoring and logging',
          'Add human review checkpoints for outputs',
          'Resubmit after adjustments'
        ]
      },
      red: {
        icon: <XCircle className="h-16 w-16 text-red-600" />,
        title: 'Red Zone – Needs SWAT Review',
        color: 'bg-red-50 border-red-200',
        message: 'Your concept involves restricted data or high-risk operations. SWAT consultation required.',
        action: 'Contact SWAT',
        nextSteps: [
          'Prepare detailed documentation of your use case',
          'Schedule SWAT consultation',
          'Review alternative approaches',
          'Consider using approved data types',
          'Do not proceed without SWAT approval'
        ]
      }
    };
    return zones[riskZone] || zones.green;
  };

  if (submitted) {
    const zoneDetails = getRiskZoneDetails();
    return (
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Concept Review Results</p>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-8 py-12">
          <Card className={`border-2 ${zoneDetails.color} mb-8`}>
            <CardHeader>
              <div className="flex items-center gap-4">
                {zoneDetails.icon}
                <div>
                  <CardTitle className="text-2xl mb-2">{zoneDetails.title}</CardTitle>
                  <p className="text-gray-700">{zoneDetails.message}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-2">Risk Score: {riskScore} / 50</h3>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full ${
                      riskZone === 'green' ? 'bg-green-500' :
                      riskZone === 'amber' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(riskScore / 50) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3">Next Steps:</h3>
                <ul className="space-y-2">
                  {zoneDetails.nextSteps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#FF9900] mt-1">•</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-4">
                <Button onClick={downloadPDF} className="bg-[#232F3E] hover:bg-[#1a2332]">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF Report
                </Button>
                {riskZone === 'red' && (
                  <a href="https://asana.amazon.com/create?project=SWAT_Consultations" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Contact SWAT
                    </Button>
                  </a>
                )}
                <Button onClick={() => setSubmitted(false)} variant="outline">
                  Start New Review
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Project Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Concept Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="font-semibold text-sm text-gray-600">Project Name</p>
                  <p className="text-lg">{formData.projectName}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Developer</p>
                  <p className="text-lg">{formData.developer}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Organization</p>
                  <p className="text-lg">{formData.org}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Development Type</p>
                  <p className="text-lg capitalize">{formData.devType.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Stage</p>
                  <p className="text-lg capitalize">{formData.stage.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Platform</p>
                  <p className="text-lg capitalize">{formData.platform.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Data Type</p>
                  <p className="text-lg capitalize">{formData.dataType.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-600">Use Case</p>
                  <p className="text-lg capitalize">{formData.useCase.replace('_', ' ')}</p>
                </div>
              </div>
              {formData.goal && (
                <div className="mt-4">
                  <p className="font-semibold text-sm text-gray-600">Goal / Problem Statement</p>
                  <p className="text-base">{formData.goal}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">SaferAI</h1>
          <p className="text-sm text-gray-300 mt-1">Concept Review</p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Concept Review</h2>
          <p className="text-lg text-gray-600">
            Submit your AI agent concept for evaluation. This review helps identify potential risks early 
            in the development process and ensures your project aligns with Amazon's security policies.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Project Details */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Project Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="projectName">Project Name *</Label>
                  <Input
                    id="projectName"
                    value={formData.projectName}
                    onChange={(e) => handleChange('projectName', e.target.value)}
                    placeholder="AutoSummarizer for Ops Reports"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="developer">Developer Name *</Label>
                  <Input
                    id="developer"
                    value={formData.developer}
                    onChange={(e) => handleChange('developer', e.target.value)}
                    placeholder="John Doe"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="org">Organization *</Label>
                  <Input
                    id="org"
                    value={formData.org}
                    onChange={(e) => handleChange('org', e.target.value)}
                    placeholder="SPS CT SWAT"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="loginId">Login ID *</Label>
                  <Input
                    id="loginId"
                    value={formData.loginId}
                    onChange={(e) => handleChange('loginId', e.target.value)}
                    placeholder="jdoe@amazon.com"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleChange('date', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="teamSize">Team Size / Roles</Label>
                  <Input
                    id="teamSize"
                    value={formData.teamSize}
                    onChange={(e) => handleChange('teamSize', e.target.value)}
                    placeholder="2 devs, 1 reviewer"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="goal">Goal / Problem Statement *</Label>
                <Textarea
                  id="goal"
                  value={formData.goal}
                  onChange={(e) => handleChange('goal', e.target.value)}
                  placeholder="Reduce manual effort in summarizing daily reports"
                  rows={3}
                  required
                />
              </div>
            </CardContent>
          </Card>

          {/* Development Type & Stage */}
          <Card>
            <CardHeader>
              <CardTitle>Development Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Type of Development *</Label>
                <RadioGroup value={formData.devType} onValueChange={(value) => handleChange('devType', value)} required>
                  <div className="flex items-center space-x-2 mt-2">
                    <RadioGroupItem value="genai_agent" id="genai_agent" />
                    <Label htmlFor="genai_agent" className="font-normal">GenAI Agent</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="extension" id="extension" />
                    <Label htmlFor="extension" className="font-normal">Extension</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="workflow_automation" id="workflow_automation" />
                    <Label htmlFor="workflow_automation" className="font-normal">Workflow Automation</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="script" id="script" />
                    <Label htmlFor="script" className="font-normal">Script</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>Development Stage *</Label>
                <RadioGroup value={formData.stage} onValueChange={(value) => handleChange('stage', value)} required>
                  <div className="flex items-center space-x-2 mt-2">
                    <RadioGroupItem value="idea" id="idea" />
                    <Label htmlFor="idea" className="font-normal">Idea</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="prototype" id="prototype" />
                    <Label htmlFor="prototype" className="font-normal">Prototype</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="pilot" id="pilot" />
                    <Label htmlFor="pilot" className="font-normal">Pilot</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="production" id="production" />
                    <Label htmlFor="production" className="font-normal">Production</Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          {/* Platform Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Primary Platform</CardTitle>
            </CardHeader>
            <CardContent>
              <Label>Which platform will you use? *</Label>
              <RadioGroup value={formData.platform} onValueChange={(value) => handleChange('platform', value)} required>
                <div className="flex items-center space-x-2 mt-2">
                  <RadioGroupItem value="cedric" id="cedric" />
                  <Label htmlFor="cedric" className="font-normal">Cedric</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="amazon_q" id="amazon_q" />
                  <Label htmlFor="amazon_q" className="font-normal">Amazon Q Internal</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="mentor" id="mentor" />
                  <Label htmlFor="mentor" className="font-normal">Mentor</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="bedrockbot" id="bedrockbot" />
                  <Label htmlFor="bedrockbot" className="font-normal">BedrockBot</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="party_rock" id="party_rock" />
                  <Label htmlFor="party_rock" className="font-normal">Party Rock</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="custom" id="custom" />
                  <Label htmlFor="custom" className="font-normal">Custom/Other</Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Data Category */}
          <Card>
            <CardHeader>
              <CardTitle>Data Category</CardTitle>
            </CardHeader>
            <CardContent>
              <Label>What type of data will your agent process? *</Label>
              <RadioGroup value={formData.dataType} onValueChange={(value) => handleChange('dataType', value)} required>
                <div className="flex items-center space-x-2 mt-2">
                  <RadioGroupItem value="public" id="public" />
                  <Label htmlFor="public" className="font-normal">Public/Non-sensitive data</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="internal" id="internal" />
                  <Label htmlFor="internal" className="font-normal">Internal business documents</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="aws_support" id="aws_support" />
                  <Label htmlFor="aws_support" className="font-normal">AWS Support data</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="partner" id="partner" />
                  <Label htmlFor="partner" className="font-normal">Business Partner data</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="customer" id="customer" />
                  <Label htmlFor="customer" className="font-normal">Customer data or content</Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Use Case & Output */}
          <Card>
            <CardHeader>
              <CardTitle>Use Case & Intended Output</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>What is the primary use case? *</Label>
                <RadioGroup value={formData.useCase} onValueChange={(value) => handleChange('useCase', value)} required>
                  <div className="flex items-center space-x-2 mt-2">
                    <RadioGroupItem value="summarization" id="summarization" />
                    <Label htmlFor="summarization" className="font-normal">Summarization</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="document_generation" id="document_generation" />
                    <Label htmlFor="document_generation" className="font-normal">Document generation (PRFAQ, MBR)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="automation" id="automation" />
                    <Label htmlFor="automation" className="font-normal">Workflow automation</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="analysis" id="analysis" />
                    <Label htmlFor="analysis" className="font-normal">Data analysis</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="qa" id="qa" />
                    <Label htmlFor="qa" className="font-normal">Q&A / Knowledge retrieval</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>Intended Output *</Label>
                <RadioGroup value={formData.outputType} onValueChange={(value) => handleChange('outputType', value)} required>
                  <div className="flex items-center space-x-2 mt-2">
                    <RadioGroupItem value="summary" id="summary" />
                    <Label htmlFor="summary" className="font-normal">Summary</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="email" id="email" />
                    <Label htmlFor="email" className="font-normal">Email</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="ticket_update" id="ticket_update" />
                    <Label htmlFor="ticket_update" className="font-normal">Ticket Update</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="report" id="report" />
                    <Label htmlFor="report" className="font-normal">Report</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="internal_teams" id="internal_teams" />
                    <Label htmlFor="internal_teams" className="font-normal">Internal dashboard/tool</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="external" id="external" />
                    <Label htmlFor="external" className="font-normal">External communication</Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
          </Card>

          {/* Integrations */}
          <Card>
            <CardHeader>
              <CardTitle>Expected Integrations</CardTitle>
            </CardHeader>
            <CardContent>
              <Label>Will your agent integrate with other tools? *</Label>
              <RadioGroup value={formData.integration} onValueChange={(value) => handleChange('integration', value)} required>
                <div className="flex items-center space-x-2 mt-2">
                  <RadioGroupItem value="none" id="none" />
                  <Label htmlFor="none" className="font-normal">None</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="slack" id="slack" />
                  <Label htmlFor="slack" className="font-normal">Slack</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="quip" id="quip" />
                  <Label htmlFor="quip" className="font-normal">Quip</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="internal" id="internal" />
                  <Label htmlFor="internal" className="font-normal">Other internal tools</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="external" id="external" />
                  <Label htmlFor="external" className="font-normal">External tools or APIs</Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Access Level */}
          <Card>
            <CardHeader>
              <CardTitle>Access & Permissions</CardTitle>
            </CardHeader>
            <CardContent>
              <Label>What level of access does your agent need? *</Label>
              <RadioGroup value={formData.accessLevel} onValueChange={(value) => handleChange('accessLevel', value)} required>
                <div className="flex items-center space-x-2 mt-2">
                  <RadioGroupItem value="view" id="view" />
                  <Label htmlFor="view" className="font-normal">View-only</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="edit" id="edit" />
                  <Label htmlFor="edit" className="font-normal">Can edit/update data</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="admin" id="admin" />
                  <Label htmlFor="admin" className="font-normal">Full admin or case access</Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Other Details */}
          <Card>
            <CardHeader>
              <CardTitle>Other Details (Optional)</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.otherDetails}
                onChange={(e) => handleChange('otherDetails', e.target.value)}
                placeholder="May later expand to handle multilingual data..."
                rows={3}
              />
            </CardContent>
          </Card>

          <Button type="submit" className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white text-lg py-6">
            Submit Concept Review
          </Button>
        </form>
      </main>

      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE
        </div>
      </footer>
    </div>
  );
};

export default ConceptReview;

