import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, Upload, ExternalLink, Loader2, FileText } from 'lucide-react';
import { generateSaferAIPDF } from '@/lib/pdfGenerator.js';

// Get API endpoint from environment variable
const PROMPT_ANALYZER_API = import.meta.env.VITE_PROMPT_ANALYZER_API || 'https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1/analyze';

const ProductReview = () => {
  const [step, setStep] = useState(1);
  const [conceptPDF, setConceptPDF] = useState(null);
  const [conceptData, setConceptData] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [promptAnalyzing, setPromptAnalyzing] = useState(false);
  const [promptScore, setPromptScore] = useState(null);
  const [promptFindings, setPromptFindings] = useState([]);
  const [promptSuggestions, setPromptSuggestions] = useState([]);
  const [promptError, setPromptError] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [totalScore, setTotalScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');
  const [comparison, setComparison] = useState(null);

  // Basic project details
  const [projectDetails, setProjectDetails] = useState({
    projectName: '',
    developer: '',
    org: '',
    loginId: '',
    date: new Date().toISOString().split('T')[0],
    goal: '',
    devType: '',
    stage: '',
    platform: '',
    dataCategory: '',
    intendedOutput: '',
    expectedIntegrations: '',
    teamSize: '',
    otherDetails: ''
  });

  const questions = [
    {
      section: 'A. Project Changes',
      items: [
        {
          id: 'changes',
          question: 'Did you make any major changes since your Concept Review?',
          options: [
            { text: 'No changes', score: 0 },
            { text: 'Added small improvements', score: 2 },
            { text: 'Added new features or data', score: 5 }
          ]
        },
        {
          id: 'platform_change',
          question: 'Did you use a different platform or tool from what you planned?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes, but internal', score: 2 },
            { text: 'Yes, a new or external one', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'B. Prompts & Instructions',
      items: [
        {
          id: 'prompt_test',
          question: 'Did you test your prompt using the SaferAI Analyzer?',
          options: [
            { text: 'Yes, and no issues found', score: 0 },
            { text: 'Yes, with a few warnings', score: 2 },
            { text: "Didn't test or high-risk warnings", score: 5 }
          ]
        },
        {
          id: 'prompt_sensitive',
          question: 'Do your prompts include any internal or sensitive info?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Maybe some internal words', score: 3 },
            { text: 'Yes, customer or private data', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'C. Data Handling',
      items: [
        {
          id: 'data_type',
          question: 'What kind of data does your bot now use?',
          options: [
            { text: 'Public or sample data', score: 0 },
            { text: 'Internal data', score: 2 },
            { text: 'Customer or private data', score: 5 }
          ]
        },
        {
          id: 'data_external',
          question: 'Does your bot send or store data outside Amazon systems?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Yes, but internal tools', score: 2 },
            { text: 'Yes, to third-party apps', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'D. Permissions',
      items: [
        {
          id: 'access_level',
          question: 'What access does your bot need?',
          options: [
            { text: 'View-only', score: 0 },
            { text: 'Can edit/update some things', score: 3 },
            { text: 'Full admin or case access', score: 5 }
          ]
        },
        {
          id: 'credentials',
          question: 'Does your bot keep or reuse login details automatically?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Sometimes', score: 3 },
            { text: 'Yes', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'E. Outputs',
      items: [
        {
          id: 'output_visibility',
          question: 'Who can see the outputs of your bot?',
          options: [
            { text: 'My team only', score: 0 },
            { text: 'Other internal teams', score: 3 },
            { text: 'Anyone external', score: 5 }
          ]
        },
        {
          id: 'output_review',
          question: 'Are the outputs reviewed by a human before use?',
          options: [
            { text: 'Always', score: 0 },
            { text: 'Sometimes', score: 3 },
            { text: 'Never', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'F. Integrations',
      items: [
        {
          id: 'integrations',
          question: 'Does your bot connect with any other tools?',
          options: [
            { text: 'No', score: 0 },
            { text: 'Internal ones like Slack or Quip', score: 2 },
            { text: 'External public ones', score: 5 }
          ]
        },
        {
          id: 'token_storage',
          question: 'Are passwords or tokens stored securely?',
          options: [
            { text: 'Yes, handled safely', score: 0 },
            { text: 'Stored locally', score: 2 },
            { text: 'Hardcoded', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'G. Stability',
      items: [
        {
          id: 'testing',
          question: 'Have you tested it for errors or weird results?',
          options: [
            { text: "Yes, it's reliable", score: 0 },
            { text: 'Sometimes glitches', score: 3 },
            { text: 'Not yet tested', score: 5 }
          ]
        },
        {
          id: 'failure_handling',
          question: 'If it fails, can it stop safely without breaking things?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Maybe', score: 3 },
            { text: 'No', score: 5 }
          ]
        }
      ]
    },
    {
      section: 'H. Monitoring',
      items: [
        {
          id: 'logging',
          question: 'Do you have logs or some way to track what it does?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Partially', score: 2 },
            { text: 'No', score: 5 }
          ]
        },
        {
          id: 'monitoring',
          question: 'Is there someone responsible for watching how it behaves?',
          options: [
            { text: 'Yes', score: 0 },
            { text: 'Not decided', score: 3 },
            { text: 'No', score: 5 }
          ]
        }
      ]
    }
  ];

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setConceptPDF(file);
      // In a real implementation, you would parse the PDF here
      // For now, we'll simulate concept data
      setConceptData({
        platform: 'Cedric',
        dataCategory: 'Internal',
        intendedOutput: 'Summaries',
        expectedIntegrations: 'None'
      });
    }
  };

  const analyzePrompt = async () => {
    if (!prompt.trim()) {
      setPromptError('Please enter a prompt to analyze');
      return;
    }

    setPromptAnalyzing(true);
    setPromptError(null);
    
    try {
      const response = await fetch(PROMPT_ANALYZER_API, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success && data.analysis) {
        setPromptScore(data.analysis.score);
        setPromptFindings(data.analysis.findings || []);
        setPromptSuggestions(data.analysis.suggestions || []);
      } else {
        throw new Error(data.error || 'Failed to analyze prompt');
      }
    } catch (error) {
      console.error('Error analyzing prompt:', error);
      setPromptError(`Failed to analyze prompt: ${error.message}`);
      
      // Fallback to simple local analysis if API fails
      let score = 0;
      const lowerPrompt = prompt.toLowerCase();
      const findings = [];
      const suggestions = [];
      
      if (lowerPrompt.includes('customer') || lowerPrompt.includes('ticket') || lowerPrompt.includes('case')) {
        score += 4;
        findings.push('Prompt may reference customer data or case content');
        suggestions.push('Use summary metadata instead of full customer data');
      }
      if (lowerPrompt.includes('email') || lowerPrompt.includes('personal')) {
        score += 3;
        findings.push('Prompt may contain email or personal information references');
        suggestions.push('Avoid including full email content in prompts');
      }
      if (lowerPrompt.includes('admin') || lowerPrompt.includes('delete')) {
        score += 3;
        findings.push('Prompt references admin or privileged operations');
        suggestions.push('Ensure proper authorization for privileged operations');
      }
      
      setPromptScore(Math.min(score, 10));
      setPromptFindings(findings);
      setPromptSuggestions(suggestions);
    } finally {
      setPromptAnalyzing(false);
    }
  };

  const handleAnswer = (questionId, optionIndex) => {
    const allQuestions = questions.flatMap(section => section.items);
    const question = allQuestions.find(q => q.id === questionId);
    setAnswers({
      ...answers,
      [questionId]: {
        answer: question.options[optionIndex].text,
        score: question.options[optionIndex].score
      }
    });
  };

  const calculateFinalScore = () => {
    let score = 0;
    Object.values(answers).forEach(answer => {
      score += answer.score;
    });
    
    if (promptScore !== null) {
      score += promptScore;
    }
    
    // Total is out of 90 (80 from questions + 10 from prompt)
    // Normalize to 45 scale: score / 2
    const normalizedScore = Math.round(score / 2);
    setTotalScore(normalizedScore);
    
    // Determine risk zone
    if (normalizedScore <= 18) {
      setRiskZone('green');
    } else if (normalizedScore <= 32) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }

    // Generate comparison if concept data exists
    if (conceptData) {
      const comp = {};
      if (conceptData.platform !== projectDetails.platform) {
        comp.Platform = {
          concept: conceptData.platform,
          product: projectDetails.platform,
          status: 'Changed'
        };
      }
      if (conceptData.dataCategory !== projectDetails.dataCategory) {
        comp['Data Source'] = {
          concept: conceptData.dataCategory,
          product: projectDetails.dataCategory,
          status: 'Broadened'
        };
      }
      if (conceptData.intendedOutput !== projectDetails.intendedOutput) {
        comp.Output = {
          concept: conceptData.intendedOutput,
          product: projectDetails.intendedOutput,
          status: 'Expanded'
        };
      }
      if (Object.keys(comp).length > 0) {
        setComparison(comp);
      }
    }
  };

  const handleSubmit = () => {
    calculateFinalScore();
    setSubmitted(true);
  };

  const getRiskZoneDetails = () => {
    const zones = {
      green: {
        icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
        title: 'Green Zone – Safe to Launch',
        color: 'bg-green-50 border-green-200',
        message: 'Works as planned with safe boundaries. Your product is ready for deployment.',
        suggestions: [
          'Document deployment procedures',
          'Set up monitoring dashboards',
          'Schedule regular review cycles',
          'Proceed with launch'
        ]
      },
      amber: {
        icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
        title: 'Amber Zone – Needs Fixes',
        color: 'bg-yellow-50 border-yellow-200',
        message: 'Minor risks or unclear prompts detected. Address these before full deployment.',
        suggestions: [
          'Avoid customer wording in prompts',
          'Re-test after trimming integrations',
          'Add human review checkpoints',
          'Enhance logging and monitoring',
          'Resubmit after fixes'
        ]
      },
      red: {
        icon: <XCircle className="h-16 w-16 text-red-600" />,
        title: 'Red Zone – Rework Needed',
        color: 'bg-red-50 border-red-200',
        message: 'Data, permissions, or output handling is too risky. SWAT consultation required.',
        suggestions: [
          'Schedule SWAT consultation immediately',
          'Review data classification and access levels',
          'Consider alternative architectures',
          'Do not deploy without SWAT approval',
          'Document all security concerns'
        ]
      }
    };
    return zones[riskZone] || zones.green;
  };

  const downloadPDF = async () => {
    const zoneDetails = getRiskZoneDetails();
    
    const pdfData = {
      projectName: projectDetails.projectName,
      developer: projectDetails.developer,
      org: projectDetails.org,
      loginId: projectDetails.loginId,
      platform: projectDetails.platform,
      date: projectDetails.date,
      stage: projectDetails.stage,
      devType: projectDetails.devType,
      zone: zoneDetails.title,
      score: totalScore,
      maxScore: 45,
      findings: [
        `Prompt Risk Score: ${promptScore}/10`,
        ...promptFindings,
        `Project Changes: ${answers.changes?.answer || 'N/A'}`,
        `Data Type: ${answers.data_type?.answer || 'N/A'}`,
        `Access Level: ${answers.access_level?.answer || 'N/A'}`,
        `Output Visibility: ${answers.output_visibility?.answer || 'N/A'}`,
        `Testing Status: ${answers.testing?.answer || 'N/A'}`
      ],
      suggestions: [...new Set([...zoneDetails.suggestions, ...promptSuggestions])],
      comparison: comparison
    };

    await generateSaferAIPDF(pdfData, 'product');
  };

  const getProgressPercentage = () => {
    const totalQuestions = questions.flatMap(s => s.items).length;
    const answeredQuestions = Object.keys(answers).length;
    return Math.round((answeredQuestions / totalQuestions) * 100);
  };

  if (submitted) {
    const zoneDetails = getRiskZoneDetails();
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-[#232F3E] text-white py-6 px-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review Results</p>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-8 py-12">
          {/* Comparison Table */}
          {comparison && (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Concept vs Product Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-4">Parameter</th>
                        <th className="text-left py-2 px-4">Planned (Concept)</th>
                        <th className="text-left py-2 px-4">Built (Product)</th>
                        <th className="text-left py-2 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(comparison).map(([key, value]) => (
                        <tr key={key} className="border-b">
                          <td className="py-2 px-4 font-medium">{key}</td>
                          <td className="py-2 px-4">{value.concept}</td>
                          <td className="py-2 px-4">{value.product}</td>
                          <td className="py-2 px-4">
                            <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
                              {value.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          <Card className={`border-2 ${zoneDetails.color} mb-8`}>
            <CardHeader>
              <div className="flex items-center gap-4">
                {zoneDetails.icon}
                <div>
                  <CardTitle className="text-2xl mb-2">{zoneDetails.title}</CardTitle>
                  <p className="text-gray-700">{zoneDetails.message}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-2">Final Score: {totalScore} / 45</h3>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className={`h-4 rounded-full ${
                      riskZone === 'green' ? 'bg-green-500' :
                      riskZone === 'amber' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(totalScore / 45) * 100}%` }}
                  ></div>
                </div>
              </div>

              {promptScore !== null && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-semibold mb-2">Prompt Analysis Results</h3>
                  <p className="text-sm mb-2">Risk score: {promptScore} / 10</p>
                  {promptFindings.length > 0 && (
                    <div className="text-sm mt-2">
                      <p className="font-medium text-red-600 mb-1">⚠️ Findings:</p>
                      <ul className="list-disc ml-5 space-y-1">
                        {promptFindings.map((finding, idx) => (
                          <li key={idx}>{finding}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {promptScore <= 3 && (
                    <p className="text-sm text-green-600 mt-2">✓ No major issues detected</p>
                  )}
                </div>
              )}

              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3">Recommendations:</h3>
                <ul className="space-y-2">
                  {zoneDetails.suggestions.map((suggestion, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-[#FF9900] mt-1">•</span>
                      <span>{suggestion}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-4 flex-wrap">
                <Button onClick={downloadPDF} className="bg-[#232F3E] hover:bg-[#1a2332]">
                  <Download className="mr-2 h-4 w-4" />
                  Download PDF Report
                </Button>
                {riskZone === 'red' && (
                  <a href="https://asana.amazon.com/create?project=SWAT_Consultations" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Contact SWAT
                    </Button>
                  </a>
                )}
                <Button onClick={() => { setSubmitted(false); setStep(1); }} variant="outline">
                  Start New Review
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Detailed Score Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-semibold mb-2">Prompt Analysis</h4>
                    <p className="text-2xl font-bold text-[#FF9900]">{promptScore || 0} / 10</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-semibold mb-2">Questions Total</h4>
                    <p className="text-2xl font-bold text-[#FF9900]">
                      {Object.values(answers).reduce((sum, a) => sum + a.score, 0)} / 80
                    </p>
                  </div>
                </div>

                {questions.map((section, idx) => (
                  <div key={idx} className="border-t pt-4">
                    <h4 className="font-semibold mb-2">{section.section}</h4>
                    <div className="space-y-2 ml-4">
                      {section.items.map((item) => (
                        <div key={item.id} className="flex justify-between text-sm">
                          <span className="text-gray-600">{item.question}</span>
                          <div className="text-right">
                            <span className="font-medium block">
                              {answers[item.id]?.score || 0} points
                            </span>
                            <span className="text-xs text-gray-500">
                              {answers[item.id]?.answer || 'Not answered'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="bg-gray-100 py-4 mt-16">
          <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
            © Amazon Seller Support TSE — SaferAI Framework
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#232F3E] text-white py-6 px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">SaferAI</h1>
            <p className="text-sm text-gray-300 mt-1">Product Review</p>
          </div>
          {step === 4 && (
            <div className="text-right">
              <p className="text-sm text-gray-300">Progress</p>
              <p className="text-2xl font-bold text-[#FF9900]">{getProgressPercentage()}%</p>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Product Review</h2>
          <p className="text-lg text-gray-600">
            Review your completed AI agent to ensure it matches your original concept and meets security standards.
          </p>
        </div>

        {/* Step Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {[
              { num: 1, label: 'Project Details' },
              { num: 2, label: 'Upload Concept' },
              { num: 3, label: 'Prompt Analysis' },
              { num: 4, label: 'Review Questions' }
            ].map((s, idx) => (
              <div key={s.num} className="flex items-center flex-1">
                <div className={`flex items-center ${step >= s.num ? 'text-[#FF9900]' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= s.num ? 'bg-[#FF9900] text-white' : 'bg-gray-200'}`}>
                    {s.num}
                  </div>
                  <span className="ml-2 text-sm font-medium hidden md:inline">{s.label}</span>
                </div>
                {idx < 3 && <div className={`flex-1 h-1 mx-4 ${step > s.num ? 'bg-[#FF9900]' : 'bg-gray-200'}`}></div>}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1: Project Details */}
        {step === 1 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Step 1: Basic Project Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="projectName">Project Name *</Label>
                    <Input
                      id="projectName"
                      value={projectDetails.projectName}
                      onChange={(e) => setProjectDetails({...projectDetails, projectName: e.target.value})}
                      placeholder="AutoSummarizer for Ops Reports"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="developer">Developer Name *</Label>
                    <Input
                      id="developer"
                      value={projectDetails.developer}
                      onChange={(e) => setProjectDetails({...projectDetails, developer: e.target.value})}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="org">Organization *</Label>
                    <Input
                      id="org"
                      value={projectDetails.org}
                      onChange={(e) => setProjectDetails({...projectDetails, org: e.target.value})}
                      placeholder="SPS CT SWAT"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="loginId">Login ID *</Label>
                    <Input
                      id="loginId"
                      value={projectDetails.loginId}
                      onChange={(e) => setProjectDetails({...projectDetails, loginId: e.target.value})}
                      placeholder="jdoe@amazon.com"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="platform">Platform *</Label>
                    <Input
                      id="platform"
                      value={projectDetails.platform}
                      onChange={(e) => setProjectDetails({...projectDetails, platform: e.target.value})}
                      placeholder="Cedric / Amazon Q Internal / BedrockBot"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="stage">Development Stage *</Label>
                    <Input
                      id="stage"
                      value={projectDetails.stage}
                      onChange={(e) => setProjectDetails({...projectDetails, stage: e.target.value})}
                      placeholder="Prototype / Pilot / Production"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="devType">Type of Development *</Label>
                    <Input
                      id="devType"
                      value={projectDetails.devType}
                      onChange={(e) => setProjectDetails({...projectDetails, devType: e.target.value})}
                      placeholder="GenAI Agent / Workflow Automation"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="dataCategory">Data Category *</Label>
                    <Input
                      id="dataCategory"
                      value={projectDetails.dataCategory}
                      onChange={(e) => setProjectDetails({...projectDetails, dataCategory: e.target.value})}
                      placeholder="Internal / AWS Support / Customer"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="intendedOutput">Intended Output *</Label>
                    <Input
                      id="intendedOutput"
                      value={projectDetails.intendedOutput}
                      onChange={(e) => setProjectDetails({...projectDetails, intendedOutput: e.target.value})}
                      placeholder="Summary / Email / Report"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="expectedIntegrations">Expected Integrations</Label>
                    <Input
                      id="expectedIntegrations"
                      value={projectDetails.expectedIntegrations}
                      onChange={(e) => setProjectDetails({...projectDetails, expectedIntegrations: e.target.value})}
                      placeholder="Slack / Sheets / None"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="goal">Goal / Problem Statement *</Label>
                  <Textarea
                    id="goal"
                    value={projectDetails.goal}
                    onChange={(e) => setProjectDetails({...projectDetails, goal: e.target.value})}
                    placeholder="Reduce manual effort in summarizing daily reports"
                    rows={3}
                    required
                  />
                </div>
              </CardContent>
            </Card>

            <Button 
              onClick={() => setStep(2)} 
              disabled={!projectDetails.projectName || !projectDetails.developer || !projectDetails.org || !projectDetails.platform}
              className="w-full bg-[#FF9900] hover:bg-[#ec8f00]"
            >
              Continue to Upload Concept
            </Button>
          </div>
        )}

        {/* Step 2: Upload Concept PDF */}
        {step === 2 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Step 2: Upload Concept Review (Optional)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Upload your Concept Review PDF to compare planned vs. built features. SaferAI will automatically detect changes.
                </p>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-[#FF9900] transition-colors">
                  <FileText className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <Label htmlFor="concept-upload" className="cursor-pointer">
                    <span className="text-[#FF9900] hover:underline text-lg font-medium">Click to upload</span>
                    <span className="text-gray-600"> or drag and drop</span>
                  </Label>
                  <p className="text-sm text-gray-500 mt-2">PDF files only</p>
                  <Input
                    id="concept-upload"
                    type="file"
                    accept=".pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  {conceptPDF && (
                    <div className="mt-6 p-4 bg-green-50 rounded-lg">
                      <p className="text-green-600 font-medium">✓ {conceptPDF.name} uploaded successfully</p>
                      <p className="text-sm text-gray-600 mt-2">SaferAI will compare this with your current build</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <Button onClick={() => setStep(1)} variant="outline" className="flex-1">
                Back
              </Button>
              <Button onClick={() => setStep(3)} className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00]">
                {conceptPDF ? 'Continue with Concept' : 'Skip & Continue'}
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Prompt Analysis */}
        {step === 3 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Step 3: Prompt Security Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Paste your main prompt or example input to analyze for security risks. This connects to the SaferAI Lambda backend.
                </p>
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Enter your prompt here... For example: 'Summarize the customer ticket and generate a response email'"
                  rows={8}
                  className="mb-4 font-mono text-sm"
                />
                {promptError && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-sm text-red-600">
                    {promptError}
                  </div>
                )}
                <div className="flex gap-4">
                  <Button
                    onClick={analyzePrompt}
                    disabled={!prompt || promptAnalyzing}
                    className="bg-[#232F3E] hover:bg-[#1a2332]"
                  >
                    {promptAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Analyze Prompt
                      </>
                    )}
                  </Button>
                  {promptScore !== null && (
                    <Button onClick={() => setStep(4)} className="bg-[#FF9900] hover:bg-[#ec8f00]">
                      Continue to Questions
                    </Button>
                  )}
                </div>
                {promptScore !== null && (
                  <div className="mt-6 p-6 bg-gray-50 rounded-lg border-2 border-gray-200">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-lg">Analysis Results</h4>
                      <div className={`px-4 py-2 rounded-full font-bold ${
                        promptScore <= 3 ? 'bg-green-100 text-green-700' :
                        promptScore <= 6 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        Risk: {promptScore} / 10
                      </div>
                    </div>
                    {promptFindings.length > 0 ? (
                      <div className="text-sm">
                        <p className="font-medium text-red-600 mb-2">⚠️ Findings:</p>
                        <ul className="list-disc ml-5 mt-2 space-y-1 mb-4">
                          {promptFindings.map((finding, idx) => (
                            <li key={idx} className="text-gray-700">{finding}</li>
                          ))}
                        </ul>
                        {promptSuggestions.length > 0 && (
                          <>
                            <p className="font-medium text-blue-600 mb-2">💡 Suggestions:</p>
                            <ul className="list-disc ml-5 mt-2 space-y-1">
                              {promptSuggestions.slice(0, 4).map((suggestion, idx) => (
                                <li key={idx} className="text-gray-700">{suggestion}</li>
                              ))}
                            </ul>
                          </>
                        )}
                      </div>
                    ) : (
                      <p className="text-sm text-green-600 font-medium">✓ No major issues detected in your prompt</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <Button onClick={() => setStep(2)} variant="outline" className="flex-1">
                Back
              </Button>
            </div>
          </div>
        )}

        {/* Step 4: Review Questions */}
        {step === 4 && (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-800">
                <strong>Instructions:</strong> Answer all questions below. Each question is rated from 0 to 5 points. 
                Your total score (including prompt analysis) will determine your risk zone.
              </p>
            </div>

            {questions.map((section, sectionIdx) => (
              <Card key={sectionIdx}>
                <CardHeader>
                  <CardTitle className="text-[#232F3E]">{section.section}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {section.items.map((item) => (
                    <div key={item.id} className="pb-4 border-b last:border-b-0 last:pb-0">
                      <Label className="text-base mb-3 block font-medium">{item.question}</Label>
                      <RadioGroup
                        value={answers[item.id]?.answer}
                        onValueChange={(value) => {
                          const optionIndex = item.options.findIndex(opt => opt.text === value);
                          handleAnswer(item.id, optionIndex);
                        }}
                      >
                        <div className="space-y-2">
                          {item.options.map((option, optIdx) => (
                            <div 
                              key={optIdx} 
                              className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                                answers[item.id]?.answer === option.text 
                                  ? 'border-[#FF9900] bg-orange-50' 
                                  : 'border-gray-200 hover:border-gray-300'
                              }`}
                            >
                              <RadioGroupItem value={option.text} id={`${item.id}-${optIdx}`} />
                              <Label 
                                htmlFor={`${item.id}-${optIdx}`} 
                                className="font-normal flex-1 cursor-pointer"
                              >
                                {option.text}
                                <span className={`ml-2 text-xs ${
                                  option.score === 0 ? 'text-green-600' :
                                  option.score <= 3 ? 'text-yellow-600' :
                                  'text-red-600'
                                }`}>
                                  ({option.score} {option.score === 1 ? 'point' : 'points'})
                                </span>
                              </Label>
                            </div>
                          ))}
                        </div>
                      </RadioGroup>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}

            <div className="sticky bottom-4 bg-white border-2 border-gray-200 rounded-lg p-4 shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold">Progress: {getProgressPercentage()}% Complete</span>
                <span className="text-sm text-gray-600">
                  {Object.keys(answers).length} / {questions.flatMap(s => s.items).length} answered
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div 
                  className="bg-[#FF9900] h-2 rounded-full transition-all duration-300"
                  style={{ width: `${getProgressPercentage()}%` }}
                ></div>
              </div>
              <div className="flex gap-4">
                <Button onClick={() => setStep(3)} variant="outline" className="flex-1">
                  Back to Prompt
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={Object.keys(answers).length < questions.flatMap(s => s.items).length}
                  className="flex-1 bg-[#FF9900] hover:bg-[#ec8f00] text-white text-lg py-6"
                >
                  Submit Product Review
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-gray-100 py-4 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © Amazon Seller Support TSE — SaferAI Framework
        </div>
      </footer>
    </div>
  );
};

export default ProductReview;

