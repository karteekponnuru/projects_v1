"""
SaferAI Prompt Security Analyzer
AWS Lambda Function (Python)

Analyzes prompts for security risks and sensitive data exposure
"""

import json
import re
from datetime import datetime
from typing import Dict, List, Tuple

# Security patterns to detect
SECURITY_PATTERNS = {
    'customer_data': {
        'patterns': [
            r'customer.*data',
            r'customer.*content',
            r'customer.*information',
            r'customer.*email',
            r'customer.*name',
            r'customer.*address',
            r'customer.*phone',
            r'case\s+data',
            r'ticket\s+text',
            r'ticket\s+content',
            r'case\s+content'
        ],
        'severity': 5,
        'message': 'Prompt references customer data or case content'
    },
    'pii_data': {
        'patterns': [
            r'\b(ssn|social\s+security)\b',
            r'\b(credit\s+card|payment)\b',
            r'\bpii\b',
            r'personal.*identif',
            r'sensitive.*data',
            r'confidential'
        ],
        'severity': 5,
        'message': 'Prompt may contain or request PII/sensitive data'
    },
    'credentials': {
        'patterns': [
            r'\b(password|passwd|pwd)\b',
            r'\b(api[_\s]?key|apikey)\b',
            r'\b(secret|token)\b',
            r'\b(credential|auth)\b',
            r'access[_\s]?key'
        ],
        'severity': 4,
        'message': 'Prompt references credentials or secrets'
    },
    'admin_operations': {
        'patterns': [
            r'\b(admin|administrator)\b',
            r'\b(delete|remove|drop)\b',
            r'\b(sudo|root)\b',
            r'\belevated\b',
            r'\bprivileged\b'
        ],
        'severity': 3,
        'message': 'Prompt references admin or privileged operations'
    },
    'email_content': {
        'patterns': [
            r'email\s+content',
            r'email\s+body',
            r'message\s+content',
            r'\bfull\s+email'
        ],
        'severity': 3,
        'message': 'Prompt requests full email or message content'
    },
    'system_access': {
        'patterns': [
            r'\b(database|db)\b',
            r'\b(query|select|insert|update)\b',
            r'\b(table|schema)\b',
            r'system\s+access'
        ],
        'severity': 3,
        'message': 'Prompt references database or system access'
    },
    'internal_ids': {
        'patterns': [
            r'\b(internal\s+id|employee\s+id)\b',
            r'\b(user\s+id|userid)\b',
            r'\baccount\s+number'
        ],
        'severity': 2,
        'message': 'Prompt references internal identifiers'
    },
    'broad_requests': {
        'patterns': [
            r'\ball\s+(data|information|records)',
            r'\bevery\s+(customer|user|case)',
            r'\bcomplete\s+(history|record)',
            r'\bentire\s+(database|system)'
        ],
        'severity': 3,
        'message': 'Prompt contains overly broad data requests'
    }
}

# Additional risk factors
RISK_FACTORS = {
    'length': {
        'threshold': 500,
        'severity': 1,
        'message': 'Very long prompt may contain excessive context'
    },
    'multiple_requests': {
        'threshold': 3,
        'severity': 1,
        'message': 'Prompt contains multiple distinct requests'
    }
}


def analyze_prompt(prompt: str) -> Dict:
    """
    Analyze prompt for security risks
    
    Args:
        prompt: The prompt text to analyze
        
    Returns:
        Dictionary containing analysis results
    """
    if not prompt or not isinstance(prompt, str):
        return {
            'error': 'Invalid prompt provided',
            'score': 0,
            'findings': [],
            'suggestions': []
        }
    
    findings = []
    total_score = 0
    detected_patterns = set()
    
    # Check security patterns
    for category, config in SECURITY_PATTERNS.items():
        for pattern in config['patterns']:
            if re.search(pattern, prompt, re.IGNORECASE):
                if category not in detected_patterns:
                    findings.append({
                        'category': category,
                        'severity': config['severity'],
                        'message': config['message']
                    })
                    total_score += config['severity']
                    detected_patterns.add(category)
                break  # Only count each category once
    
    # Check additional risk factors
    if len(prompt) > RISK_FACTORS['length']['threshold']:
        findings.append({
            'category': 'prompt_length',
            'severity': RISK_FACTORS['length']['severity'],
            'message': RISK_FACTORS['length']['message']
        })
        total_score += RISK_FACTORS['length']['severity']
    
    # Check for multiple requests
    question_marks = len(re.findall(r'\?', prompt))
    and_requests = len(re.findall(r'\band\s+(also\s+)?(give|provide|show|tell)', prompt, re.IGNORECASE))
    request_count = question_marks + and_requests
    
    if request_count >= RISK_FACTORS['multiple_requests']['threshold']:
        findings.append({
            'category': 'multiple_requests',
            'severity': RISK_FACTORS['multiple_requests']['severity'],
            'message': RISK_FACTORS['multiple_requests']['message']
        })
        total_score += RISK_FACTORS['multiple_requests']['severity']
    
    # Cap score at 10
    final_score = min(total_score, 10)
    
    # Generate suggestions based on findings
    suggestions = generate_suggestions(findings, prompt)
    
    return {
        'score': final_score,
        'maxScore': 10,
        'riskLevel': get_risk_level(final_score),
        'findings': [f['message'] for f in findings],
        'suggestions': suggestions,
        'detectedCategories': list(detected_patterns),
        'promptLength': len(prompt),
        'timestamp': datetime.utcnow().isoformat() + 'Z'
    }


def get_risk_level(score: int) -> str:
    """Get risk level based on score"""
    if score <= 3:
        return 'LOW'
    elif score <= 6:
        return 'MEDIUM'
    return 'HIGH'


def generate_suggestions(findings: List[Dict], prompt: str) -> List[str]:
    """Generate suggestions based on findings"""
    suggestions = []
    categories = [f['category'] for f in findings]
    
    if 'customer_data' in categories:
        suggestions.append('Use summary metadata instead of full customer data or case content')
        suggestions.append('Reference case IDs rather than case content')
    
    if 'pii_data' in categories:
        suggestions.append('Remove references to PII and sensitive personal information')
        suggestions.append('Use anonymized or synthetic data for testing')
    
    if 'credentials' in categories:
        suggestions.append('Never include credentials, tokens, or secrets in prompts')
        suggestions.append('Use secure parameter stores for sensitive configuration')
    
    if 'admin_operations' in categories:
        suggestions.append('Limit prompt scope to read-only operations when possible')
        suggestions.append('Ensure proper authorization checks for privileged operations')
    
    if 'email_content' in categories:
        suggestions.append('Use email metadata (subject, date) instead of full content')
        suggestions.append('Implement content filtering before passing to AI')
    
    if 'broad_requests' in categories:
        suggestions.append('Narrow the scope of data requests')
        suggestions.append('Use specific filters and limits')
    
    if 'prompt_length' in categories:
        suggestions.append('Break down complex prompts into smaller, focused requests')
    
    if 'multiple_requests' in categories:
        suggestions.append('Separate multiple requests into individual prompts')
    
    # General suggestions if high risk
    if len(findings) > 0:
        suggestions.append('Review prompt against SaferAI data classification guidelines')
        suggestions.append('Consider adding human review checkpoints for outputs')
    
    return suggestions


def lambda_handler(event, context):
    """
    AWS Lambda handler function
    
    Args:
        event: API Gateway event
        context: Lambda context
        
    Returns:
        API Gateway response
    """
    # CORS headers
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'POST,OPTIONS'
    }
    
    # Handle preflight OPTIONS request
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }
    
    try:
        # Parse request body
        try:
            body = json.loads(event.get('body', '{}'))
        except json.JSONDecodeError:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': 'Invalid JSON in request body'
                })
            }
        
        prompt = body.get('prompt')
        
        if not prompt:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': 'Missing required field: prompt'
                })
            }
        
        # Analyze the prompt
        analysis = analyze_prompt(prompt)
        
        # Return results
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'analysis': analysis
            })
        }
    
    except Exception as e:
        print(f'Error analyzing prompt: {str(e)}')
        
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }


# For local testing
if __name__ == '__main__':
    test_prompt = "Analyze all customer ticket data and show me the email content from case #12345"
    print('Testing prompt analyzer...')
    print(f'Prompt: {test_prompt}')
    print(f'\nResults: {json.dumps(analyze_prompt(test_prompt), indent=2)}')

