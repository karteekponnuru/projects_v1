// Concept Review Questions (Before Build)
export const CONCEPT_QUESTIONS = {
  dataSensitivity: {
    id: 'dataSensitivity',
    title: '1. Data Sensitivity',
    question: 'What kind of data will your agent use or process?',
    options: [
      { label: 'Test / Public data only', score: 0 },
      { label: 'Internal non-sensitive data', score: 1 },
      { label: 'Employee or operational data', score: 2 },
      { label: 'Customer metadata (IDs, summaries)', score: 3 },
      { label: 'Customer content (emails, chats, attachments)', score: 4 },
      { label: 'Security-sensitive / PII / credentials', score: 5 }
    ]
  },
  accessPermissions: {
    id: 'accessPermissions',
    title: '2. Access Permissions',
    question: 'What kind of access will the agent need?',
    options: [
      { label: 'None (sandboxed)', score: 0 },
      { label: 'Read-only scoped API', score: 1 },
      { label: 'Scoped write access (tag, assign)', score: 2 },
      { label: 'Cross-team or multi-tenant access', score: 3 },
      { label: 'Workflow approval or auto-closure', score: 4 },
      { label: 'Admin / Unfettered Search (UFS)', score: 5 }
    ]
  },
  outputSafety: {
    id: 'outputSafety',
    title: '3. Output Safety',
    question: 'What actions or outputs will your agent perform?',
    options: [
      { label: 'Suggestions or insights only', score: 0 },
      { label: 'Drafts for human review', score: 1 },
      { label: 'Internal updates (tags, notes)', score: 2 },
      { label: 'Auto-closes or updates workflows', score: 3 },
      { label: 'Sends internal/external messages', score: 4 },
      { label: 'Executes changes autonomously', score: 5 }
    ]
  },
  promptSecurity: {
    id: 'promptSecurity',
    title: '4. Prompt Security',
    question: 'Who can interact with or modify your agent\'s instructions?',
    options: [
      { label: 'Fixed system prompt only', score: 0 },
      { label: 'Internal staff (limited prompts)', score: 1 },
      { label: 'Internal users (free text allowed)', score: 2 },
      { label: 'Anyone in org (wide access)', score: 3 },
      { label: 'Accepts files / URLs', score: 4 },
      { label: 'External / public users', score: 5 }
    ]
  },
  externalIntegrations: {
    id: 'externalIntegrations',
    title: '5. External Integrations',
    question: 'Will your agent connect to any external systems or APIs?',
    options: [
      { label: 'None', score: 0 },
      { label: 'Internal tools (Nemo, Workfront)', score: 1 },
      { label: 'Internal AWS APIs (Lambda, S3)', score: 2 },
      { label: 'Third-party SaaS (Slack, Jira)', score: 3 },
      { label: 'Public APIs / Internet calls', score: 4 },
      { label: 'Unverified / dynamic endpoints', score: 5 }
    ]
  },
  businessImpact: {
    id: 'businessImpact',
    title: '6. Business Impact',
    question: 'What happens if the agent fails or misbehaves?',
    options: [
      { label: 'None (test only)', score: 0 },
      { label: 'Internal efficiency impact', score: 1 },
      { label: 'Team-level disruption', score: 2 },
      { label: 'Cross-org disruption', score: 3 },
      { label: 'Customer-facing impact', score: 4 },
      { label: 'Compliance / financial impact', score: 5 }
    ]
  },
  complianceReview: {
    id: 'complianceReview',
    title: '7. Compliance & Review',
    question: 'Has this idea been reviewed or approved?',
    options: [
      { label: 'Already reviewed and approved', score: 0 },
      { label: 'Reviewed by peer / pending SWAT', score: 2 },
      { label: 'Not yet reviewed', score: 3 },
      { label: 'Rejected or unsure', score: 5 }
    ]
  },
  monitoring: {
    id: 'monitoring',
    title: '8. Monitoring',
    question: 'Will your agent have logging or monitoring?',
    options: [
      { label: 'Full logging and dashboards', score: 0 },
      { label: 'Partial logs (success/failure)', score: 2 },
      { label: 'Manual tracking only', score: 3 },
      { label: 'No monitoring planned', score: 5 }
    ]
  }
};

// Product Review Questions (After Build)
export const PRODUCT_QUESTIONS = {
  dataHandling: {
    id: 'dataHandling',
    title: '1. Data Handling',
    question: 'What kind of data does your agent now access or store?',
    options: [
      { label: 'Test / mock data only', score: 0 },
      { label: 'Internal data', score: 1 },
      { label: 'Employee / anonymized customer data', score: 2 },
      { label: 'Customer metadata', score: 3 },
      { label: 'Customer content', score: 4 },
      { label: 'PII, security or credential data', score: 5 }
    ]
  },
  accessLevel: {
    id: 'accessLevel',
    title: '2. Access Level',
    question: 'What access level does the deployed agent use?',
    options: [
      { label: 'None / Read-only', score: 0 },
      { label: 'Scoped write access', score: 1 },
      { label: 'Cross-team write', score: 2 },
      { label: 'Auto-approval or closure', score: 3 },
      { label: 'Admin privileges', score: 4 },
      { label: 'Unfettered Search / broad access', score: 5 }
    ]
  },
  outputBehavior: {
    id: 'outputBehavior',
    title: '3. Output Behavior',
    question: 'What kind of actions or messages does it generate?',
    options: [
      { label: 'Internal summaries only', score: 0 },
      { label: 'Draft responses (reviewed)', score: 1 },
      { label: 'Internal tagging or updates', score: 2 },
      { label: 'Auto-actions without approval', score: 3 },
      { label: 'Sends internal/external communications', score: 4 },
      { label: 'Executes workflow changes directly', score: 5 }
    ]
  },
  inputHandling: {
    id: 'inputHandling',
    title: '4. Input Handling',
    question: 'Who can provide input to your agent?',
    options: [
      { label: 'Fixed system input', score: 0 },
      { label: 'Internal team only', score: 1 },
      { label: 'Internal org', score: 2 },
      { label: 'Vendors / third parties', score: 3 },
      { label: 'External customers', score: 4 },
      { label: 'Public or unverified users', score: 5 }
    ]
  },
  integrations: {
    id: 'integrations',
    title: '5. Integrations',
    question: 'What systems or APIs does your agent connect to?',
    options: [
      { label: 'None', score: 0 },
      { label: 'Internal APIs (Nemo, Workfront)', score: 1 },
      { label: 'AWS services (Lambda, DynamoDB)', score: 2 },
      { label: 'SaaS platforms (Slack, Jira)', score: 3 },
      { label: 'Public API endpoints', score: 4 },
      { label: 'Dynamic / unverified endpoints', score: 5 }
    ]
  },
  loggingAuditability: {
    id: 'loggingAuditability',
    title: '6. Logging & Auditability',
    question: 'Can you see what it\'s doing and when?',
    options: [
      { label: 'Full structured logs (CloudWatch, S3)', score: 0 },
      { label: 'Partial logging (key events only)', score: 2 },
      { label: 'Manual or local logs', score: 3 },
      { label: 'No audit logs', score: 5 }
    ]
  },
  failureHandling: {
    id: 'failureHandling',
    title: '7. Failure Handling',
    question: 'What happens when the agent encounters an error?',
    options: [
      { label: 'Fails gracefully / notifies admin', score: 0 },
      { label: 'Logs error only', score: 2 },
      { label: 'Stops silently', score: 3 },
      { label: 'Continues with incorrect data', score: 4 },
      { label: 'Impacts production or customers', score: 5 }
    ]
  },
  securityReview: {
    id: 'securityReview',
    title: '8. Security Review Status',
    question: 'What is the current security review status?',
    options: [
      { label: 'Completed full security review with approval', score: 0 },
      { label: 'Peer reviewed by team lead', score: 1 },
      { label: 'Self-assessed only', score: 3 },
      { label: 'No security review conducted', score: 5 }
    ]
  }
};

// Platform options
export const PLATFORMS = [
  'PartyRock',
  'Amazon Q Business',
  'Bedrock Playground',
  'Approved Chatbots (Cedric, Mentor, Field Advisor)',
  'Custom Bedrock Integration'
];

// Development types
export const DEVELOPMENT_TYPES = [
  { value: 'low-code', label: 'Low Code (PartyRock, Q Business, No-Code Tools)' },
  { value: 'high-code', label: 'High Code (Custom Bedrock, Lambda, Full Development)' }
];
