# SaferAI Portal - Enhanced Version

## 🎯 Overview

SaferAI Portal is a comprehensive security assessment tool for AI applications on Amazon internal platforms. This enhanced version includes a guidance bot, improved user experience, and complete integration with AWS Bedrock for prompt security analysis.

## ✨ Key Features

### 1. **Intelligent Guidance Bot** 💬
- Floating chat assistant available on all pages
- Answers questions about platforms, scoring, and security
- Context-aware help for developers
- Quick question shortcuts for common scenarios

### 2. **Enhanced Home Page** 🏠
- Background story explaining SaferAI's purpose
- Clear value propositions for each review type
- Improved visual design and user flow
- Time estimates and feature highlights

### 3. **Concept Review** 🎯
- **Before you build** - Evaluate project feasibility
- 8 risk vectors with 40-point scoring system
- Platform selection guidance
- Clear go/no-go decision framework
- Risk thresholds: Low (0-16), Medium (17-28), High (29-40)

### 4. **Product Review** 🚀
- **After you build** - Production deployment assessment
- **ASR ID mandatory field** for compliance tracking
- **PDF upload** for documentation attachment
- **AI-powered prompt analysis** via AWS Bedrock
- Concept comparison capability
- Combined risk assessment (product + prompt)

### 5. **Platform Compatibility Matrix** 📊
- Interactive guide for platform-data combinations
- Real-time compatibility checking
- Detailed requirements and timelines
- Covers all Amazon internal AI platforms

## 🏗️ Architecture

### Frontend
- **Framework**: React 18 with Vite
- **Routing**: React Router v6
- **Styling**: Inline styles with hover states
- **State Management**: React hooks (useState)

### Backend Integration
- **API Gateway**: AWS API Gateway (prod-v1)
- **Prompt Analysis**: AWS Bedrock integration
- **Endpoint**: `https://2fjp2golx7.execute-api.ap-south-1.amazonaws.com/prod-v1`

### Components
```
src/
├── components/
│   ├── HomePage.jsx           - Landing page with PRFAQ background
│   ├── MechanismPage.jsx      - Platform compatibility matrix
│   ├── ConceptReviewPage.jsx  - Before-build assessment
│   ├── ProductReviewPage.jsx  - After-build assessment
│   └── GuidanceBot.jsx        - Floating help assistant
├── lib/
│   ├── scoringEngine.js       - 40-point scoring logic
│   └── pdfGenerator.js        - Report generation
├── config.js                  - API configuration
└── App.jsx                    - Main application component
```

## 📋 Scoring System

### Concept Review (0-40 points)
1. **Data Sensitivity** (0-5) - What data will be processed
2. **Access Permissions** (0-5) - What access level needed
3. **Output Safety** (0-5) - What actions will be performed
4. **Prompt Security** (0-5) - Who can interact with agent
5. **External Integrations** (0-5) - What systems connected
6. **Business Impact** (0-5) - Impact if agent fails
7. **Compliance & Review** (0, 2, 3, 5) - Review status
8. **Monitoring** (0, 2, 3, 5) - Logging plan

### Product Review (0-40 points)
1. **Data Handling** (0-5) - Actual data accessed
2. **Access Level** (0-5) - Deployed access level
3. **Output Behavior** (0-5) - Actions generated
4. **Input Handling** (0-5) - Who can provide input
5. **Integrations** (0-5) - Systems connected
6. **Logging & Auditability** (0, 2, 3, 5) - Audit capabilities
7. **Failure Handling** (0, 2, 3, 4, 5) - Error handling
8. **Compliance & Review** (0, 1, 3, 5) - Security review status

### Prompt Security (0-40 points)
8 security checks analyzing prompt design, injection resistance, secret exposure, and more.

## 🚀 Quick Start

### Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Access at http://localhost:5173
```

### Production Build

```bash
# Build for production
npm run build

# Preview production build
npm run preview

# Deploy dist/ folder to S3 + CloudFront
```

## 🔧 Configuration

### API Endpoint

Edit `src/config.js` to change API endpoints:

```javascript
export const API_CONFIG = {
  BASE_URL: 'https://your-api-gateway-url.com/prod-v1',
  ENDPOINTS: {
    PRODUCT_REVIEW: '/product-review',
    CONCEPT_REVIEW: '/concept-review',
    PROMPT_ANALYSIS: '/prompt-analysis'
  }
};
```

### Platform List

Supported platforms (configured in components):
- PartyRock
- Amazon Q Business
- Bedrock Playground
- Approved Chatbots (Cedric, Mentor, Field Advisor)
- Custom Bedrock Integration

## 📖 User Guide

### For Concept Review (Before Build)

1. Navigate to **Concept Review** page
2. Fill in project information
3. Answer 8 risk assessment questions
4. Review your risk score and recommendations
5. Proceed based on risk level:
   - 🟢 **Low (0-16)**: Safe to proceed
   - 🟡 **Medium (17-28)**: File TT for visibility
   - 🔴 **High (29-40)**: Raise SIM before building

### For Product Review (After Build)

1. Navigate to **Product Review** page
2. Fill in project information including **ASR ID** (mandatory)
3. Upload documentation (PDF, optional)
4. Paste your system prompt for analysis
5. Click "Analyze Prompt Security" for AI-powered review
6. Answer 8 product assessment questions
7. Review combined risk assessment (product + prompt)
8. Take action based on risk levels
9. Print or download report for security review

### Using the Guidance Bot

1. Click the chat bubble (💬) in bottom-right corner
2. Ask questions or select quick questions
3. Get instant answers about:
   - Platform compatibility
   - Scoring methodology
   - Risk levels and actions
   - PII handling
   - Prompt security
   - And more!

## 🎨 Design Principles

- **Simplicity**: Complex security made simple
- **Transparency**: Clear scoring with no hidden logic
- **Guidance**: Contextual help at every step
- **Accessibility**: Plain language, no jargon
- **Responsiveness**: Works on all devices
- **Professionalism**: Amazon design aesthetic

## 🔒 Security Features

- Client-side scoring (no sensitive data sent for basic assessment)
- API integration for advanced prompt analysis
- ASR ID tracking for compliance
- PDF documentation support
- Audit trail through ASR ID linkage
- Graceful fallback if API unavailable

## 📊 Risk Assessment Logic

### Combined Risk Evaluation

The final deployment decision considers both product and prompt risk:

| Product Risk | Prompt Risk | Final Action |
|--------------|-------------|--------------|
| Low | Low | ✅ Proceed |
| Medium | Low | ⚠ File TT |
| High | Any | 🔴 Raise SIM |
| Any | High | 🔴 Raise SIM |

## 🛠️ Development

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Modern web browser

### Tech Stack
- React 18
- Vite 4
- React Router 6
- Native fetch API for HTTP requests

### Code Structure
- Functional components with hooks
- Inline styles for simplicity
- No external UI libraries (pure React)
- Modular component design

## 📝 Testing

Run through this checklist before deployment:

- [ ] All pages load correctly
- [ ] GuidanceBot appears and responds
- [ ] Concept Review calculates scores correctly
- [ ] Product Review requires ASR ID
- [ ] PDF upload works
- [ ] Prompt analysis calls API
- [ ] Risk levels display correctly
- [ ] Navigation works
- [ ] Responsive on mobile
- [ ] Print functionality works

## 🤝 Contributing

This is an internal Amazon tool. For improvements or bug reports:
1. Contact CTOSS SWAT team
2. File a TT with enhancement requests
3. Follow Amazon's internal contribution guidelines

## 📞 Support

- **GuidanceBot**: Use the built-in chat for common questions
- **SWAT Team**: Contact for security guidance
- **Documentation**: See DEPLOYMENT_GUIDE.md for detailed setup

## 📜 License

Internal Amazon use only. Not for external distribution.

## 🎯 Roadmap

Future enhancements under consideration:
- [ ] Save/load concept reviews for comparison
- [ ] Export to multiple formats (PDF, Excel, JSON)
- [ ] Integration with Asana for ticket creation
- [ ] Historical trend analysis
- [ ] Team dashboards
- [ ] Automated SIM/TT creation

## 📚 Additional Resources

- **PRFAQ Document**: See SaferAI_PRFAQ_Narrative.md for full background
- **Deployment Guide**: See DEPLOYMENT_GUIDE.md for deployment instructions
- **Scoring Details**: See src/lib/scoringEngine.js for scoring logic
- **API Documentation**: Contact SWAT team for API specs

---

**Version**: 2.0 (Enhanced)
**Last Updated**: October 2025
**Maintained By**: CTOSS SWAT Team
