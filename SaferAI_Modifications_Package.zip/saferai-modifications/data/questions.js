// Concept Review Questions with Guidance
export const CONCEPT_QUESTIONS = {
  dataSensitivity: {
    id: 'dataSensitivity',
    title: '1. Data Sensitivity',
    question: 'What kind of data will your agent use or process?',
    guidance: 'Consider the most sensitive data your agent might access. Test data and public information carry no risk. Customer content (emails, chats, documents) and PII (names, addresses, credentials) carry the highest risk. If unsure, choose the higher risk option.',
    examples: 'Example: If your agent reads Zendesk tickets to generate summaries, that\'s "Customer content". If it only reads internal wiki pages, that\'s "Internal non-sensitive data".',
    options: [
      { label: 'Test / Public data only', score: 0 },
      { label: 'Internal non-sensitive data', score: 1 },
      { label: 'Employee or operational data', score: 2 },
      { label: 'Customer metadata (IDs, summaries)', score: 3 },
      { label: 'Customer content (emails, chats, attachments)', score: 4 },
      { label: 'Security-sensitive / PII / credentials', score: 5 }
    ]
  },
  accessPermissions: {
    id: 'accessPermissions',
    title: '2. Access Permissions',
    question: 'What kind of access will the agent need?',
    guidance: 'Think about what your agent needs to DO, not just read. Read-only access to specific APIs is low risk. Admin access or Unfettered Search (UFS) that can access anything is high risk. Scoped write access (like adding tags or notes) is medium risk.',
    examples: 'Example: If your agent can only read from a specific API endpoint, choose "Read-only scoped API". If it can update ticket status or close workflows, choose "Workflow approval or auto-closure".',
    options: [
      { label: 'None (sandboxed)', score: 0 },
      { label: 'Read-only scoped API', score: 1 },
      { label: 'Scoped write access (tag, assign)', score: 2 },
      { label: 'Cross-team or multi-tenant access', score: 3 },
      { label: 'Workflow approval or auto-closure', score: 4 },
      { label: 'Admin / Unfettered Search (UFS)', score: 5 }
    ]
  },
  outputSafety: {
    id: 'outputSafety',
    title: '3. Output Safety',
    question: 'What actions or outputs will your agent perform?',
    guidance: 'Consider the most impactful thing your agent can do. Suggestions that humans review are low risk. Autonomous actions (sending emails, closing tickets, making changes without human review) are high risk.',
    examples: 'Example: If your agent generates draft responses that a human must review before sending, choose "Drafts for human review". If it automatically sends emails to customers, choose "Sends internal/external messages".',
    options: [
      { label: 'Suggestions or insights only', score: 0 },
      { label: 'Drafts for human review', score: 1 },
      { label: 'Internal updates (tags, notes)', score: 2 },
      { label: 'Auto-closes or updates workflows', score: 3 },
      { label: 'Sends internal/external messages', score: 4 },
      { label: 'Executes changes autonomously', score: 5 }
    ]
  },
  promptSecurity: {
    id: 'promptSecurity',
    title: '4. Prompt Security',
    question: 'Who can interact with or modify your agent\'s instructions?',
    guidance: 'Think about who can send prompts to your agent and whether they can upload files or URLs. Fixed system prompts (no user input) are safest. Allowing external users or file uploads is highest risk due to prompt injection attacks.',
    examples: 'Example: If only your team can use the agent with pre-defined prompts, choose "Internal staff (limited prompts)". If any customer can send free-text questions, choose "External / public users".',
    options: [
      { label: 'Fixed system prompt only', score: 0 },
      { label: 'Internal staff (limited prompts)', score: 1 },
      { label: 'Internal users (free text allowed)', score: 2 },
      { label: 'Anyone in org (wide access)', score: 3 },
      { label: 'Accepts files / URLs', score: 4 },
      { label: 'External / public users', score: 5 }
    ]
  },
  externalIntegrations: {
    id: 'externalIntegrations',
    title: '5. External Integrations',
    question: 'Will your agent connect to any external systems or APIs?',
    guidance: 'Consider all systems your agent talks to. Internal Amazon tools are lower risk. Third-party SaaS (Slack, Jira) is medium risk. Public APIs or unverified endpoints are highest risk.',
    examples: 'Example: If your agent calls an internal Lambda function, choose "Internal AWS APIs". If it posts to a public Slack workspace or calls a random URL, choose "Unverified / dynamic endpoints".',
    options: [
      { label: 'None', score: 0 },
      { label: 'Internal tools (Nemo, Workfront)', score: 1 },
      { label: 'Internal AWS APIs (Lambda, S3)', score: 2 },
      { label: 'Third-party SaaS (Slack, Jira)', score: 3 },
      { label: 'Public APIs / Internet calls', score: 4 },
      { label: 'Unverified / dynamic endpoints', score: 5 }
    ]
  },
  businessImpact: {
    id: 'businessImpact',
    title: '6. Business Impact',
    question: 'What happens if the agent fails or misbehaves?',
    guidance: 'Think about the worst-case scenario if your agent breaks, hallucinates, or does something wrong. Test-only agents have no impact. Customer-facing or compliance-impacting failures are highest risk.',
    examples: 'Example: If your agent is just for testing and no one relies on it, choose "None (test only)". If customers would be affected or compliance could be violated, choose "Compliance / financial impact".',
    options: [
      { label: 'None (test only)', score: 0 },
      { label: 'Internal efficiency impact', score: 1 },
      { label: 'Team-level disruption', score: 2 },
      { label: 'Cross-org disruption', score: 3 },
      { label: 'Customer-facing impact', score: 4 },
      { label: 'Compliance / financial impact', score: 5 }
    ]
  },
  complianceReview: {
    id: 'complianceReview',
    title: '7. Compliance & Review',
    question: 'Has this idea been reviewed or approved?',
    guidance: 'Be honest about review status. If you haven\'t discussed this with anyone yet, choose "Not yet reviewed". If a peer or manager has looked at it, choose "Reviewed by peer". If it was previously rejected or you\'re unsure, choose "Rejected or unsure".',
    examples: 'Example: If you just had the idea today and haven\'t talked to anyone, choose "Not yet reviewed". If your manager said it sounds good, choose "Reviewed by peer / pending SWAT".',
    options: [
      { label: 'Already reviewed and approved', score: 0 },
      { label: 'Reviewed by peer / pending SWAT', score: 2 },
      { label: 'Not yet reviewed', score: 3 },
      { label: 'Rejected or unsure', score: 5 }
    ]
  },
  monitoring: {
    id: 'monitoring',
    title: '8. Monitoring',
    question: 'Will your agent have logging or monitoring?',
    guidance: 'Logging is critical for debugging and security. Full logging with dashboards (CloudWatch, Datadog) is best. No logging is highest risk because you won\'t know if something goes wrong.',
    examples: 'Example: If you\'re using CloudWatch Logs and have dashboards set up, choose "Full logging and dashboards". If you\'re just planning to check logs manually sometimes, choose "Manual tracking only".',
    options: [
      { label: 'Full logging and dashboards', score: 0 },
      { label: 'Partial logs (success/failure)', score: 2 },
      { label: 'Manual tracking only', score: 3 },
      { label: 'No monitoring planned', score: 5 }
    ]
  }
};

// Product Review Questions with Guidance
export const PRODUCT_QUESTIONS = {
  dataHandling: {
    id: 'dataHandling',
    title: '1. Data Handling',
    question: 'What kind of data does your agent now access or store?',
    guidance: 'Review what data your DEPLOYED agent actually uses. This should match or be more specific than your Concept Review. If you\'re now accessing more sensitive data than planned, that\'s a red flag.',
    examples: 'Example: If your agent stores customer email addresses in DynamoDB, that\'s "Customer metadata". If it stores full email content, that\'s "Customer content".',
    options: [
      { label: 'Test / mock data only', score: 0 },
      { label: 'Internal data', score: 1 },
      { label: 'Employee / anonymized customer data', score: 2 },
      { label: 'Customer metadata', score: 3 },
      { label: 'Customer content', score: 4 },
      { label: 'PII, security or credential data', score: 5 }
    ]
  },
  accessLevel: {
    id: 'accessLevel',
    title: '2. Access Level',
    question: 'What access level does the deployed agent use?',
    guidance: 'Check your IAM roles and API permissions. What can your agent ACTUALLY do in production? Admin access or UFS should trigger immediate SWAT review.',
    examples: 'Example: If your Lambda function has an IAM role that allows S3 read-only, choose "None / Read-only". If it can write to multiple services, choose "Cross-team write".',
    options: [
      { label: 'None / Read-only', score: 0 },
      { label: 'Scoped write access', score: 1 },
      { label: 'Cross-team write', score: 2 },
      { label: 'Auto-approval or closure', score: 3 },
      { label: 'Admin privileges', score: 4 },
      { label: 'Unfettered Search / broad access', score: 5 }
    ]
  },
  outputBehavior: {
    id: 'outputBehavior',
    title: '3. Output Behavior',
    question: 'What kind of actions or messages does it generate?',
    guidance: 'What does your agent DO with its outputs? Internal summaries are safe. Sending messages to customers or executing workflow changes without human review is high risk.',
    examples: 'Example: If your agent updates Jira tickets automatically, choose "Internal tagging or updates". If it sends Slack messages to customers, choose "Sends internal/external communications".',
    options: [
      { label: 'Internal summaries only', score: 0 },
      { label: 'Draft responses (reviewed)', score: 1 },
      { label: 'Internal tagging or updates', score: 2 },
      { label: 'Auto-actions without approval', score: 3 },
      { label: 'Sends internal/external communications', score: 4 },
      { label: 'Executes workflow changes directly', score: 5 }
    ]
  },
  inputHandling: {
    id: 'inputHandling',
    title: '4. Input Handling',
    question: 'Who can provide input to your agent?',
    guidance: 'Who can actually send prompts to your deployed agent? Internal team only is safest. Public or unverified users is highest risk.',
    examples: 'Example: If only your team can access the agent through an internal tool, choose "Internal team only". If customers can interact with it, choose "External customers".',
    options: [
      { label: 'Fixed system input', score: 0 },
      { label: 'Internal team only', score: 1 },
      { label: 'Internal org', score: 2 },
      { label: 'Vendors / third parties', score: 3 },
      { label: 'External customers', score: 4 },
      { label: 'Public or unverified users', score: 5 }
    ]
  },
  integrations: {
    id: 'integrations',
    title: '5. Integrations',
    question: 'What systems or APIs does your agent connect to?',
    guidance: 'List ALL integrations in your production deployment. Internal AWS services are lower risk. Public APIs or dynamic endpoints are higher risk.',
    examples: 'Example: If your agent calls Lambda, stores data in S3, and posts to Slack, choose "SaaS platforms (Slack, Jira)" as the highest risk integration.',
    options: [
      { label: 'None', score: 0 },
      { label: 'Internal APIs (Nemo, Workfront)', score: 1 },
      { label: 'AWS services (Lambda, DynamoDB)', score: 2 },
      { label: 'SaaS platforms (Slack, Jira)', score: 3 },
      { label: 'Public API endpoints', score: 4 },
      { label: 'Dynamic / unverified endpoints', score: 5 }
    ]
  },
  loggingAuditability: {
    id: 'loggingAuditability',
    title: '6. Logging & Auditability',
    question: 'Can you see what it\'s doing and when?',
    guidance: 'Check your actual logging setup. Can you see every action your agent takes? Can you audit it later? Full structured logs are required for high-risk agents.',
    examples: 'Example: If you have CloudWatch Logs with structured JSON and retention policies, choose "Full structured logs". If you just console.log() sometimes, choose "Manual or local logs".',
    options: [
      { label: 'Full structured logs (CloudWatch, S3)', score: 0 },
      { label: 'Partial logging (key events only)', score: 2 },
      { label: 'Manual or local logs', score: 3 },
      { label: 'No audit logs', score: 5 }
    ]
  },
  failureHandling: {
    id: 'failureHandling',
    title: '7. Failure Handling',
    question: 'What happens when the agent encounters an error?',
    guidance: 'Test your error handling. What happens if the LLM returns garbage? What if an API call fails? Graceful failure with notifications is best. Silent failures or continuing with bad data is worst.',
    examples: 'Example: If your agent has try-catch blocks and sends alerts to PagerDuty on errors, choose "Fails gracefully / notifies admin". If it just crashes silently, choose "Stops silently".',
    options: [
      { label: 'Fails gracefully / notifies admin', score: 0 },
      { label: 'Logs error only', score: 2 },
      { label: 'Stops silently', score: 3 },
      { label: 'Continues with incorrect data', score: 4 },
      { label: 'Impacts production or customers', score: 5 }
    ]
  },
  securityReview: {
    id: 'securityReview',
    title: '8. Security Review Status',
    question: 'What is the current security review status?',
    guidance: 'Be honest about what reviews you\'ve completed. This SaferAI assessment counts as "Self-assessed only". Peer review means your team lead reviewed it. Full security review means SWAT or InfoSec signed off.',
    examples: 'Example: If you\'re doing this SaferAI assessment for the first time, choose "Self-assessed only". If SWAT already reviewed and approved, choose "Completed full security review with approval".',
    options: [
      { label: 'Completed full security review with approval', score: 0 },
      { label: 'Peer reviewed by team lead', score: 1 },
      { label: 'Self-assessed only', score: 3 },
      { label: 'No security review conducted', score: 5 }
    ]
  }
};

// Platform options
export const PLATFORMS = [
  'PartyRock',
  'Amazon Q Business',
  'Bedrock Playground',
  'Approved Chatbots (Cedric, Mentor, Field Advisor)',
  'Custom Bedrock Integration',
  'Other (specify in description)'
];

// Development types
export const DEVELOPMENT_TYPES = [
  { value: 'low-code', label: 'Low Code (PartyRock, Q Business, No-Code Tools)' },
  { value: 'high-code', label: 'High Code (Custom Bedrock, Lambda, Full Development)' }
];
