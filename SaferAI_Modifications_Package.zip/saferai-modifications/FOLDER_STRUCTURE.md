# SaferAI Portal - Modified Files Installation Guide

## 📁 Folder Structure

Place the modified files in your existing SaferAI portal according to this structure:

```
your-saferai-portal/
├── src/
│   ├── pages/
│   │   ├── HomePage.jsx              ← REPLACE with new file
│   │   ├── ConceptReviewPage.jsx     ← REPLACE with new file
│   │   ├── ProductReviewPage.jsx     ← REPLACE with new file
│   │   └── MechanismPage.jsx         ← REPLACE with new file
│   ├── lib/
│   │   └── pdfGenerator.js           ← REPLACE with new file
│   └── data/
│       └── questions.js              ← REPLACE with new file
```

## 🔧 Installation Steps

1. **Backup your current files** (recommended)
   ```bash
   cp src/pages/HomePage.jsx src/pages/HomePage.jsx.backup
   cp src/pages/ConceptReviewPage.jsx src/pages/ConceptReviewPage.jsx.backup
   cp src/pages/ProductReviewPage.jsx src/pages/ProductReviewPage.jsx.backup
   cp src/pages/MechanismPage.jsx src/pages/MechanismPage.jsx.backup
   cp src/lib/pdfGenerator.js src/lib/pdfGenerator.js.backup
   cp src/data/questions.js src/data/questions.js.backup
   ```

2. **Copy the new files** from this package:
   ```bash
   cp pages/* your-saferai-portal/src/pages/
   cp lib/* your-saferai-portal/src/lib/
   cp data/* your-saferai-portal/src/data/
   ```

3. **Install required dependencies** (if not already installed):
   ```bash
   cd your-saferai-portal
   npm install jspdf jspdf-autotable
   # or
   pnpm add jspdf jspdf-autotable
   ```

4. **Test the application**:
   ```bash
   npm run dev
   # or
   pnpm run dev
   ```

5. **Build for production**:
   ```bash
   npm run build
   # or
   pnpm run build
   ```

## ✨ What's Changed

### HomePage.jsx
- Simplified to 3 clear action buttons:
  - Raise a Concept Review
  - Raise a Product Review  
  - Need Help? Talk to Guidance Bot
- Clean, welcoming design
- Removed clutter

### ConceptReviewPage.jsx & ProductReviewPage.jsx
- **Added new form fields:**
  - Project Name
  - Description
  - Platform
  - Requestor Login
  - Requestor Org
  - Direct Manager
  - L6 Sponsor
  - L7 Sponsor

- **Added guidance tooltips (?) for each risk vector question**
  - Hover over the (?) icon to see detailed explanation
  - Examples of how to answer each question
  - Clear guidance on scoring

### pdfGenerator.js
- Professional formatting with tables
- Amazon branding
- Proper layout and spacing
- Footer: © Amazon TSE CTOSS - Product Initiative
- Risk level color coding
- Comprehensive project information section

### MechanismPage.jsx
- Enhanced content
- Better platform explanations
- Improved layout and readability

### questions.js
- Added `guidance` field to each question
- Detailed explanations
- Examples for each risk vector

## 🎯 Key Features

✅ All form fields as specified
✅ Guidance tooltips on every question
✅ Professional PDF with Amazon branding
✅ Simplified, clear HomePage
✅ Enhanced Mechanism page

## 📝 Notes

- All files use Inter font (configured in index.css)
- Compatible with existing routing and state management
- No breaking changes to other components
- Maintains all existing functionality

## 🐛 Troubleshooting

If you encounter issues:

1. **Build errors**: Make sure jspdf and jspdf-autotable are installed
2. **Routing issues**: Verify App.jsx has correct route paths
3. **Missing tooltips**: Check that index.css includes tooltip styles
4. **PDF not generating**: Check browser console for errors

## 📧 Support

For questions or issues:
- Email: swat-team@amazon.com
- Slack: #ctoss-swat
