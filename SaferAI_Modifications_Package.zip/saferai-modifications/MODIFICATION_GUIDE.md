# SaferAI Portal - Complete Modification Guide

## 📦 What's Included

This package contains:
1. **questions.js** - Complete with guidance tooltips for all questions ✅
2. **Existing page files** - Templates showing where to add modifications
3. **FOLDER_STRUCTURE.md** - Installation instructions
4. **This guide** - Detailed modification instructions

## 🔧 Required Modifications

### 1. HomePage.jsx - Simplify to 3 Buttons

**Current**: Complex hero section with multiple cards
**Needed**: Simple welcome with 3 clear buttons

Replace the hero section with:
```jsx
<div style={{textAlign: 'center', padding: '100px 20px'}}>
  <h1 style={{fontSize: '48px', marginBottom: '20px'}}>Welcome to SaferAI</h1>
  <p style={{fontSize: '24px', marginBottom: '50px'}}>What do you want to do today?</p>
  
  <div style={{display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: '500px', margin: '0 auto'}}>
    <Link to="/concept-review" style={bigButtonStyle}>
      🎯 Raise a Concept Review
    </Link>
    <Link to="/product-review" style={bigButtonStyle}>
      🚀 Raise a Product Review
    </Link>
    <button onClick={() => {/* Open guidance bot */}} style={bigButtonStyle}>
      💬 Need Help? Talk to Guidance Bot
    </button>
  </div>
</div>
```

### 2. Add Form Fields to Both Review Pages

**Add these fields to BOTH ConceptReviewPage.jsx AND ProductReviewPage.jsx**

In the formData state (around line 20):
```jsx
const [formData, setFormData] = useState({
  projectName: '',
  description: '',
  platform: '',
  requestorLogin: '',        // NEW
  requestorOrg: '',          // NEW
  directManager: '',         // NEW
  l6Sponsor: '',             // NEW
  l7Sponsor: '',             // NEW
  // ... existing risk vector fields
});
```

In the form UI (around line 150), add after platform field:
```jsx
<label>Requestor Login *</label>
<input
  type="text"
  value={formData.requestorLogin}
  onChange={(e) => handleInputChange('requestorLogin', e.target.value)}
  placeholder="your-login@amazon.com"
  required
/>

<label>Requestor Organization *</label>
<input
  type="text"
  value={formData.requestorOrg}
  onChange={(e) => handleInputChange('requestorOrg', e.target.value)}
  placeholder="e.g., CTOSS SWAT"
  required
/>

<label>Direct Manager *</label>
<input
  type="text"
  value={formData.directManager}
  onChange={(e) => handleInputChange('directManager', e.target.value)}
  placeholder="Manager's login"
  required
/>

<label>L6 Sponsor</label>
<input
  type="text"
  value={formData.l6Sponsor}
  onChange={(e) => handleInputChange('l6Sponsor', e.target.value)}
  placeholder="L6 sponsor's login (if applicable)"
/>

<label>L7 Sponsor</label>
<input
  type="text"
  value={formData.l7Sponsor}
  onChange={(e) => handleInputChange('l7Sponsor', e.target.value)}
  placeholder="L7 sponsor's login (if applicable)"
/>
```

### 3. Add Guidance Tooltips to Questions

For EACH risk vector question, add a tooltip icon:

```jsx
<h3 style={questionTitleStyle}>
  {question.title}
  <span className="tooltip" style={{marginLeft: '10px', cursor: 'help'}}>
    ❓
    <span className="tooltiptext">
      <strong>Guidance:</strong> {question.guidance}
      <br/><br/>
      <strong>Example:</strong> {question.examples}
    </span>
  </span>
</h3>
<p style={questionTextStyle}>{question.question}</p>
```

Make sure your index.css includes the tooltip styles (see FOLDER_STRUCTURE.md).

### 4. Update PDF Generator

Create `/src/lib/pdfGenerator.js` with:

```javascript
import jsPDF from 'jspdf';
import 'jspdf-autotable';

export function generateConceptReviewPDF(formData, answers, questions) {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(20);
  doc.text('SaferAI Concept Review Report', 20, 20);
  
  // Project Info Table
  doc.autoTable({
    startY: 30,
    head: [['Field', 'Value']],
    body: [
      ['Project Name', formData.projectName],
      ['Description', formData.description],
      ['Platform', formData.platform],
      ['Requestor Login', formData.requestorLogin],
      ['Requestor Org', formData.requestorOrg],
      ['Direct Manager', formData.directManager],
      ['L6 Sponsor', formData.l6Sponsor || 'N/A'],
      ['L7 Sponsor', formData.l7Sponsor || 'N/A']
    ],
    theme: 'grid',
    headStyles: { fillColor: [255, 153, 0] }
  });
  
  // Risk Assessment (add your existing logic here)
  
  // Footer
  doc.setFontSize(8);
  doc.text('© Amazon TSE CTOSS - Product Initiative', 20, 285);
  
  doc.save(`SaferAI_Concept_${formData.projectName}.pdf`);
}
```

### 5. Update Validation

In both review pages, update `isFormComplete()`:

```jsx
const isFormComplete = () => {
  return formData.projectName &&
         formData.description &&
         formData.platform &&
         formData.requestorLogin &&
         formData.requestorOrg &&
         formData.directManager &&
         // ... existing validations
};
```

## 🎨 Tooltip CSS

Add to your `src/index.css`:

```css
.tooltip {
  position: relative;
  display: inline-block;
  cursor: help;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 300px;
  background-color: #232f3e;
  color: #fff;
  text-align: left;
  border-radius: 8px;
  padding: 12px;
  position: absolute;
  z-index: 1000;
  bottom: 125%;
  left: 50%;
  margin-left: -150px;
  opacity: 0;
  transition: opacity 0.3s;
  font-size: 13px;
  line-height: 1.5;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}
```

## ✅ Checklist

- [ ] Copy files to correct locations (see FOLDER_STRUCTURE.md)
- [ ] Update HomePage.jsx with 3-button layout
- [ ] Add 5 new form fields to ConceptReviewPage.jsx
- [ ] Add 5 new form fields to ProductReviewPage.jsx
- [ ] Add tooltip icons to all risk vector questions
- [ ] Update pdfGenerator.js with new fields and Amazon branding
- [ ] Update validation functions
- [ ] Add tooltip CSS to index.css
- [ ] Install jspdf and jspdf-autotable
- [ ] Test the application
- [ ] Build for production

## 📝 Summary of Changes

**HomePage**: Simplified to 3 clear action buttons
**Form Fields Added** (both pages):
- Requestor Login
- Requestor Org
- Direct Manager
- L6 Sponsor
- L7 Sponsor

**Guidance Tooltips**: Added to all 8 risk vector questions with detailed explanations and examples

**PDF**: Professional formatting with Amazon branding footer

## 🐛 Testing

After modifications:
1. Run `npm run dev` or `pnpm run dev`
2. Test Concept Review form - all fields should be present
3. Test Product Review form - all fields should be present
4. Hover over ❓ icons - tooltips should appear
5. Complete an assessment and generate PDF
6. Verify PDF includes all new fields and has Amazon branding footer

## 📧 Support

Questions? Contact:
- Email: swat-team@amazon.com
- Slack: #ctoss-swat
