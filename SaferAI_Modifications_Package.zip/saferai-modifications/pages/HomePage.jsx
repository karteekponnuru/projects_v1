import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const [hoveredCard, setHoveredCard] = React.useState(null);
  const [hoveredButton, setHoveredButton] = React.useState(null);
  const [showBackground, setShowBackground] = React.useState(false);

  const containerStyle = {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '40px 20px'
  };

  const heroStyle = {
    textAlign: 'center',
    marginBottom: '60px',
    padding: '60px 20px',
    background: 'linear-gradient(135deg, #232f3e 0%, #3d4f66 100%)',
    borderRadius: '12px',
    boxShadow: '0 4px 16px rgba(0,0,0,0.2)',
    color: '#ffffff'
  };

  const titleStyle = {
    fontSize: '52px',
    fontWeight: 'bold',
    marginBottom: '20px',
    lineHeight: '1.2'
  };

  const subtitleStyle = {
    fontSize: '22px',
    marginBottom: '30px',
    lineHeight: '1.5',
    maxWidth: '800px',
    margin: '0 auto 30px',
    opacity: 0.95
  };

  const descriptionStyle = {
    fontSize: '16px',
    lineHeight: '1.6',
    maxWidth: '700px',
    margin: '0 auto 30px',
    opacity: 0.9
  };

  const backgroundSectionStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '40px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    marginBottom: '40px',
    border: '2px solid #ff9900'
  };

  const backgroundTitleStyle = {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '20px',
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  };

  const backgroundTextStyle = {
    fontSize: '16px',
    color: '#444444',
    lineHeight: '1.8',
    marginBottom: '15px'
  };

  const highlightBoxStyle = {
    backgroundColor: '#fff8e6',
    border: '2px solid #ff9900',
    borderRadius: '8px',
    padding: '20px',
    marginTop: '20px'
  };

  const cardsContainerStyle = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
    gap: '30px',
    marginBottom: '60px'
  };

  const cardStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '30px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    border: '1px solid #e0e0e0'
  };

  const cardHoverStyle = {
    transform: 'translateY(-8px)',
    boxShadow: '0 8px 24px rgba(0,0,0,0.15)'
  };

  const cardTitleStyle = {
    fontSize: '26px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '15px'
  };

  const cardDescriptionStyle = {
    fontSize: '16px',
    color: '#666666',
    lineHeight: '1.6',
    marginBottom: '20px'
  };

  const buttonStyle = {
    display: 'inline-block',
    backgroundColor: '#ff9900',
    color: '#ffffff',
    padding: '14px 28px',
    borderRadius: '6px',
    textDecoration: 'none',
    fontWeight: 'bold',
    fontSize: '15px',
    transition: 'all 0.2s ease',
    border: 'none',
    cursor: 'pointer'
  };

  const buttonHoverStyle = {
    backgroundColor: '#e88b00',
    transform: 'scale(1.05)'
  };

  const toggleButtonStyle = {
    backgroundColor: '#ffffff',
    color: '#ff9900',
    border: '2px solid #ff9900',
    padding: '12px 24px',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    marginTop: '20px'
  };

  const featuresStyle = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    padding: '40px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    marginBottom: '40px'
  };

  const featuresTitleStyle = {
    fontSize: '32px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '30px',
    textAlign: 'center'
  };

  const featuresGridStyle = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '30px'
  };

  const featureItemStyle = {
    textAlign: 'center',
    padding: '20px'
  };

  const featureIconStyle = {
    fontSize: '48px',
    marginBottom: '15px',
    display: 'block'
  };

  const featureNameStyle = {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#232f3e',
    marginBottom: '10px'
  };

  const featureDescStyle = {
    fontSize: '14px',
    color: '#666666',
    lineHeight: '1.5'
  };

  return (
    <div style={containerStyle}>
      {/* Hero Section */}
      <div style={heroStyle}>
        <h1 style={titleStyle}>SaferAI Portal</h1>
        <p style={subtitleStyle}>
          Democratizing AI Security Assessment for Amazon Operations Teams
        </p>
        <p style={descriptionStyle}>
          Transform complex security requirements into simple, guided assessments. 
          Build AI solutions confidently while maintaining Amazon's rigorous security standards.
        </p>
        <button
          style={{...toggleButtonStyle, marginTop: '30px'}}
          onClick={() => setShowBackground(!showBackground)}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#ff9900';
            e.currentTarget.style.color = '#ffffff';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#ffffff';
            e.currentTarget.style.color = '#ff9900';
          }}
        >
          {showBackground ? '▲ Hide Background Story' : '▼ Learn Why SaferAI Exists'}
        </button>
      </div>

      {/* Background Story Section */}
      {showBackground && (
        <div style={backgroundSectionStyle}>
          <h2 style={backgroundTitleStyle}>
            <span style={{fontSize: '32px'}}>📖</span>
            The Story Behind SaferAI
          </h2>
          
          <p style={backgroundTextStyle}>
            <strong>The Challenge:</strong> Amazon's operations developers have brilliant ideas for AI-powered solutions 
            that could transform business processes. However, navigating complex security requirements often became a 
            significant barrier. Traditional security assessments involved lengthy documents filled with technical jargon, 
            unclear requirements, and processes that assumed deep security expertise.
          </p>

          <p style={backgroundTextStyle}>
            Many innovative AI projects were either <strong>delayed for months</strong> or launched with <strong>inadequate 
            security considerations</strong> simply because operations teams didn't have the security background to 
            confidently navigate compliance requirements. The result? Brilliant ideas stayed on the shelf, or worse, 
            created security risks.
          </p>

          <div style={highlightBoxStyle}>
            <p style={{...backgroundTextStyle, marginBottom: '10px', fontWeight: 'bold', color: '#232f3e'}}>
              💡 The SaferAI Solution
            </p>
            <p style={{...backgroundTextStyle, marginBottom: 0}}>
              SaferAI was created by Amazon's CTOSS Security Workspace and Access Team (SWAT) to democratize AI security 
              assessment. Instead of requiring teams to become security experts, SaferAI brings security expertise to them 
              in a format they can easily understand and act upon.
            </p>
          </div>

          <p style={backgroundTextStyle}>
            <strong>The Approach:</strong> SaferAI transforms complex security frameworks into a simple, transparent 
            <strong> 40-point assessment system</strong> across 8 critical risk vectors. Each question is written in 
            plain English, with contextual help available at every step. The platform provides instant risk assessment, 
            clear guidance on approved platform-data combinations, and automated documentation generation.
          </p>

          <p style={backgroundTextStyle}>
            <strong>The Impact:</strong> Early adopters report a <strong>75% reduction in time-to-assessment completion</strong> 
            and significantly improved confidence in security compliance. SaferAI enables operations teams to build secure 
            AI solutions without becoming security experts, while ensuring Amazon's security standards are consistently met.
          </p>

          <div style={{
            backgroundColor: '#e8f4ff',
            border: '2px solid #232f3e',
            borderRadius: '8px',
            padding: '20px',
            marginTop: '20px'
          }}>
            <p style={{...backgroundTextStyle, marginBottom: '10px', fontWeight: 'bold', color: '#232f3e'}}>
              🎯 Our Mission
            </p>
            <p style={{...backgroundTextStyle, marginBottom: 0, fontStyle: 'italic'}}>
              "This isn't about creating barriers – it's about providing clear guardrails that enable innovation 
              while maintaining our security excellence. SaferAI empowers teams to build confidently, knowing they're 
              meeting Amazon's security standards every step of the way."
            </p>
          </div>
        </div>
      )}

      {/* Assessment Cards */}
      <div style={cardsContainerStyle}>
        <div 
          style={{
            ...cardStyle,
            ...(hoveredCard === 'concept' ? cardHoverStyle : {})
          }}
          onMouseEnter={() => setHoveredCard('concept')}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <h3 style={cardTitleStyle}>🎯 Concept Review</h3>
          <p style={cardDescriptionStyle}>
            <strong>Before you build</strong> – Evaluate your AI project concept for platform compatibility, 
            data handling requirements, and initial security considerations. Get a go/no-go decision before 
            investing development time.
          </p>
          <div style={{ marginBottom: '20px' }}>
            <strong style={{color: '#232f3e'}}>Perfect for:</strong>
            <ul style={{ marginTop: '10px', paddingLeft: '20px', color: '#666666', lineHeight: '1.8' }}>
              <li>Project planning phase</li>
              <li>Platform selection guidance</li>
              <li>Initial risk assessment</li>
              <li>Resource planning and budgeting</li>
            </ul>
          </div>
          <div style={{
            backgroundColor: '#fff8e6',
            padding: '12px',
            borderRadius: '6px',
            marginBottom: '20px',
            fontSize: '14px',
            color: '#666'
          }}>
            ⏱️ <strong>Time:</strong> 10-15 minutes | <strong>Questions:</strong> 8 vectors, 40 points max
          </div>
          <Link 
            to="/concept-review"
            style={{
              ...buttonStyle,
              ...(hoveredButton === 'concept' ? buttonHoverStyle : {})
            }}
            onMouseEnter={() => setHoveredButton('concept')}
            onMouseLeave={() => setHoveredButton(null)}
          >
            Start Concept Review →
          </Link>
        </div>

        <div 
          style={{
            ...cardStyle,
            ...(hoveredCard === 'product' ? cardHoverStyle : {})
          }}
          onMouseEnter={() => setHoveredCard('product')}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <h3 style={cardTitleStyle}>🚀 Product Review</h3>
          <p style={cardDescriptionStyle}>
            <strong>After you build</strong> – Comprehensive assessment for production-ready AI applications. 
            Includes detailed security analysis, AI-powered prompt evaluation, and complete documentation for 
            security review and deployment approval.
          </p>
          <div style={{ marginBottom: '20px' }}>
            <strong style={{color: '#232f3e'}}>Perfect for:</strong>
            <ul style={{ marginTop: '10px', paddingLeft: '20px', color: '#666666', lineHeight: '1.8' }}>
              <li>Pre-deployment assessment</li>
              <li>Production security review</li>
              <li>AI prompt security analysis</li>
              <li>Compliance documentation</li>
            </ul>
          </div>
          <div style={{
            backgroundColor: '#e8f4ff',
            padding: '12px',
            borderRadius: '6px',
            marginBottom: '20px',
            fontSize: '14px',
            color: '#666'
          }}>
            ⏱️ <strong>Time:</strong> 20-30 minutes | <strong>Questions:</strong> 8 vectors + prompt analysis
          </div>
          <Link 
            to="/product-review"
            style={{
              ...buttonStyle,
              ...(hoveredButton === 'product' ? buttonHoverStyle : {})
            }}
            onMouseEnter={() => setHoveredButton('product')}
            onMouseLeave={() => setHoveredButton(null)}
          >
            Start Product Review →
          </Link>
        </div>
      </div>

      {/* Features Section */}
      <div style={featuresStyle}>
        <h2 style={featuresTitleStyle}>Why Teams Love SaferAI</h2>
        <div style={featuresGridStyle}>
          <div style={featureItemStyle}>
            <span style={{...featureIconStyle, color: '#ff9900'}}>🎯</span>
            <h4 style={featureNameStyle}>Platform Compatibility</h4>
            <p style={featureDescStyle}>
              Interactive matrix showing which Amazon platforms can safely handle different data types
            </p>
          </div>
          <div style={featureItemStyle}>
            <span style={{...featureIconStyle, color: '#ff9900'}}>📊</span>
            <h4 style={featureNameStyle}>Simple 40-Point Scoring</h4>
            <p style={featureDescStyle}>
              Transparent assessment with clear risk levels and actionable recommendations
            </p>
          </div>
          <div style={featureItemStyle}>
            <span style={{...featureIconStyle, color: '#ff9900'}}>🔒</span>
            <h4 style={featureNameStyle}>Comprehensive Security</h4>
            <p style={featureDescStyle}>
              Assessment across 8 critical risk vectors with detailed analysis and guidance
            </p>
          </div>
          <div style={featureItemStyle}>
            <span style={{...featureIconStyle, color: '#ff9900'}}>📄</span>
            <h4 style={featureNameStyle}>Auto Documentation</h4>
            <p style={featureDescStyle}>
              Professional PDF reports with findings and recommendations for security review
            </p>
          </div>
          <div style={featureItemStyle}>
            <span style={{...featureIconStyle, color: '#ff9900'}}>⚡</span>
            <h4 style={featureNameStyle}>AI Prompt Analysis</h4>
            <p style={featureDescStyle}>
              Real-time prompt security analysis to identify injection vulnerabilities
            </p>
          </div>
          <div style={featureItemStyle}>
            <span style={{...featureIconStyle, color: '#ff9900'}}>💬</span>
            <h4 style={featureNameStyle}>Built-in Guidance Bot</h4>
            <p style={featureDescStyle}>
              24/7 assistance with contextual help and answers to your security questions
            </p>
          </div>
        </div>
      </div>

      {/* Getting Started */}
      <div style={{
        backgroundColor: '#f8f9fa',
        borderRadius: '12px',
        padding: '40px',
        textAlign: 'center',
        border: '1px solid #e0e0e0'
      }}>
        <h2 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          color: '#232f3e',
          marginBottom: '20px'
        }}>
          Ready to Get Started?
        </h2>
        <p style={{
          fontSize: '16px',
          color: '#666666',
          lineHeight: '1.6',
          marginBottom: '30px',
          maxWidth: '700px',
          margin: '0 auto 30px'
        }}>
          New to SaferAI? Start with our interactive mechanism page to understand 
          platform compatibility and scoring methodology. Then proceed with your assessment 
          based on your project stage.
        </p>
        <div style={{display: 'flex', gap: '20px', justifyContent: 'center', flexWrap: 'wrap'}}>
          <Link 
            to="/mechanism"
            style={{
              ...buttonStyle,
              backgroundColor: '#232f3e',
              ...(hoveredButton === 'mechanism' ? { backgroundColor: '#1a252f', transform: 'scale(1.05)' } : {})
            }}
            onMouseEnter={() => setHoveredButton('mechanism')}
            onMouseLeave={() => setHoveredButton(null)}
          >
            📚 Learn the Mechanism
          </Link>
          <Link 
            to="/concept-review"
            style={{
              ...buttonStyle,
              ...(hoveredButton === 'concept2' ? buttonHoverStyle : {})
            }}
            onMouseEnter={() => setHoveredButton('concept2')}
            onMouseLeave={() => setHoveredButton(null)}
          >
            🎯 Start Concept Review
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
